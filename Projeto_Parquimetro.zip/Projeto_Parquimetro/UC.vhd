--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Unidade de Controle Exemplo => UC_Exemplo.vhd
-- Rev. 0
-- Especificacoes: Entradas: CK, SP, IT, DT, CC, VC, ZR, PO, NG, ES, TM
-- 			 Saidas:Sel_mxa[1..0], Sel_mxb[1..0], Sel_alu[1..0],Lda, Ldb, Ldc, RT
-- A UC controla os elementos do fluxo de dados do processador para parquimetro.
--********************************************************************************
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity UC is
	port(	CK	: in std_logic;	-- clock de 50MHz
	
	-- Entradas Externas:
			SP	: in std_logic; 	-- sinal de presenca de veiculo (ativo em '1')
			IT	: in std_logic; 	-- sinal que incrementa  X minutos de credito (ativo em '1')
			DT	: in std_logic; 	-- sinal que decrementa Y minutos de credito (ativo em '1')
			CC : in std_logic; 	-- sinal de aceitacao do cartao de credito (ativo em '1')
			VC	: in std_logic; 	-- sinal para validacao de credito (ativo em '1')
			
	-- Sinais de Estado da ALU:
			ZR	: in std_logic;	-- resultado zero na operacao (ativo em '1')
			PO	: in std_logic;	-- resultado positivo na operacao (ativo em '1')
			NG	: in std_logic;	-- resultado negativo na operacao (ativo em '1')
			ES	: in std_logic;	-- resultado de estouro na operacao (>15)	
			
	-- Sinais de Estado dos TIMER's:
			TM	: in std_logic;	-- fim da temporizacao do Timer_1S (ativo em '1')
			
	-- Sinais de Saida para MUX:
			Sel_mxa : out std_logic_vector(1 downto 0); 	-- seleciona entrada de MUX_A
			Sel_mxb	: out std_logic_vector(1 downto 0);	-- seleciona entrada de MUX_B
			
	-- Sinais de Saida para ALU:
			Sel_alu	: out std_logic_vector(1 downto 0);	-- seleciona operacao da ALU
			
	-- Sinais de Saida para Registradores:
			Lda		: out std_logic;						-- carrega TP (Tempo de Permanencia)
			Ldb		: out std_logic;						-- carrega TV (Tempo de Validacao)
			Ldc		: out std_logic;						-- carrega TC (Tempo de Credito)
			
	-- Sinais de Saida para TIMER's:
			RT		: out std_logic;			-- inicia temporizacao do Timer_1 (ativo em '1')
			
	-- Sinais de Saida da UC:
			MT		: out std_logic );		-- inicia multa (ativo em '1')
end UC;

----------------------------------------------------------------------------------

architecture FSM of UC is

	type state_type is (ZERA_RG, VAG_OCP, CAR_TV, AGD_VAL, 
								SOM_X, VER_MAX, LIM_MAX, 
								SUB_Y, LIM_MIN, 
								SUB_TV, ZERA_TC, 
								ZERA_TV, VER_TC, AGD_TM, SUB_TC, 
								MULTA);
								
	signal E: state_type;
	
	CONSTANT XY: INTEGER := 1;   	-- declaracao de parametro
	CONSTANT Z: INTEGER := 7;   -- declaracao de parametro


begin

------------------------------ ESTADOS ------------------------------

	Transicao_de_Estados: process(CK, SP)
		begin
		
		if SP='0' then E <= ZERA_RG;	  			-- zera registros, multa e vaga livre (DP=0)
		elsif (CK'event and CK='1') then
		
		 case E is
		 
			when ZERA_RG => E <= VAG_OCP;			-- sinaliza ocupacao da vaga (DP=1)
		
			when VAG_OCP => E <= CAR_TV;			-- carrega tempo de validacao	
				
			when CAR_TV => E <= AGD_VAL;
				
			when AGD_VAL => 
				IF TM = '1' THEN E<= SUB_TV;
				ELSIF VC = '1' THEN E<= ZERA_TV;
				ELSIF VC = '1' THEN E<= ZERA_TV;
				ELSIF (IT='1' AND CC='1') THEN E<= SOM_X;
				ELSIF (DT='1' AND CC='1') THEN E<= SUB_Y;
				ELSE E <= AGD_VAL;
				END IF;
				
			when SOM_X => E <= VER_MAX;
			
			when VER_MAX => 
				IF PO = '0' THEN E <= AGD_VAL;
				ELSE E <= LIM_MAX;
				END IF;
				
			when LIM_MAX => E <= AGD_VAL;
			
			when SUB_Y => 
				IF NG = '0' THEN E <= AGD_VAL;
				ELSE E <= LIM_MIN;
				END IF;
				
			when LIM_MIN => E <= AGD_VAL;
			
			when SUB_TV => 
				IF ZR = '0' THEN E <= AGD_VAL;
				ELSE E <= ZERA_TC;
				END IF;
				
			when ZERA_TC => E <= MULTA;
			
			when ZERA_TV => E <= VER_TC;
			
			when VER_TC => 
				IF ZR = '0' THEN E <= AGD_TM;
				ELSE E <= MULTA;
				END IF;
				
			when AGD_TM => 
				IF TM = '0' THEN E <= AGD_TM;
				ELSE E <= SUB_TC;
				END IF;
				
			when SUB_TC => 
				IF ZR = '0' THEN E <= AGD_TM;
				ELSE E <= MULTA;
				END IF;		
				
			when MULTA => E <= MULTA;				-- aciona multa e tira foto	
			when others => Null;
			
		 end case;
		end if;
		
	end process Transicao_de_Estados;

	
------------------------------ sAIDAS ------------------------------


	Ativacao_de_Saidas: process(E)
		begin
		
		case E is
			when ZERA_RG =>
			  Sel_mxa <= "XX"; Sel_mxb <= "11"; Sel_alu <= "00";
			  Ldc <= '1'; Ldb <= '1'; Lda <= '1'; RT <= '1'; MT <= '0';

			when VAG_OCP =>
			  Sel_mxa <= "11"; Sel_mxb <= "11"; Sel_alu <= "10";
			  Ldc <= '0'; Ldb <= '0'; Lda <= '1'; RT <= '1'; MT <= '0';

			when CAR_TV =>
			  Sel_mxa <= "10"; Sel_mxb <= "11"; Sel_alu <= "10";
			  Ldc <= '0'; Ldb <= '1'; Lda <= '0'; RT <= '1'; MT <= '0';

			when AGD_VAL =>
			  Sel_mxa <= "XX"; Sel_mxb <= "XX"; Sel_alu <= "XX";
			  Ldc <= '0'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when SOM_X =>
			  Sel_mxa <= "11"; Sel_mxb <= "10"; Sel_alu <= "10";
			  Ldc <= '1'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when VER_MAX =>
			  Sel_mxa <= "10"; Sel_mxb <= "10"; Sel_alu <= "11";
			  Ldc <= '0'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when LIM_MAX =>
			  Sel_mxa <= "10"; Sel_mxb <= "11"; Sel_alu <= "10";
			  Ldc <= '1'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when SUB_Y =>
			  Sel_mxa <= "11"; Sel_mxb <= "10"; Sel_alu <= "11";
			  Ldc <= '1'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when LIM_MIN =>
			  Sel_mxa <= "XX"; Sel_mxb <= "11"; Sel_alu <= "00";
			  Ldc <= '1'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when SUB_TV =>
			  Sel_mxa <= "11"; Sel_mxb <= "01"; Sel_alu <= "11";
			  Ldc <= '0'; Ldb <= '1'; Lda <= '0'; RT <= '1'; MT <= '0';

			when ZERA_TC =>
			  Sel_mxa <= "XX"; Sel_mxb <= "11"; Sel_alu <= "00";
			  Ldc <= '1'; Ldb <= '0'; Lda <= '0'; RT <= '1'; MT <= '0';

			when ZERA_TV =>
			  Sel_mxa <= "XX"; Sel_mxb <= "11"; Sel_alu <= "00";
			  Ldc <= '0'; Ldb <= '1'; Lda <= '0'; RT <= '0'; MT <= '0';

			when VER_TC =>
			  Sel_mxa <= "XX"; Sel_mxb <= "10"; Sel_alu <= "00";
			  Ldc <= '0'; Ldb <= '0'; Lda <= '0'; RT <= '1'; MT <= '0';  

			when AGD_TM =>
			  Sel_mxa <= "XX"; Sel_mxb <= "XX"; Sel_alu <= "XX";
			  Ldc <= '0'; Ldb <= '0'; Lda <= '0'; RT <= '0'; MT <= '0';

			when SUB_TC =>
			  Sel_mxa <= "11"; Sel_mxb <= "10"; Sel_alu <= "11";
			  Ldc <= '1'; Ldb <= '0'; Lda <= '0'; RT <= '1'; MT <= '0';

			when MULTA =>
			  Sel_mxa <= "11"; Sel_mxb <= "00"; Sel_alu <= "10";
			  Ldc <= '0'; Ldb <= '0'; Lda <= '1'; RT <= '1'; MT <= '1';
	
			when others => Null;
			
		end case;
	end process Ativacao_de_Saidas;

end FSM;

