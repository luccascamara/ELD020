-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 16.1.0 Build 196 10/24/2016 SJ Lite Edition"

-- DATE "11/05/2025 14:52:36"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	Parquimetro IS
    PORT (
	RT : OUT std_logic;
	CK : IN std_logic;
	SP : IN std_logic;
	IT : IN std_logic;
	DT : IN std_logic;
	CC : IN std_logic;
	VC : IN std_logic;
	LDC : OUT std_logic;
	ALU : OUT std_logic_vector(3 DOWNTO 0);
	LDB : OUT std_logic;
	TM : OUT std_logic;
	MT : OUT std_logic;
	LDA : OUT std_logic;
	DP : OUT std_logic_vector(3 DOWNTO 0);
	TC : OUT std_logic_vector(3 DOWNTO 0);
	TV : OUT std_logic_vector(3 DOWNTO 0)
	);
END Parquimetro;

ARCHITECTURE structure OF Parquimetro IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_RT : std_logic;
SIGNAL ww_CK : std_logic;
SIGNAL ww_SP : std_logic;
SIGNAL ww_IT : std_logic;
SIGNAL ww_DT : std_logic;
SIGNAL ww_CC : std_logic;
SIGNAL ww_VC : std_logic;
SIGNAL ww_LDC : std_logic;
SIGNAL ww_ALU : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_LDB : std_logic;
SIGNAL ww_TM : std_logic;
SIGNAL ww_MT : std_logic;
SIGNAL ww_LDA : std_logic;
SIGNAL ww_DP : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_TC : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_TV : std_logic_vector(3 DOWNTO 0);
SIGNAL \RT~output_o\ : std_logic;
SIGNAL \LDC~output_o\ : std_logic;
SIGNAL \ALU[3]~output_o\ : std_logic;
SIGNAL \ALU[2]~output_o\ : std_logic;
SIGNAL \ALU[1]~output_o\ : std_logic;
SIGNAL \ALU[0]~output_o\ : std_logic;
SIGNAL \LDB~output_o\ : std_logic;
SIGNAL \TM~output_o\ : std_logic;
SIGNAL \MT~output_o\ : std_logic;
SIGNAL \LDA~output_o\ : std_logic;
SIGNAL \DP[3]~output_o\ : std_logic;
SIGNAL \DP[2]~output_o\ : std_logic;
SIGNAL \DP[1]~output_o\ : std_logic;
SIGNAL \DP[0]~output_o\ : std_logic;
SIGNAL \TC[3]~output_o\ : std_logic;
SIGNAL \TC[2]~output_o\ : std_logic;
SIGNAL \TC[1]~output_o\ : std_logic;
SIGNAL \TC[0]~output_o\ : std_logic;
SIGNAL \TV[3]~output_o\ : std_logic;
SIGNAL \TV[2]~output_o\ : std_logic;
SIGNAL \TV[1]~output_o\ : std_logic;
SIGNAL \TV[0]~output_o\ : std_logic;
SIGNAL \CK~input_o\ : std_logic;
SIGNAL \CC~input_o\ : std_logic;
SIGNAL \inst10|CNT[0]~26_combout\ : std_logic;
SIGNAL \inst10|CNT[0]~27\ : std_logic;
SIGNAL \inst10|CNT[1]~28_combout\ : std_logic;
SIGNAL \inst10|CNT[1]~29\ : std_logic;
SIGNAL \inst10|CNT[2]~30_combout\ : std_logic;
SIGNAL \inst10|CNT[2]~31\ : std_logic;
SIGNAL \inst10|CNT[3]~32_combout\ : std_logic;
SIGNAL \inst10|CNT[3]~33\ : std_logic;
SIGNAL \inst10|CNT[4]~34_combout\ : std_logic;
SIGNAL \inst10|CNT[4]~35\ : std_logic;
SIGNAL \inst10|CNT[5]~36_combout\ : std_logic;
SIGNAL \inst10|LessThan0~0_combout\ : std_logic;
SIGNAL \inst10|CNT[5]~37\ : std_logic;
SIGNAL \inst10|CNT[6]~38_combout\ : std_logic;
SIGNAL \inst10|CNT[6]~39\ : std_logic;
SIGNAL \inst10|CNT[7]~40_combout\ : std_logic;
SIGNAL \inst10|CNT[7]~41\ : std_logic;
SIGNAL \inst10|CNT[8]~42_combout\ : std_logic;
SIGNAL \inst10|CNT[8]~43\ : std_logic;
SIGNAL \inst10|CNT[9]~44_combout\ : std_logic;
SIGNAL \inst10|LessThan0~1_combout\ : std_logic;
SIGNAL \inst10|CNT[9]~45\ : std_logic;
SIGNAL \inst10|CNT[10]~46_combout\ : std_logic;
SIGNAL \inst10|CNT[10]~47\ : std_logic;
SIGNAL \inst10|CNT[11]~48_combout\ : std_logic;
SIGNAL \inst10|CNT[11]~49\ : std_logic;
SIGNAL \inst10|CNT[12]~50_combout\ : std_logic;
SIGNAL \inst10|CNT[12]~51\ : std_logic;
SIGNAL \inst10|CNT[13]~52_combout\ : std_logic;
SIGNAL \inst10|LessThan0~2_combout\ : std_logic;
SIGNAL \inst10|CNT[13]~53\ : std_logic;
SIGNAL \inst10|CNT[14]~54_combout\ : std_logic;
SIGNAL \inst10|CNT[14]~55\ : std_logic;
SIGNAL \inst10|CNT[15]~56_combout\ : std_logic;
SIGNAL \inst10|CNT[15]~57\ : std_logic;
SIGNAL \inst10|CNT[16]~58_combout\ : std_logic;
SIGNAL \inst10|CNT[16]~59\ : std_logic;
SIGNAL \inst10|CNT[17]~60_combout\ : std_logic;
SIGNAL \inst10|LessThan0~3_combout\ : std_logic;
SIGNAL \inst10|LessThan0~4_combout\ : std_logic;
SIGNAL \inst10|CNT[17]~61\ : std_logic;
SIGNAL \inst10|CNT[18]~62_combout\ : std_logic;
SIGNAL \inst10|CNT[18]~63\ : std_logic;
SIGNAL \inst10|CNT[19]~64_combout\ : std_logic;
SIGNAL \inst10|CNT[19]~65\ : std_logic;
SIGNAL \inst10|CNT[20]~66_combout\ : std_logic;
SIGNAL \inst10|CNT[20]~67\ : std_logic;
SIGNAL \inst10|CNT[21]~68_combout\ : std_logic;
SIGNAL \inst10|LessThan0~5_combout\ : std_logic;
SIGNAL \inst10|CNT[21]~69\ : std_logic;
SIGNAL \inst10|CNT[22]~70_combout\ : std_logic;
SIGNAL \inst10|CNT[22]~71\ : std_logic;
SIGNAL \inst10|CNT[23]~72_combout\ : std_logic;
SIGNAL \inst10|CNT[23]~73\ : std_logic;
SIGNAL \inst10|CNT[24]~74_combout\ : std_logic;
SIGNAL \inst10|CNT[24]~75\ : std_logic;
SIGNAL \inst10|CNT[25]~76_combout\ : std_logic;
SIGNAL \inst10|LessThan0~6_combout\ : std_logic;
SIGNAL \inst10|TM~0_combout\ : std_logic;
SIGNAL \inst10|TM~q\ : std_logic;
SIGNAL \VC~input_o\ : std_logic;
SIGNAL \inst|E~23_combout\ : std_logic;
SIGNAL \DT~input_o\ : std_logic;
SIGNAL \IT~input_o\ : std_logic;
SIGNAL \inst|E~25_combout\ : std_logic;
SIGNAL \SP~input_o\ : std_logic;
SIGNAL \inst|E.SUB_Y~q\ : std_logic;
SIGNAL \inst|E.ZERA_RG~q\ : std_logic;
SIGNAL \inst|E.VAG_OCP~0_combout\ : std_logic;
SIGNAL \inst|E.VAG_OCP~q\ : std_logic;
SIGNAL \inst|E.CAR_TV~q\ : std_logic;
SIGNAL \inst|E~29_combout\ : std_logic;
SIGNAL \inst|E.ZERA_TV~q\ : std_logic;
SIGNAL \inst|E.VER_TC~q\ : std_logic;
SIGNAL \inst|WideOr16~1_combout\ : std_logic;
SIGNAL \inst|E~24_combout\ : std_logic;
SIGNAL \inst|E.SOM_X~q\ : std_logic;
SIGNAL \inst|WideOr13~0_combout\ : std_logic;
SIGNAL \inst|WideOr13~combout\ : std_logic;
SIGNAL \inst|E.MULTA~0_combout\ : std_logic;
SIGNAL \inst|E.MULTA~q\ : std_logic;
SIGNAL \inst|E.VER_MAX~q\ : std_logic;
SIGNAL \inst|WideOr9~0_combout\ : std_logic;
SIGNAL \inst|WideOr9~combout\ : std_logic;
SIGNAL \inst40|Mux3~0_combout\ : std_logic;
SIGNAL \inst|WideOr14~combout\ : std_logic;
SIGNAL \inst40|Mux1~0_combout\ : std_logic;
SIGNAL \inst|WideOr6~combout\ : std_logic;
SIGNAL \inst9|Add0~2_combout\ : std_logic;
SIGNAL \inst9|Add1~2_combout\ : std_logic;
SIGNAL \inst9|Add2~10_combout\ : std_logic;
SIGNAL \inst40|Mux0~0_combout\ : std_logic;
SIGNAL \inst9|LessThan0~0_combout\ : std_logic;
SIGNAL \inst9|Alu_out[0]~4_combout\ : std_logic;
SIGNAL \inst9|LessThan1~0_combout\ : std_logic;
SIGNAL \inst9|LessThan1~1_combout\ : std_logic;
SIGNAL \inst9|Temp[5]~0_combout\ : std_logic;
SIGNAL \inst9|Alu_out[0]_117~combout\ : std_logic;
SIGNAL \inst9|Mux6~4_combout\ : std_logic;
SIGNAL \inst9|Mux6~5_combout\ : std_logic;
SIGNAL \inst40|Mux3~1_combout\ : std_logic;
SIGNAL \inst9|Add0~3\ : std_logic;
SIGNAL \inst9|Add0~4_combout\ : std_logic;
SIGNAL \inst9|Add2~2_combout\ : std_logic;
SIGNAL \inst9|Add1~3\ : std_logic;
SIGNAL \inst9|Add1~4_combout\ : std_logic;
SIGNAL \inst9|Alu_out[1]~0_combout\ : std_logic;
SIGNAL \inst9|Alu_out[1]~3_combout\ : std_logic;
SIGNAL \inst9|Alu_out[1]_127~combout\ : std_logic;
SIGNAL \inst9|Mux5~4_combout\ : std_logic;
SIGNAL \inst9|Mux5~5_combout\ : std_logic;
SIGNAL \inst40|Mux2~0_combout\ : std_logic;
SIGNAL \inst9|Add0~5\ : std_logic;
SIGNAL \inst9|Add0~6_combout\ : std_logic;
SIGNAL \inst9|Add2~3\ : std_logic;
SIGNAL \inst9|Add2~4_combout\ : std_logic;
SIGNAL \inst9|Add1~5\ : std_logic;
SIGNAL \inst9|Add1~6_combout\ : std_logic;
SIGNAL \inst9|Alu_out[2]~2_combout\ : std_logic;
SIGNAL \inst9|Alu_out[2]_137~combout\ : std_logic;
SIGNAL \inst9|Mux4~4_combout\ : std_logic;
SIGNAL \inst9|Mux4~5_combout\ : std_logic;
SIGNAL \inst|E~27_combout\ : std_logic;
SIGNAL \inst9|LessThan1~2_combout\ : std_logic;
SIGNAL \inst9|Mux8~2_combout\ : std_logic;
SIGNAL \inst|E~28_combout\ : std_logic;
SIGNAL \inst|E.LIM_MIN~q\ : std_logic;
SIGNAL \inst|WideOr4~0_combout\ : std_logic;
SIGNAL \inst|WideOr4~1_combout\ : std_logic;
SIGNAL \inst9|Add0~7\ : std_logic;
SIGNAL \inst9|Add0~8_combout\ : std_logic;
SIGNAL \inst9|Add2~5\ : std_logic;
SIGNAL \inst9|Add2~6_combout\ : std_logic;
SIGNAL \inst9|Add1~7\ : std_logic;
SIGNAL \inst9|Add1~8_combout\ : std_logic;
SIGNAL \inst9|Alu_out[3]~1_combout\ : std_logic;
SIGNAL \inst9|Alu_out[3]_147~combout\ : std_logic;
SIGNAL \inst9|Mux3~5_combout\ : std_logic;
SIGNAL \inst9|Mux3~6_combout\ : std_logic;
SIGNAL \inst9|Equal1~0_combout\ : std_logic;
SIGNAL \inst9|Add2~7\ : std_logic;
SIGNAL \inst9|Add2~8_combout\ : std_logic;
SIGNAL \inst9|Add0~9\ : std_logic;
SIGNAL \inst9|Add0~10_combout\ : std_logic;
SIGNAL \inst9|Mux2~11_combout\ : std_logic;
SIGNAL \inst9|Add1~9\ : std_logic;
SIGNAL \inst9|Add1~10_combout\ : std_logic;
SIGNAL \inst9|Mux2~10_combout\ : std_logic;
SIGNAL \inst9|Mux0~0_combout\ : std_logic;
SIGNAL \inst9|Equal1~1_combout\ : std_logic;
SIGNAL \inst9|Equal1~2_combout\ : std_logic;
SIGNAL \inst9|Equal1~3_combout\ : std_logic;
SIGNAL \inst|Selector1~0_combout\ : std_logic;
SIGNAL \inst|E.AGD_TM~q\ : std_logic;
SIGNAL \inst|E~22_combout\ : std_logic;
SIGNAL \inst|E.SUB_TC~q\ : std_logic;
SIGNAL \inst|WideOr12~0_combout\ : std_logic;
SIGNAL \inst9|Mux2~6_combout\ : std_logic;
SIGNAL \inst9|Mux2~7_combout\ : std_logic;
SIGNAL \inst9|Mux1~0_combout\ : std_logic;
SIGNAL \inst9|PO~0_combout\ : std_logic;
SIGNAL \inst9|PO~1_combout\ : std_logic;
SIGNAL \inst|E~26_combout\ : std_logic;
SIGNAL \inst|E.LIM_MAX~q\ : std_logic;
SIGNAL \inst|Selector0~0_combout\ : std_logic;
SIGNAL \inst|Selector0~1_combout\ : std_logic;
SIGNAL \inst|Selector0~2_combout\ : std_logic;
SIGNAL \inst9|Mux3~4_combout\ : std_logic;
SIGNAL \inst9|Mux2~8_combout\ : std_logic;
SIGNAL \inst9|Mux2~9_combout\ : std_logic;
SIGNAL \inst|Selector0~3_combout\ : std_logic;
SIGNAL \inst|Selector0~4_combout\ : std_logic;
SIGNAL \inst|E.AGD_VAL~q\ : std_logic;
SIGNAL \inst|E~21_combout\ : std_logic;
SIGNAL \inst|E.SUB_TV~q\ : std_logic;
SIGNAL \inst|E~20_combout\ : std_logic;
SIGNAL \inst|E.ZERA_TC~q\ : std_logic;
SIGNAL \inst|WideOr16~0_combout\ : std_logic;
SIGNAL \inst|WideOr16~combout\ : std_logic;
SIGNAL \inst|WideOr15~combout\ : std_logic;
SIGNAL \inst10|CNT\ : std_logic_vector(25 DOWNTO 0);
SIGNAL \inst13|R_out\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst8|R_out\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst9|Temp\ : std_logic_vector(5 DOWNTO 0);
SIGNAL \inst10|ALT_INV_TM~0_combout\ : std_logic;

BEGIN

RT <= ww_RT;
ww_CK <= CK;
ww_SP <= SP;
ww_IT <= IT;
ww_DT <= DT;
ww_CC <= CC;
ww_VC <= VC;
LDC <= ww_LDC;
ALU <= ww_ALU;
LDB <= ww_LDB;
TM <= ww_TM;
MT <= ww_MT;
LDA <= ww_LDA;
DP <= ww_DP;
TC <= ww_TC;
TV <= ww_TV;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\inst10|ALT_INV_TM~0_combout\ <= NOT \inst10|TM~0_combout\;

\RT~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|WideOr16~combout\,
	devoe => ww_devoe,
	o => \RT~output_o\);

\LDC~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|WideOr13~combout\,
	devoe => ww_devoe,
	o => \LDC~output_o\);

\ALU[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux3~6_combout\,
	devoe => ww_devoe,
	o => \ALU[3]~output_o\);

\ALU[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux4~5_combout\,
	devoe => ww_devoe,
	o => \ALU[2]~output_o\);

\ALU[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux5~5_combout\,
	devoe => ww_devoe,
	o => \ALU[1]~output_o\);

\ALU[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst9|Mux6~5_combout\,
	devoe => ww_devoe,
	o => \ALU[0]~output_o\);

\LDB~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|WideOr14~combout\,
	devoe => ww_devoe,
	o => \LDB~output_o\);

\TM~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst10|TM~q\,
	devoe => ww_devoe,
	o => \TM~output_o\);

\MT~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|E.MULTA~q\,
	devoe => ww_devoe,
	o => \MT~output_o\);

\LDA~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|WideOr15~combout\,
	devoe => ww_devoe,
	o => \LDA~output_o\);

\DP[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(3),
	devoe => ww_devoe,
	o => \DP[3]~output_o\);

\DP[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(2),
	devoe => ww_devoe,
	o => \DP[2]~output_o\);

\DP[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(1),
	devoe => ww_devoe,
	o => \DP[1]~output_o\);

\DP[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(0),
	devoe => ww_devoe,
	o => \DP[0]~output_o\);

\TC[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(3),
	devoe => ww_devoe,
	o => \TC[3]~output_o\);

\TC[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(2),
	devoe => ww_devoe,
	o => \TC[2]~output_o\);

\TC[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(1),
	devoe => ww_devoe,
	o => \TC[1]~output_o\);

\TC[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst13|R_out\(0),
	devoe => ww_devoe,
	o => \TC[0]~output_o\);

\TV[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|R_out\(3),
	devoe => ww_devoe,
	o => \TV[3]~output_o\);

\TV[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|R_out\(2),
	devoe => ww_devoe,
	o => \TV[2]~output_o\);

\TV[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|R_out\(1),
	devoe => ww_devoe,
	o => \TV[1]~output_o\);

\TV[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst8|R_out\(0),
	devoe => ww_devoe,
	o => \TV[0]~output_o\);

\CK~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK,
	o => \CK~input_o\);

\CC~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CC,
	o => \CC~input_o\);

\inst10|CNT[0]~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[0]~26_combout\ = \inst10|CNT\(0) $ (VCC)
-- \inst10|CNT[0]~27\ = CARRY(\inst10|CNT\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(0),
	datad => VCC,
	combout => \inst10|CNT[0]~26_combout\,
	cout => \inst10|CNT[0]~27\);

\inst10|CNT[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[0]~26_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(0));

\inst10|CNT[1]~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[1]~28_combout\ = (\inst10|CNT\(1) & (!\inst10|CNT[0]~27\)) # (!\inst10|CNT\(1) & ((\inst10|CNT[0]~27\) # (GND)))
-- \inst10|CNT[1]~29\ = CARRY((!\inst10|CNT[0]~27\) # (!\inst10|CNT\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(1),
	datad => VCC,
	cin => \inst10|CNT[0]~27\,
	combout => \inst10|CNT[1]~28_combout\,
	cout => \inst10|CNT[1]~29\);

\inst10|CNT[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[1]~28_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(1));

\inst10|CNT[2]~30\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[2]~30_combout\ = (\inst10|CNT\(2) & (\inst10|CNT[1]~29\ $ (GND))) # (!\inst10|CNT\(2) & (!\inst10|CNT[1]~29\ & VCC))
-- \inst10|CNT[2]~31\ = CARRY((\inst10|CNT\(2) & !\inst10|CNT[1]~29\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(2),
	datad => VCC,
	cin => \inst10|CNT[1]~29\,
	combout => \inst10|CNT[2]~30_combout\,
	cout => \inst10|CNT[2]~31\);

\inst10|CNT[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[2]~30_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(2));

\inst10|CNT[3]~32\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[3]~32_combout\ = (\inst10|CNT\(3) & (!\inst10|CNT[2]~31\)) # (!\inst10|CNT\(3) & ((\inst10|CNT[2]~31\) # (GND)))
-- \inst10|CNT[3]~33\ = CARRY((!\inst10|CNT[2]~31\) # (!\inst10|CNT\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(3),
	datad => VCC,
	cin => \inst10|CNT[2]~31\,
	combout => \inst10|CNT[3]~32_combout\,
	cout => \inst10|CNT[3]~33\);

\inst10|CNT[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[3]~32_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(3));

\inst10|CNT[4]~34\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[4]~34_combout\ = (\inst10|CNT\(4) & (\inst10|CNT[3]~33\ $ (GND))) # (!\inst10|CNT\(4) & (!\inst10|CNT[3]~33\ & VCC))
-- \inst10|CNT[4]~35\ = CARRY((\inst10|CNT\(4) & !\inst10|CNT[3]~33\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(4),
	datad => VCC,
	cin => \inst10|CNT[3]~33\,
	combout => \inst10|CNT[4]~34_combout\,
	cout => \inst10|CNT[4]~35\);

\inst10|CNT[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[4]~34_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(4));

\inst10|CNT[5]~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[5]~36_combout\ = (\inst10|CNT\(5) & (!\inst10|CNT[4]~35\)) # (!\inst10|CNT\(5) & ((\inst10|CNT[4]~35\) # (GND)))
-- \inst10|CNT[5]~37\ = CARRY((!\inst10|CNT[4]~35\) # (!\inst10|CNT\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(5),
	datad => VCC,
	cin => \inst10|CNT[4]~35\,
	combout => \inst10|CNT[5]~36_combout\,
	cout => \inst10|CNT[5]~37\);

\inst10|CNT[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[5]~36_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(5));

\inst10|LessThan0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~0_combout\ = (\inst10|CNT\(2)) # ((\inst10|CNT\(3)) # ((\inst10|CNT\(4)) # (\inst10|CNT\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(2),
	datab => \inst10|CNT\(3),
	datac => \inst10|CNT\(4),
	datad => \inst10|CNT\(5),
	combout => \inst10|LessThan0~0_combout\);

\inst10|CNT[6]~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[6]~38_combout\ = (\inst10|CNT\(6) & (\inst10|CNT[5]~37\ $ (GND))) # (!\inst10|CNT\(6) & (!\inst10|CNT[5]~37\ & VCC))
-- \inst10|CNT[6]~39\ = CARRY((\inst10|CNT\(6) & !\inst10|CNT[5]~37\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(6),
	datad => VCC,
	cin => \inst10|CNT[5]~37\,
	combout => \inst10|CNT[6]~38_combout\,
	cout => \inst10|CNT[6]~39\);

\inst10|CNT[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[6]~38_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(6));

\inst10|CNT[7]~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[7]~40_combout\ = (\inst10|CNT\(7) & (!\inst10|CNT[6]~39\)) # (!\inst10|CNT\(7) & ((\inst10|CNT[6]~39\) # (GND)))
-- \inst10|CNT[7]~41\ = CARRY((!\inst10|CNT[6]~39\) # (!\inst10|CNT\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(7),
	datad => VCC,
	cin => \inst10|CNT[6]~39\,
	combout => \inst10|CNT[7]~40_combout\,
	cout => \inst10|CNT[7]~41\);

\inst10|CNT[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[7]~40_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(7));

\inst10|CNT[8]~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[8]~42_combout\ = (\inst10|CNT\(8) & (\inst10|CNT[7]~41\ $ (GND))) # (!\inst10|CNT\(8) & (!\inst10|CNT[7]~41\ & VCC))
-- \inst10|CNT[8]~43\ = CARRY((\inst10|CNT\(8) & !\inst10|CNT[7]~41\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(8),
	datad => VCC,
	cin => \inst10|CNT[7]~41\,
	combout => \inst10|CNT[8]~42_combout\,
	cout => \inst10|CNT[8]~43\);

\inst10|CNT[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[8]~42_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(8));

\inst10|CNT[9]~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[9]~44_combout\ = (\inst10|CNT\(9) & (!\inst10|CNT[8]~43\)) # (!\inst10|CNT\(9) & ((\inst10|CNT[8]~43\) # (GND)))
-- \inst10|CNT[9]~45\ = CARRY((!\inst10|CNT[8]~43\) # (!\inst10|CNT\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(9),
	datad => VCC,
	cin => \inst10|CNT[8]~43\,
	combout => \inst10|CNT[9]~44_combout\,
	cout => \inst10|CNT[9]~45\);

\inst10|CNT[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[9]~44_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(9));

\inst10|LessThan0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~1_combout\ = (\inst10|CNT\(6)) # ((\inst10|CNT\(7)) # ((\inst10|CNT\(8)) # (\inst10|CNT\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(6),
	datab => \inst10|CNT\(7),
	datac => \inst10|CNT\(8),
	datad => \inst10|CNT\(9),
	combout => \inst10|LessThan0~1_combout\);

\inst10|CNT[10]~46\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[10]~46_combout\ = (\inst10|CNT\(10) & (\inst10|CNT[9]~45\ $ (GND))) # (!\inst10|CNT\(10) & (!\inst10|CNT[9]~45\ & VCC))
-- \inst10|CNT[10]~47\ = CARRY((\inst10|CNT\(10) & !\inst10|CNT[9]~45\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(10),
	datad => VCC,
	cin => \inst10|CNT[9]~45\,
	combout => \inst10|CNT[10]~46_combout\,
	cout => \inst10|CNT[10]~47\);

\inst10|CNT[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[10]~46_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(10));

\inst10|CNT[11]~48\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[11]~48_combout\ = (\inst10|CNT\(11) & (!\inst10|CNT[10]~47\)) # (!\inst10|CNT\(11) & ((\inst10|CNT[10]~47\) # (GND)))
-- \inst10|CNT[11]~49\ = CARRY((!\inst10|CNT[10]~47\) # (!\inst10|CNT\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(11),
	datad => VCC,
	cin => \inst10|CNT[10]~47\,
	combout => \inst10|CNT[11]~48_combout\,
	cout => \inst10|CNT[11]~49\);

\inst10|CNT[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[11]~48_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(11));

\inst10|CNT[12]~50\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[12]~50_combout\ = (\inst10|CNT\(12) & (\inst10|CNT[11]~49\ $ (GND))) # (!\inst10|CNT\(12) & (!\inst10|CNT[11]~49\ & VCC))
-- \inst10|CNT[12]~51\ = CARRY((\inst10|CNT\(12) & !\inst10|CNT[11]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(12),
	datad => VCC,
	cin => \inst10|CNT[11]~49\,
	combout => \inst10|CNT[12]~50_combout\,
	cout => \inst10|CNT[12]~51\);

\inst10|CNT[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[12]~50_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(12));

\inst10|CNT[13]~52\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[13]~52_combout\ = (\inst10|CNT\(13) & (!\inst10|CNT[12]~51\)) # (!\inst10|CNT\(13) & ((\inst10|CNT[12]~51\) # (GND)))
-- \inst10|CNT[13]~53\ = CARRY((!\inst10|CNT[12]~51\) # (!\inst10|CNT\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(13),
	datad => VCC,
	cin => \inst10|CNT[12]~51\,
	combout => \inst10|CNT[13]~52_combout\,
	cout => \inst10|CNT[13]~53\);

\inst10|CNT[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[13]~52_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(13));

\inst10|LessThan0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~2_combout\ = (\inst10|CNT\(10)) # ((\inst10|CNT\(11)) # ((\inst10|CNT\(12)) # (\inst10|CNT\(13))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(10),
	datab => \inst10|CNT\(11),
	datac => \inst10|CNT\(12),
	datad => \inst10|CNT\(13),
	combout => \inst10|LessThan0~2_combout\);

\inst10|CNT[14]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[14]~54_combout\ = (\inst10|CNT\(14) & (\inst10|CNT[13]~53\ $ (GND))) # (!\inst10|CNT\(14) & (!\inst10|CNT[13]~53\ & VCC))
-- \inst10|CNT[14]~55\ = CARRY((\inst10|CNT\(14) & !\inst10|CNT[13]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(14),
	datad => VCC,
	cin => \inst10|CNT[13]~53\,
	combout => \inst10|CNT[14]~54_combout\,
	cout => \inst10|CNT[14]~55\);

\inst10|CNT[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[14]~54_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(14));

\inst10|CNT[15]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[15]~56_combout\ = (\inst10|CNT\(15) & (!\inst10|CNT[14]~55\)) # (!\inst10|CNT\(15) & ((\inst10|CNT[14]~55\) # (GND)))
-- \inst10|CNT[15]~57\ = CARRY((!\inst10|CNT[14]~55\) # (!\inst10|CNT\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(15),
	datad => VCC,
	cin => \inst10|CNT[14]~55\,
	combout => \inst10|CNT[15]~56_combout\,
	cout => \inst10|CNT[15]~57\);

\inst10|CNT[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[15]~56_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(15));

\inst10|CNT[16]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[16]~58_combout\ = (\inst10|CNT\(16) & (\inst10|CNT[15]~57\ $ (GND))) # (!\inst10|CNT\(16) & (!\inst10|CNT[15]~57\ & VCC))
-- \inst10|CNT[16]~59\ = CARRY((\inst10|CNT\(16) & !\inst10|CNT[15]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(16),
	datad => VCC,
	cin => \inst10|CNT[15]~57\,
	combout => \inst10|CNT[16]~58_combout\,
	cout => \inst10|CNT[16]~59\);

\inst10|CNT[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[16]~58_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(16));

\inst10|CNT[17]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[17]~60_combout\ = (\inst10|CNT\(17) & (!\inst10|CNT[16]~59\)) # (!\inst10|CNT\(17) & ((\inst10|CNT[16]~59\) # (GND)))
-- \inst10|CNT[17]~61\ = CARRY((!\inst10|CNT[16]~59\) # (!\inst10|CNT\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(17),
	datad => VCC,
	cin => \inst10|CNT[16]~59\,
	combout => \inst10|CNT[17]~60_combout\,
	cout => \inst10|CNT[17]~61\);

\inst10|CNT[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[17]~60_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(17));

\inst10|LessThan0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~3_combout\ = (\inst10|CNT\(14)) # ((\inst10|CNT\(15)) # ((\inst10|CNT\(16)) # (\inst10|CNT\(17))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(14),
	datab => \inst10|CNT\(15),
	datac => \inst10|CNT\(16),
	datad => \inst10|CNT\(17),
	combout => \inst10|LessThan0~3_combout\);

\inst10|LessThan0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~4_combout\ = (\inst10|LessThan0~0_combout\) # ((\inst10|LessThan0~1_combout\) # ((\inst10|LessThan0~2_combout\) # (\inst10|LessThan0~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|LessThan0~0_combout\,
	datab => \inst10|LessThan0~1_combout\,
	datac => \inst10|LessThan0~2_combout\,
	datad => \inst10|LessThan0~3_combout\,
	combout => \inst10|LessThan0~4_combout\);

\inst10|CNT[18]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[18]~62_combout\ = (\inst10|CNT\(18) & (\inst10|CNT[17]~61\ $ (GND))) # (!\inst10|CNT\(18) & (!\inst10|CNT[17]~61\ & VCC))
-- \inst10|CNT[18]~63\ = CARRY((\inst10|CNT\(18) & !\inst10|CNT[17]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(18),
	datad => VCC,
	cin => \inst10|CNT[17]~61\,
	combout => \inst10|CNT[18]~62_combout\,
	cout => \inst10|CNT[18]~63\);

\inst10|CNT[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[18]~62_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(18));

\inst10|CNT[19]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[19]~64_combout\ = (\inst10|CNT\(19) & (!\inst10|CNT[18]~63\)) # (!\inst10|CNT\(19) & ((\inst10|CNT[18]~63\) # (GND)))
-- \inst10|CNT[19]~65\ = CARRY((!\inst10|CNT[18]~63\) # (!\inst10|CNT\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(19),
	datad => VCC,
	cin => \inst10|CNT[18]~63\,
	combout => \inst10|CNT[19]~64_combout\,
	cout => \inst10|CNT[19]~65\);

\inst10|CNT[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[19]~64_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(19));

\inst10|CNT[20]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[20]~66_combout\ = (\inst10|CNT\(20) & (\inst10|CNT[19]~65\ $ (GND))) # (!\inst10|CNT\(20) & (!\inst10|CNT[19]~65\ & VCC))
-- \inst10|CNT[20]~67\ = CARRY((\inst10|CNT\(20) & !\inst10|CNT[19]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(20),
	datad => VCC,
	cin => \inst10|CNT[19]~65\,
	combout => \inst10|CNT[20]~66_combout\,
	cout => \inst10|CNT[20]~67\);

\inst10|CNT[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[20]~66_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(20));

\inst10|CNT[21]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[21]~68_combout\ = (\inst10|CNT\(21) & (!\inst10|CNT[20]~67\)) # (!\inst10|CNT\(21) & ((\inst10|CNT[20]~67\) # (GND)))
-- \inst10|CNT[21]~69\ = CARRY((!\inst10|CNT[20]~67\) # (!\inst10|CNT\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(21),
	datad => VCC,
	cin => \inst10|CNT[20]~67\,
	combout => \inst10|CNT[21]~68_combout\,
	cout => \inst10|CNT[21]~69\);

\inst10|CNT[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[21]~68_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(21));

\inst10|LessThan0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~5_combout\ = (\inst10|CNT\(18)) # ((\inst10|CNT\(19)) # ((\inst10|CNT\(20)) # (\inst10|CNT\(21))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(18),
	datab => \inst10|CNT\(19),
	datac => \inst10|CNT\(20),
	datad => \inst10|CNT\(21),
	combout => \inst10|LessThan0~5_combout\);

\inst10|CNT[22]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[22]~70_combout\ = (\inst10|CNT\(22) & (\inst10|CNT[21]~69\ $ (GND))) # (!\inst10|CNT\(22) & (!\inst10|CNT[21]~69\ & VCC))
-- \inst10|CNT[22]~71\ = CARRY((\inst10|CNT\(22) & !\inst10|CNT[21]~69\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(22),
	datad => VCC,
	cin => \inst10|CNT[21]~69\,
	combout => \inst10|CNT[22]~70_combout\,
	cout => \inst10|CNT[22]~71\);

\inst10|CNT[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[22]~70_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(22));

\inst10|CNT[23]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[23]~72_combout\ = (\inst10|CNT\(23) & (!\inst10|CNT[22]~71\)) # (!\inst10|CNT\(23) & ((\inst10|CNT[22]~71\) # (GND)))
-- \inst10|CNT[23]~73\ = CARRY((!\inst10|CNT[22]~71\) # (!\inst10|CNT\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(23),
	datad => VCC,
	cin => \inst10|CNT[22]~71\,
	combout => \inst10|CNT[23]~72_combout\,
	cout => \inst10|CNT[23]~73\);

\inst10|CNT[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[23]~72_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(23));

\inst10|CNT[24]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[24]~74_combout\ = (\inst10|CNT\(24) & (\inst10|CNT[23]~73\ $ (GND))) # (!\inst10|CNT\(24) & (!\inst10|CNT[23]~73\ & VCC))
-- \inst10|CNT[24]~75\ = CARRY((\inst10|CNT\(24) & !\inst10|CNT[23]~73\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(24),
	datad => VCC,
	cin => \inst10|CNT[23]~73\,
	combout => \inst10|CNT[24]~74_combout\,
	cout => \inst10|CNT[24]~75\);

\inst10|CNT[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[24]~74_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(24));

\inst10|CNT[25]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|CNT[25]~76_combout\ = \inst10|CNT\(25) $ (\inst10|CNT[24]~75\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(25),
	cin => \inst10|CNT[24]~75\,
	combout => \inst10|CNT[25]~76_combout\);

\inst10|CNT[25]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|CNT[25]~76_combout\,
	sclr => \inst|WideOr16~combout\,
	ena => \inst10|ALT_INV_TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|CNT\(25));

\inst10|LessThan0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|LessThan0~6_combout\ = (\inst10|CNT\(22)) # ((\inst10|CNT\(23)) # ((\inst10|CNT\(24)) # (\inst10|CNT\(25))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|CNT\(22),
	datab => \inst10|CNT\(23),
	datac => \inst10|CNT\(24),
	datad => \inst10|CNT\(25),
	combout => \inst10|LessThan0~6_combout\);

\inst10|TM~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst10|TM~0_combout\ = (!\inst|WideOr16~combout\ & ((\inst10|LessThan0~4_combout\) # ((\inst10|LessThan0~5_combout\) # (\inst10|LessThan0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst10|LessThan0~4_combout\,
	datab => \inst10|LessThan0~5_combout\,
	datac => \inst10|LessThan0~6_combout\,
	datad => \inst|WideOr16~combout\,
	combout => \inst10|TM~0_combout\);

\inst10|TM\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst10|TM~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst10|TM~q\);

\VC~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_VC,
	o => \VC~input_o\);

\inst|E~23\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~23_combout\ = (\inst|E.AGD_VAL~q\ & (!\inst10|TM~q\ & !\VC~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.AGD_VAL~q\,
	datac => \inst10|TM~q\,
	datad => \VC~input_o\,
	combout => \inst|E~23_combout\);

\DT~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_DT,
	o => \DT~input_o\);

\IT~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_IT,
	o => \IT~input_o\);

\inst|E~25\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~25_combout\ = (\CC~input_o\ & (\inst|E~23_combout\ & (\DT~input_o\ & !\IT~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CC~input_o\,
	datab => \inst|E~23_combout\,
	datac => \DT~input_o\,
	datad => \IT~input_o\,
	combout => \inst|E~25_combout\);

\SP~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SP,
	o => \SP~input_o\);

\inst|E.SUB_Y\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~25_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.SUB_Y~q\);

\inst|E.ZERA_RG\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => VCC,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.ZERA_RG~q\);

\inst|E.VAG_OCP~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E.VAG_OCP~0_combout\ = !\inst|E.ZERA_RG~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.ZERA_RG~q\,
	combout => \inst|E.VAG_OCP~0_combout\);

\inst|E.VAG_OCP\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E.VAG_OCP~0_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.VAG_OCP~q\);

\inst|E.CAR_TV\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E.VAG_OCP~q\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.CAR_TV~q\);

\inst|E~29\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~29_combout\ = (\inst|E.AGD_VAL~q\ & (\VC~input_o\ & !\inst10|TM~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.AGD_VAL~q\,
	datab => \VC~input_o\,
	datad => \inst10|TM~q\,
	combout => \inst|E~29_combout\);

\inst|E.ZERA_TV\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~29_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.ZERA_TV~q\);

\inst|E.VER_TC\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E.ZERA_TV~q\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.VER_TC~q\);

\inst|WideOr16~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr16~1_combout\ = (!\inst|E.VER_TC~q\ & !\inst|E.SUB_TC~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst|E.VER_TC~q\,
	datad => \inst|E.SUB_TC~q\,
	combout => \inst|WideOr16~1_combout\);

\inst|E~24\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~24_combout\ = (\IT~input_o\ & (\CC~input_o\ & \inst|E~23_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \IT~input_o\,
	datab => \CC~input_o\,
	datac => \inst|E~23_combout\,
	combout => \inst|E~24_combout\);

\inst|E.SOM_X\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~24_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.SOM_X~q\);

\inst|WideOr13~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr13~0_combout\ = (\inst|E.ZERA_TC~q\) # ((\inst|E.LIM_MAX~q\) # ((\inst|E.LIM_MIN~q\) # (!\inst|E.ZERA_RG~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.ZERA_TC~q\,
	datab => \inst|E.LIM_MAX~q\,
	datac => \inst|E.LIM_MIN~q\,
	datad => \inst|E.ZERA_RG~q\,
	combout => \inst|WideOr13~0_combout\);

\inst|WideOr13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr13~combout\ = (\inst|E.SUB_TC~q\) # ((\inst|E.SOM_X~q\) # ((\inst|E.SUB_Y~q\) # (\inst|WideOr13~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_TC~q\,
	datab => \inst|E.SOM_X~q\,
	datac => \inst|E.SUB_Y~q\,
	datad => \inst|WideOr13~0_combout\,
	combout => \inst|WideOr13~combout\);

\inst13|R_out[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux3~6_combout\,
	ena => \inst|WideOr13~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst13|R_out\(3));

\inst|E.MULTA~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E.MULTA~0_combout\ = (\inst|E.ZERA_TC~q\) # ((\inst|E.MULTA~q\) # ((\inst9|Equal1~3_combout\ & !\inst|WideOr16~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.ZERA_TC~q\,
	datab => \inst|E.MULTA~q\,
	datac => \inst9|Equal1~3_combout\,
	datad => \inst|WideOr16~1_combout\,
	combout => \inst|E.MULTA~0_combout\);

\inst|E.MULTA\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E.MULTA~0_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.MULTA~q\);

\inst|E.VER_MAX\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E.SOM_X~q\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.VER_MAX~q\);

\inst|WideOr9~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr9~0_combout\ = (\inst|E.SUB_TC~q\) # ((\inst|E.SOM_X~q\) # ((\inst|E.SUB_Y~q\) # (\inst|E.VER_MAX~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_TC~q\,
	datab => \inst|E.SOM_X~q\,
	datac => \inst|E.SUB_Y~q\,
	datad => \inst|E.VER_MAX~q\,
	combout => \inst|WideOr9~0_combout\);

\inst|WideOr9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr9~combout\ = (\inst|E.MULTA~q\) # ((\inst|E.VER_TC~q\) # (\inst|WideOr9~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.MULTA~q\,
	datab => \inst|E.VER_TC~q\,
	datac => \inst|WideOr9~0_combout\,
	combout => \inst|WideOr9~combout\);

\inst40|Mux3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst40|Mux3~0_combout\ = (\inst|E.SUB_TV~q\ & (!\inst|E.MULTA~q\ & (!\inst|E.VER_TC~q\ & !\inst|WideOr9~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_TV~q\,
	datab => \inst|E.MULTA~q\,
	datac => \inst|E.VER_TC~q\,
	datad => \inst|WideOr9~0_combout\,
	combout => \inst40|Mux3~0_combout\);

\inst|WideOr14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr14~combout\ = (\inst|E.CAR_TV~q\) # ((\inst|E.SUB_TV~q\) # ((\inst|E.ZERA_TV~q\) # (!\inst|E.ZERA_RG~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.CAR_TV~q\,
	datab => \inst|E.SUB_TV~q\,
	datac => \inst|E.ZERA_TV~q\,
	datad => \inst|E.ZERA_RG~q\,
	combout => \inst|WideOr14~combout\);

\inst8|R_out[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux4~5_combout\,
	ena => \inst|WideOr14~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst8|R_out\(2));

\inst40|Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst40|Mux1~0_combout\ = (\inst|WideOr9~combout\ & ((\inst13|R_out\(2)) # ((\inst40|Mux3~0_combout\ & \inst8|R_out\(2))))) # (!\inst|WideOr9~combout\ & (\inst40|Mux3~0_combout\ & (\inst8|R_out\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr9~combout\,
	datab => \inst40|Mux3~0_combout\,
	datac => \inst8|R_out\(2),
	datad => \inst13|R_out\(2),
	combout => \inst40|Mux1~0_combout\);

\inst|WideOr6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr6~combout\ = (\inst|E.CAR_TV~q\) # ((\inst|E.LIM_MAX~q\) # (\inst|E.VER_MAX~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.CAR_TV~q\,
	datab => \inst|E.LIM_MAX~q\,
	datac => \inst|E.VER_MAX~q\,
	combout => \inst|WideOr6~combout\);

\inst9|Add0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add0~2_combout\ = \inst40|Mux3~1_combout\ $ (VCC)
-- \inst9|Add0~3\ = CARRY(\inst40|Mux3~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux3~1_combout\,
	datad => VCC,
	combout => \inst9|Add0~2_combout\,
	cout => \inst9|Add0~3\);

\inst9|Add1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add1~2_combout\ = \inst40|Mux3~1_combout\ $ (VCC)
-- \inst9|Add1~3\ = CARRY(\inst40|Mux3~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux3~1_combout\,
	datad => VCC,
	combout => \inst9|Add1~2_combout\,
	cout => \inst9|Add1~3\);

\inst9|Add2~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add2~10_combout\ = !\inst40|Mux3~1_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux3~1_combout\,
	combout => \inst9|Add2~10_combout\);

\inst8|R_out[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux3~6_combout\,
	ena => \inst|WideOr14~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst8|R_out\(3));

\inst40|Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst40|Mux0~0_combout\ = (\inst13|R_out\(3) & ((\inst|WideOr9~combout\) # ((\inst8|R_out\(3) & \inst40|Mux3~0_combout\)))) # (!\inst13|R_out\(3) & (\inst8|R_out\(3) & (\inst40|Mux3~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst13|R_out\(3),
	datab => \inst8|R_out\(3),
	datac => \inst40|Mux3~0_combout\,
	datad => \inst|WideOr9~combout\,
	combout => \inst40|Mux0~0_combout\);

\inst9|LessThan0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|LessThan0~0_combout\ = (\inst40|Mux0~0_combout\) # ((!\inst|WideOr6~combout\ & ((\inst40|Mux1~0_combout\) # (\inst40|Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux0~0_combout\,
	datab => \inst40|Mux1~0_combout\,
	datac => \inst40|Mux2~0_combout\,
	datad => \inst|WideOr6~combout\,
	combout => \inst9|LessThan0~0_combout\);

\inst9|Alu_out[0]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[0]~4_combout\ = (\inst9|LessThan0~0_combout\ & (\inst9|Add1~2_combout\)) # (!\inst9|LessThan0~0_combout\ & ((\inst9|Add2~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Add1~2_combout\,
	datab => \inst9|Add2~10_combout\,
	datad => \inst9|LessThan0~0_combout\,
	combout => \inst9|Alu_out[0]~4_combout\);

\inst9|LessThan1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|LessThan1~0_combout\ = (!\inst40|Mux0~0_combout\ & ((\inst40|Mux1~0_combout\ & (\inst|WideOr6~combout\ & \inst40|Mux2~0_combout\)) # (!\inst40|Mux1~0_combout\ & (!\inst|WideOr6~combout\ & !\inst40|Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux1~0_combout\,
	datab => \inst|WideOr6~combout\,
	datac => \inst40|Mux2~0_combout\,
	datad => \inst40|Mux0~0_combout\,
	combout => \inst9|LessThan1~0_combout\);

\inst9|LessThan1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|LessThan1~1_combout\ = (\inst|WideOr6~combout\ & (!\inst40|Mux0~0_combout\ & ((!\inst40|Mux2~0_combout\) # (!\inst40|Mux1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr6~combout\,
	datab => \inst40|Mux1~0_combout\,
	datac => \inst40|Mux2~0_combout\,
	datad => \inst40|Mux0~0_combout\,
	combout => \inst9|LessThan1~1_combout\);

\inst9|Temp[5]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Temp[5]~0_combout\ = (!\inst9|LessThan1~0_combout\ & (!\inst9|LessThan1~1_combout\ & !\inst9|LessThan0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|LessThan1~0_combout\,
	datac => \inst9|LessThan1~1_combout\,
	datad => \inst9|LessThan0~0_combout\,
	combout => \inst9|Temp[5]~0_combout\);

\inst9|Alu_out[0]_117\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[0]_117~combout\ = (\inst9|Temp[5]~0_combout\ & ((\inst9|Alu_out[0]_117~combout\))) # (!\inst9|Temp[5]~0_combout\ & (\inst9|Alu_out[0]~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|Alu_out[0]~4_combout\,
	datac => \inst9|Alu_out[0]_117~combout\,
	datad => \inst9|Temp[5]~0_combout\,
	combout => \inst9|Alu_out[0]_117~combout\);

\inst9|Mux6~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux6~4_combout\ = (\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ $ (((\inst40|Mux3~1_combout\))))) # (!\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ & (\inst9|Alu_out[0]_117~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datab => \inst9|Alu_out[0]_117~combout\,
	datac => \inst|WideOr4~1_combout\,
	datad => \inst40|Mux3~1_combout\,
	combout => \inst9|Mux6~4_combout\);

\inst9|Mux6~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux6~5_combout\ = (\inst9|Mux6~4_combout\) # ((!\inst|WideOr4~1_combout\ & (!\inst|WideOr12~0_combout\ & \inst9|Add0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr4~1_combout\,
	datab => \inst|WideOr12~0_combout\,
	datac => \inst9|Add0~2_combout\,
	datad => \inst9|Mux6~4_combout\,
	combout => \inst9|Mux6~5_combout\);

\inst8|R_out[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux6~5_combout\,
	ena => \inst|WideOr14~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst8|R_out\(0));

\inst13|R_out[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux6~5_combout\,
	ena => \inst|WideOr13~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst13|R_out\(0));

\inst40|Mux3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst40|Mux3~1_combout\ = (\inst|WideOr9~combout\ & ((\inst13|R_out\(0)) # ((\inst40|Mux3~0_combout\ & \inst8|R_out\(0))))) # (!\inst|WideOr9~combout\ & (\inst40|Mux3~0_combout\ & (\inst8|R_out\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr9~combout\,
	datab => \inst40|Mux3~0_combout\,
	datac => \inst8|R_out\(0),
	datad => \inst13|R_out\(0),
	combout => \inst40|Mux3~1_combout\);

\inst9|Add0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add0~4_combout\ = (\inst40|Mux2~0_combout\ & ((\inst|WideOr6~combout\ & (\inst9|Add0~3\ & VCC)) # (!\inst|WideOr6~combout\ & (!\inst9|Add0~3\)))) # (!\inst40|Mux2~0_combout\ & ((\inst|WideOr6~combout\ & (!\inst9|Add0~3\)) # (!\inst|WideOr6~combout\ 
-- & ((\inst9|Add0~3\) # (GND)))))
-- \inst9|Add0~5\ = CARRY((\inst40|Mux2~0_combout\ & (!\inst|WideOr6~combout\ & !\inst9|Add0~3\)) # (!\inst40|Mux2~0_combout\ & ((!\inst9|Add0~3\) # (!\inst|WideOr6~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux2~0_combout\,
	datab => \inst|WideOr6~combout\,
	datad => VCC,
	cin => \inst9|Add0~3\,
	combout => \inst9|Add0~4_combout\,
	cout => \inst9|Add0~5\);

\inst9|Add2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add2~2_combout\ = (\inst40|Mux2~0_combout\ & (\inst|WideOr6~combout\ $ (VCC))) # (!\inst40|Mux2~0_combout\ & ((\inst|WideOr6~combout\) # (GND)))
-- \inst9|Add2~3\ = CARRY((\inst|WideOr6~combout\) # (!\inst40|Mux2~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011011011101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux2~0_combout\,
	datab => \inst|WideOr6~combout\,
	datad => VCC,
	combout => \inst9|Add2~2_combout\,
	cout => \inst9|Add2~3\);

\inst9|Add1~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add1~4_combout\ = (\inst40|Mux2~0_combout\ & ((\inst|WideOr6~combout\ & (!\inst9|Add1~3\)) # (!\inst|WideOr6~combout\ & (\inst9|Add1~3\ & VCC)))) # (!\inst40|Mux2~0_combout\ & ((\inst|WideOr6~combout\ & ((\inst9|Add1~3\) # (GND))) # 
-- (!\inst|WideOr6~combout\ & (!\inst9|Add1~3\))))
-- \inst9|Add1~5\ = CARRY((\inst40|Mux2~0_combout\ & (\inst|WideOr6~combout\ & !\inst9|Add1~3\)) # (!\inst40|Mux2~0_combout\ & ((\inst|WideOr6~combout\) # (!\inst9|Add1~3\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100101001101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux2~0_combout\,
	datab => \inst|WideOr6~combout\,
	datad => VCC,
	cin => \inst9|Add1~3\,
	combout => \inst9|Add1~4_combout\,
	cout => \inst9|Add1~5\);

\inst9|Alu_out[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[1]~0_combout\ = (!\inst9|LessThan0~0_combout\ & ((!\inst9|LessThan1~0_combout\) # (!\inst40|Mux3~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst40|Mux3~1_combout\,
	datac => \inst9|LessThan1~0_combout\,
	datad => \inst9|LessThan0~0_combout\,
	combout => \inst9|Alu_out[1]~0_combout\);

\inst9|Alu_out[1]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[1]~3_combout\ = (\inst9|Add2~2_combout\ & ((\inst9|Alu_out[1]~0_combout\) # ((\inst9|LessThan0~0_combout\ & \inst9|Add1~4_combout\)))) # (!\inst9|Add2~2_combout\ & (\inst9|LessThan0~0_combout\ & (\inst9|Add1~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Add2~2_combout\,
	datab => \inst9|LessThan0~0_combout\,
	datac => \inst9|Add1~4_combout\,
	datad => \inst9|Alu_out[1]~0_combout\,
	combout => \inst9|Alu_out[1]~3_combout\);

\inst9|Alu_out[1]_127\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[1]_127~combout\ = (\inst9|Temp[5]~0_combout\ & ((\inst9|Alu_out[1]_127~combout\))) # (!\inst9|Temp[5]~0_combout\ & (\inst9|Alu_out[1]~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|Alu_out[1]~3_combout\,
	datac => \inst9|Alu_out[1]_127~combout\,
	datad => \inst9|Temp[5]~0_combout\,
	combout => \inst9|Alu_out[1]_127~combout\);

\inst9|Mux5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux5~4_combout\ = (\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ $ (((\inst40|Mux2~0_combout\))))) # (!\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ & (\inst9|Alu_out[1]_127~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datab => \inst9|Alu_out[1]_127~combout\,
	datac => \inst|WideOr4~1_combout\,
	datad => \inst40|Mux2~0_combout\,
	combout => \inst9|Mux5~4_combout\);

\inst9|Mux5~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux5~5_combout\ = (\inst9|Mux5~4_combout\) # ((!\inst|WideOr4~1_combout\ & (!\inst|WideOr12~0_combout\ & \inst9|Add0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr4~1_combout\,
	datab => \inst|WideOr12~0_combout\,
	datac => \inst9|Add0~4_combout\,
	datad => \inst9|Mux5~4_combout\,
	combout => \inst9|Mux5~5_combout\);

\inst8|R_out[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux5~5_combout\,
	ena => \inst|WideOr14~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst8|R_out\(1));

\inst13|R_out[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux5~5_combout\,
	ena => \inst|WideOr13~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst13|R_out\(1));

\inst40|Mux2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst40|Mux2~0_combout\ = (\inst|WideOr9~combout\ & ((\inst13|R_out\(1)) # ((\inst40|Mux3~0_combout\ & \inst8|R_out\(1))))) # (!\inst|WideOr9~combout\ & (\inst40|Mux3~0_combout\ & (\inst8|R_out\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr9~combout\,
	datab => \inst40|Mux3~0_combout\,
	datac => \inst8|R_out\(1),
	datad => \inst13|R_out\(1),
	combout => \inst40|Mux2~0_combout\);

\inst9|Add0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add0~6_combout\ = ((\inst40|Mux1~0_combout\ $ (\inst|WideOr6~combout\ $ (!\inst9|Add0~5\)))) # (GND)
-- \inst9|Add0~7\ = CARRY((\inst40|Mux1~0_combout\ & ((\inst|WideOr6~combout\) # (!\inst9|Add0~5\))) # (!\inst40|Mux1~0_combout\ & (\inst|WideOr6~combout\ & !\inst9|Add0~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux1~0_combout\,
	datab => \inst|WideOr6~combout\,
	datad => VCC,
	cin => \inst9|Add0~5\,
	combout => \inst9|Add0~6_combout\,
	cout => \inst9|Add0~7\);

\inst9|Add2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add2~4_combout\ = (\inst40|Mux1~0_combout\ & ((\inst|WideOr6~combout\ & (!\inst9|Add2~3\)) # (!\inst|WideOr6~combout\ & ((\inst9|Add2~3\) # (GND))))) # (!\inst40|Mux1~0_combout\ & ((\inst|WideOr6~combout\ & (\inst9|Add2~3\ & VCC)) # 
-- (!\inst|WideOr6~combout\ & (!\inst9|Add2~3\))))
-- \inst9|Add2~5\ = CARRY((\inst40|Mux1~0_combout\ & ((!\inst9|Add2~3\) # (!\inst|WideOr6~combout\))) # (!\inst40|Mux1~0_combout\ & (!\inst|WideOr6~combout\ & !\inst9|Add2~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100100101011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux1~0_combout\,
	datab => \inst|WideOr6~combout\,
	datad => VCC,
	cin => \inst9|Add2~3\,
	combout => \inst9|Add2~4_combout\,
	cout => \inst9|Add2~5\);

\inst9|Add1~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add1~6_combout\ = ((\inst40|Mux1~0_combout\ $ (\inst|WideOr6~combout\ $ (\inst9|Add1~5\)))) # (GND)
-- \inst9|Add1~7\ = CARRY((\inst40|Mux1~0_combout\ & ((!\inst9|Add1~5\) # (!\inst|WideOr6~combout\))) # (!\inst40|Mux1~0_combout\ & (!\inst|WideOr6~combout\ & !\inst9|Add1~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000101011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux1~0_combout\,
	datab => \inst|WideOr6~combout\,
	datad => VCC,
	cin => \inst9|Add1~5\,
	combout => \inst9|Add1~6_combout\,
	cout => \inst9|Add1~7\);

\inst9|Alu_out[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[2]~2_combout\ = (\inst9|Add2~4_combout\ & ((\inst9|Alu_out[1]~0_combout\) # ((\inst9|LessThan0~0_combout\ & \inst9|Add1~6_combout\)))) # (!\inst9|Add2~4_combout\ & (\inst9|LessThan0~0_combout\ & (\inst9|Add1~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Add2~4_combout\,
	datab => \inst9|LessThan0~0_combout\,
	datac => \inst9|Add1~6_combout\,
	datad => \inst9|Alu_out[1]~0_combout\,
	combout => \inst9|Alu_out[2]~2_combout\);

\inst9|Alu_out[2]_137\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[2]_137~combout\ = (\inst9|Temp[5]~0_combout\ & ((\inst9|Alu_out[2]_137~combout\))) # (!\inst9|Temp[5]~0_combout\ & (\inst9|Alu_out[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|Alu_out[2]~2_combout\,
	datac => \inst9|Alu_out[2]_137~combout\,
	datad => \inst9|Temp[5]~0_combout\,
	combout => \inst9|Alu_out[2]_137~combout\);

\inst9|Mux4~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux4~4_combout\ = (\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ $ (((\inst40|Mux1~0_combout\))))) # (!\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ & (\inst9|Alu_out[2]_137~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datab => \inst9|Alu_out[2]_137~combout\,
	datac => \inst|WideOr4~1_combout\,
	datad => \inst40|Mux1~0_combout\,
	combout => \inst9|Mux4~4_combout\);

\inst9|Mux4~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux4~5_combout\ = (\inst9|Mux4~4_combout\) # ((!\inst|WideOr4~1_combout\ & (!\inst|WideOr12~0_combout\ & \inst9|Add0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr4~1_combout\,
	datab => \inst|WideOr12~0_combout\,
	datac => \inst9|Add0~6_combout\,
	datad => \inst9|Mux4~4_combout\,
	combout => \inst9|Mux4~5_combout\);

\inst13|R_out[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst9|Mux4~5_combout\,
	ena => \inst|WideOr13~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst13|R_out\(2));

\inst|E~27\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~27_combout\ = (!\inst13|R_out\(3) & (!\inst13|R_out\(2) & (!\inst13|R_out\(1) & !\inst13|R_out\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst13|R_out\(3),
	datab => \inst13|R_out\(2),
	datac => \inst13|R_out\(1),
	datad => \inst13|R_out\(0),
	combout => \inst|E~27_combout\);

\inst9|LessThan1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|LessThan1~2_combout\ = (\inst9|LessThan1~1_combout\) # ((\inst9|LessThan1~0_combout\ & !\inst40|Mux3~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|LessThan1~1_combout\,
	datab => \inst9|LessThan1~0_combout\,
	datad => \inst40|Mux3~1_combout\,
	combout => \inst9|LessThan1~2_combout\);

\inst9|Mux8~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux8~2_combout\ = ((\inst|WideOr4~1_combout\) # ((\inst9|LessThan1~2_combout\) # (!\inst9|Alu_out[1]~0_combout\))) # (!\inst|WideOr12~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datab => \inst|WideOr4~1_combout\,
	datac => \inst9|LessThan1~2_combout\,
	datad => \inst9|Alu_out[1]~0_combout\,
	combout => \inst9|Mux8~2_combout\);

\inst9|Temp[5]\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Temp\(5) = (\inst9|Mux8~2_combout\ & (\inst9|Mux2~7_combout\)) # (!\inst9|Mux8~2_combout\ & ((\inst9|Temp\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|Mux2~7_combout\,
	datac => \inst9|Temp\(5),
	datad => \inst9|Mux8~2_combout\,
	combout => \inst9|Temp\(5));

\inst|E~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~28_combout\ = (\inst|E.SUB_Y~q\ & (\inst|E~27_combout\ & ((\inst9|LessThan1~2_combout\) # (\inst9|Temp\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_Y~q\,
	datab => \inst|E~27_combout\,
	datac => \inst9|LessThan1~2_combout\,
	datad => \inst9|Temp\(5),
	combout => \inst|E~28_combout\);

\inst|E.LIM_MIN\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~28_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.LIM_MIN~q\);

\inst|WideOr4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr4~0_combout\ = (\inst|E.ZERA_TC~q\) # ((\inst|E.LIM_MIN~q\) # ((\inst|E.AGD_VAL~q\) # (!\inst|E.ZERA_RG~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.ZERA_TC~q\,
	datab => \inst|E.LIM_MIN~q\,
	datac => \inst|E.AGD_VAL~q\,
	datad => \inst|E.ZERA_RG~q\,
	combout => \inst|WideOr4~0_combout\);

\inst|WideOr4~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr4~1_combout\ = (\inst|E.VER_TC~q\) # ((\inst|WideOr4~0_combout\) # ((\inst|E.ZERA_TV~q\) # (\inst|E.AGD_TM~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.VER_TC~q\,
	datab => \inst|WideOr4~0_combout\,
	datac => \inst|E.ZERA_TV~q\,
	datad => \inst|E.AGD_TM~q\,
	combout => \inst|WideOr4~1_combout\);

\inst9|Add0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add0~8_combout\ = (\inst40|Mux0~0_combout\ & (!\inst9|Add0~7\)) # (!\inst40|Mux0~0_combout\ & ((\inst9|Add0~7\) # (GND)))
-- \inst9|Add0~9\ = CARRY((!\inst9|Add0~7\) # (!\inst40|Mux0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux0~0_combout\,
	datad => VCC,
	cin => \inst9|Add0~7\,
	combout => \inst9|Add0~8_combout\,
	cout => \inst9|Add0~9\);

\inst9|Add2~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add2~6_combout\ = (\inst40|Mux0~0_combout\ & (!\inst9|Add2~5\ & VCC)) # (!\inst40|Mux0~0_combout\ & (\inst9|Add2~5\ $ (GND)))
-- \inst9|Add2~7\ = CARRY((!\inst40|Mux0~0_combout\ & !\inst9|Add2~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux0~0_combout\,
	datad => VCC,
	cin => \inst9|Add2~5\,
	combout => \inst9|Add2~6_combout\,
	cout => \inst9|Add2~7\);

\inst9|Add1~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add1~8_combout\ = (\inst40|Mux0~0_combout\ & (\inst9|Add1~7\ & VCC)) # (!\inst40|Mux0~0_combout\ & (!\inst9|Add1~7\))
-- \inst9|Add1~9\ = CARRY((!\inst40|Mux0~0_combout\ & !\inst9|Add1~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \inst40|Mux0~0_combout\,
	datad => VCC,
	cin => \inst9|Add1~7\,
	combout => \inst9|Add1~8_combout\,
	cout => \inst9|Add1~9\);

\inst9|Alu_out[3]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[3]~1_combout\ = (\inst9|Add2~6_combout\ & ((\inst9|Alu_out[1]~0_combout\) # ((\inst9|LessThan0~0_combout\ & \inst9|Add1~8_combout\)))) # (!\inst9|Add2~6_combout\ & (\inst9|LessThan0~0_combout\ & (\inst9|Add1~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Add2~6_combout\,
	datab => \inst9|LessThan0~0_combout\,
	datac => \inst9|Add1~8_combout\,
	datad => \inst9|Alu_out[1]~0_combout\,
	combout => \inst9|Alu_out[3]~1_combout\);

\inst9|Alu_out[3]_147\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Alu_out[3]_147~combout\ = (\inst9|Temp[5]~0_combout\ & ((\inst9|Alu_out[3]_147~combout\))) # (!\inst9|Temp[5]~0_combout\ & (\inst9|Alu_out[3]~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|Alu_out[3]~1_combout\,
	datac => \inst9|Alu_out[3]_147~combout\,
	datad => \inst9|Temp[5]~0_combout\,
	combout => \inst9|Alu_out[3]_147~combout\);

\inst9|Mux3~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux3~5_combout\ = (\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ $ (((\inst40|Mux0~0_combout\))))) # (!\inst|WideOr4~1_combout\ & (\inst|WideOr12~0_combout\ & (\inst9|Alu_out[3]_147~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datab => \inst9|Alu_out[3]_147~combout\,
	datac => \inst|WideOr4~1_combout\,
	datad => \inst40|Mux0~0_combout\,
	combout => \inst9|Mux3~5_combout\);

\inst9|Mux3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux3~6_combout\ = (\inst9|Mux3~5_combout\) # ((!\inst|WideOr4~1_combout\ & (!\inst|WideOr12~0_combout\ & \inst9|Add0~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr4~1_combout\,
	datab => \inst|WideOr12~0_combout\,
	datac => \inst9|Add0~8_combout\,
	datad => \inst9|Mux3~5_combout\,
	combout => \inst9|Mux3~6_combout\);

\inst9|Equal1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Equal1~0_combout\ = (!\inst9|Mux3~6_combout\ & (!\inst9|Mux4~5_combout\ & (!\inst9|Mux5~5_combout\ & !\inst9|Mux6~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux3~6_combout\,
	datab => \inst9|Mux4~5_combout\,
	datac => \inst9|Mux5~5_combout\,
	datad => \inst9|Mux6~5_combout\,
	combout => \inst9|Equal1~0_combout\);

\inst9|Add2~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add2~8_combout\ = !\inst9|Add2~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \inst9|Add2~7\,
	combout => \inst9|Add2~8_combout\);

\inst9|Add0~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add0~10_combout\ = !\inst9|Add0~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \inst9|Add0~9\,
	combout => \inst9|Add0~10_combout\);

\inst9|Mux2~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux2~11_combout\ = (!\inst|WideOr4~1_combout\ & (!\inst|WideOr12~0_combout\ & \inst9|Add0~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr4~1_combout\,
	datab => \inst|WideOr12~0_combout\,
	datac => \inst9|Add0~10_combout\,
	combout => \inst9|Mux2~11_combout\);

\inst9|Add1~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Add1~10_combout\ = \inst9|Add1~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \inst9|Add1~9\,
	combout => \inst9|Add1~10_combout\);

\inst9|Mux2~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux2~10_combout\ = (\inst|WideOr12~0_combout\ & (!\inst|WideOr4~1_combout\ & (\inst9|LessThan0~0_combout\ & \inst9|Add1~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datab => \inst|WideOr4~1_combout\,
	datac => \inst9|LessThan0~0_combout\,
	datad => \inst9|Add1~10_combout\,
	combout => \inst9|Mux2~10_combout\);

\inst9|Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux0~0_combout\ = (\inst9|Mux2~11_combout\) # ((\inst9|Mux2~10_combout\) # ((\inst9|Add2~8_combout\ & \inst9|Mux2~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux2~11_combout\,
	datab => \inst9|Mux2~10_combout\,
	datac => \inst9|Add2~8_combout\,
	datad => \inst9|Mux2~7_combout\,
	combout => \inst9|Mux0~0_combout\);

\inst9|Temp[4]\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Temp\(4) = (\inst9|Mux8~2_combout\ & (\inst9|Mux0~0_combout\)) # (!\inst9|Mux8~2_combout\ & ((\inst9|Temp\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst9|Mux0~0_combout\,
	datac => \inst9|Temp\(4),
	datad => \inst9|Mux8~2_combout\,
	combout => \inst9|Temp\(4));

\inst9|Equal1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Equal1~1_combout\ = (\inst9|LessThan1~2_combout\ & (\inst9|Add2~8_combout\)) # (!\inst9|LessThan1~2_combout\ & ((\inst9|Temp\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|LessThan1~2_combout\,
	datab => \inst9|Add2~8_combout\,
	datac => \inst9|Temp\(4),
	combout => \inst9|Equal1~1_combout\);

\inst9|Equal1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Equal1~2_combout\ = (\inst9|Mux1~0_combout\) # ((\inst9|Mux2~11_combout\) # (\inst9|Mux2~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux1~0_combout\,
	datab => \inst9|Mux2~11_combout\,
	datac => \inst9|Mux2~10_combout\,
	combout => \inst9|Equal1~2_combout\);

\inst9|Equal1~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Equal1~3_combout\ = (\inst9|Equal1~0_combout\ & (!\inst9|Equal1~2_combout\ & ((!\inst9|Equal1~1_combout\) # (!\inst9|Mux2~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux2~7_combout\,
	datab => \inst9|Equal1~0_combout\,
	datac => \inst9|Equal1~1_combout\,
	datad => \inst9|Equal1~2_combout\,
	combout => \inst9|Equal1~3_combout\);

\inst|Selector1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|Selector1~0_combout\ = (\inst|E.AGD_TM~q\ & (((!\inst|WideOr16~1_combout\ & !\inst9|Equal1~3_combout\)) # (!\inst10|TM~q\))) # (!\inst|E.AGD_TM~q\ & (!\inst|WideOr16~1_combout\ & (!\inst9|Equal1~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001110101011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.AGD_TM~q\,
	datab => \inst|WideOr16~1_combout\,
	datac => \inst9|Equal1~3_combout\,
	datad => \inst10|TM~q\,
	combout => \inst|Selector1~0_combout\);

\inst|E.AGD_TM\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|Selector1~0_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.AGD_TM~q\);

\inst|E~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~22_combout\ = (\inst|E.AGD_TM~q\ & \inst10|TM~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.AGD_TM~q\,
	datab => \inst10|TM~q\,
	combout => \inst|E~22_combout\);

\inst|E.SUB_TC\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~22_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.SUB_TC~q\);

\inst|WideOr12~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr12~0_combout\ = (\inst|E.SUB_TV~q\) # ((\inst|E.SUB_TC~q\) # ((\inst|E.SUB_Y~q\) # (\inst|E.VER_MAX~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_TV~q\,
	datab => \inst|E.SUB_TC~q\,
	datac => \inst|E.SUB_Y~q\,
	datad => \inst|E.VER_MAX~q\,
	combout => \inst|WideOr12~0_combout\);

\inst9|Mux2~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux2~6_combout\ = (\inst|WideOr12~0_combout\ & !\inst|WideOr4~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr12~0_combout\,
	datad => \inst|WideOr4~1_combout\,
	combout => \inst9|Mux2~6_combout\);

\inst9|Mux2~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux2~7_combout\ = (\inst9|Mux2~6_combout\ & (!\inst9|LessThan0~0_combout\ & ((!\inst9|LessThan1~0_combout\) # (!\inst40|Mux3~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux2~6_combout\,
	datab => \inst40|Mux3~1_combout\,
	datac => \inst9|LessThan1~0_combout\,
	datad => \inst9|LessThan0~0_combout\,
	combout => \inst9|Mux2~7_combout\);

\inst9|Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux1~0_combout\ = (\inst9|Mux2~7_combout\ & ((\inst9|LessThan1~2_combout\) # (\inst9|Temp\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux2~7_combout\,
	datab => \inst9|LessThan1~2_combout\,
	datac => \inst9|Temp\(5),
	combout => \inst9|Mux1~0_combout\);

\inst9|PO~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|PO~0_combout\ = (\inst13|R_out\(3)) # ((\inst13|R_out\(2) & (\inst13|R_out\(1) & \inst13|R_out\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst13|R_out\(3),
	datab => \inst13|R_out\(2),
	datac => \inst13|R_out\(1),
	datad => \inst13|R_out\(0),
	combout => \inst9|PO~0_combout\);

\inst9|PO~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|PO~1_combout\ = (!\inst9|Alu_out[3]_147~combout\ & (!\inst9|Alu_out[2]_137~combout\ & (!\inst9|Alu_out[1]_127~combout\ & !\inst9|Alu_out[0]_117~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Alu_out[3]_147~combout\,
	datab => \inst9|Alu_out[2]_137~combout\,
	datac => \inst9|Alu_out[1]_127~combout\,
	datad => \inst9|Alu_out[0]_117~combout\,
	combout => \inst9|PO~1_combout\);

\inst|E~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~26_combout\ = (!\inst9|Mux1~0_combout\ & (\inst|E.VER_MAX~q\ & ((!\inst9|PO~1_combout\) # (!\inst9|PO~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux1~0_combout\,
	datab => \inst9|PO~0_combout\,
	datac => \inst9|PO~1_combout\,
	datad => \inst|E.VER_MAX~q\,
	combout => \inst|E~26_combout\);

\inst|E.LIM_MAX\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~26_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.LIM_MAX~q\);

\inst|Selector0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|Selector0~0_combout\ = (\inst|E~23_combout\ & (((!\IT~input_o\ & !\DT~input_o\)) # (!\CC~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E~23_combout\,
	datab => \IT~input_o\,
	datac => \DT~input_o\,
	datad => \CC~input_o\,
	combout => \inst|Selector0~0_combout\);

\inst|Selector0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|Selector0~1_combout\ = (\inst|E.CAR_TV~q\) # ((\inst|E.LIM_MAX~q\) # ((\inst|E.LIM_MIN~q\) # (\inst|Selector0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.CAR_TV~q\,
	datab => \inst|E.LIM_MAX~q\,
	datac => \inst|E.LIM_MIN~q\,
	datad => \inst|Selector0~0_combout\,
	combout => \inst|Selector0~1_combout\);

\inst|Selector0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|Selector0~2_combout\ = (\inst|Selector0~1_combout\) # ((\inst|E.SUB_TV~q\ & !\inst9|Equal1~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|Selector0~1_combout\,
	datab => \inst|E.SUB_TV~q\,
	datac => \inst9|Equal1~3_combout\,
	combout => \inst|Selector0~2_combout\);

\inst9|Mux3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux3~4_combout\ = (!\inst|WideOr4~1_combout\ & !\inst|WideOr12~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst|WideOr4~1_combout\,
	datad => \inst|WideOr12~0_combout\,
	combout => \inst9|Mux3~4_combout\);

\inst9|Mux2~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux2~8_combout\ = (\inst9|Mux2~7_combout\ & ((\inst9|LessThan1~2_combout\ & ((\inst9|Add2~8_combout\))) # (!\inst9|LessThan1~2_combout\ & (\inst9|Temp\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux2~7_combout\,
	datab => \inst9|Temp\(4),
	datac => \inst9|LessThan1~2_combout\,
	datad => \inst9|Add2~8_combout\,
	combout => \inst9|Mux2~8_combout\);

\inst9|Mux2~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst9|Mux2~9_combout\ = (\inst9|Mux2~8_combout\) # ((\inst9|Mux2~10_combout\) # ((\inst9|Mux3~4_combout\ & \inst9|Add0~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst9|Mux3~4_combout\,
	datab => \inst9|Add0~10_combout\,
	datac => \inst9|Mux2~8_combout\,
	datad => \inst9|Mux2~10_combout\,
	combout => \inst9|Mux2~9_combout\);

\inst|Selector0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|Selector0~3_combout\ = (\inst9|Mux2~9_combout\ & (\inst|E.VER_MAX~q\)) # (!\inst9|Mux2~9_combout\ & ((\inst9|Mux1~0_combout\) # ((\inst|E.VER_MAX~q\ & \inst9|Equal1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.VER_MAX~q\,
	datab => \inst9|Mux2~9_combout\,
	datac => \inst9|Equal1~0_combout\,
	datad => \inst9|Mux1~0_combout\,
	combout => \inst|Selector0~3_combout\);

\inst|Selector0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|Selector0~4_combout\ = (\inst|Selector0~2_combout\) # ((\inst|Selector0~3_combout\ & ((\inst|E.VER_MAX~q\))) # (!\inst|Selector0~3_combout\ & (\inst|E.SUB_Y~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_Y~q\,
	datab => \inst|Selector0~2_combout\,
	datac => \inst|E.VER_MAX~q\,
	datad => \inst|Selector0~3_combout\,
	combout => \inst|Selector0~4_combout\);

\inst|E.AGD_VAL\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|Selector0~4_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.AGD_VAL~q\);

\inst|E~21\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~21_combout\ = (\inst|E.AGD_VAL~q\ & \inst10|TM~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.AGD_VAL~q\,
	datab => \inst10|TM~q\,
	combout => \inst|E~21_combout\);

\inst|E.SUB_TV\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~21_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.SUB_TV~q\);

\inst|E~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|E~20_combout\ = (\inst|E.SUB_TV~q\ & (\inst9|Equal1~0_combout\ & (!\inst9|Mux2~9_combout\ & !\inst9|Mux1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.SUB_TV~q\,
	datab => \inst9|Equal1~0_combout\,
	datac => \inst9|Mux2~9_combout\,
	datad => \inst9|Mux1~0_combout\,
	combout => \inst|E~20_combout\);

\inst|E.ZERA_TC\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst|E~20_combout\,
	clrn => \SP~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|E.ZERA_TC~q\);

\inst|WideOr16~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr16~0_combout\ = (\inst|E.ZERA_TC~q\) # ((\inst|E.CAR_TV~q\) # ((\inst|E.SUB_TV~q\) # (!\inst|E.ZERA_RG~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.ZERA_TC~q\,
	datab => \inst|E.CAR_TV~q\,
	datac => \inst|E.SUB_TV~q\,
	datad => \inst|E.ZERA_RG~q\,
	combout => \inst|WideOr16~0_combout\);

\inst|WideOr16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr16~combout\ = (\inst|WideOr16~0_combout\) # ((\inst|E.VAG_OCP~q\) # ((\inst|E.MULTA~q\) # (!\inst|WideOr16~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|WideOr16~0_combout\,
	datab => \inst|E.VAG_OCP~q\,
	datac => \inst|E.MULTA~q\,
	datad => \inst|WideOr16~1_combout\,
	combout => \inst|WideOr16~combout\);

\inst|WideOr15\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst|WideOr15~combout\ = (\inst|E.VAG_OCP~q\) # ((\inst|E.MULTA~q\) # (!\inst|E.ZERA_RG~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|E.VAG_OCP~q\,
	datab => \inst|E.MULTA~q\,
	datad => \inst|E.ZERA_RG~q\,
	combout => \inst|WideOr15~combout\);

ww_RT <= \RT~output_o\;

ww_LDC <= \LDC~output_o\;

ww_ALU(3) <= \ALU[3]~output_o\;

ww_ALU(2) <= \ALU[2]~output_o\;

ww_ALU(1) <= \ALU[1]~output_o\;

ww_ALU(0) <= \ALU[0]~output_o\;

ww_LDB <= \LDB~output_o\;

ww_TM <= \TM~output_o\;

ww_MT <= \MT~output_o\;

ww_LDA <= \LDA~output_o\;

ww_DP(3) <= \DP[3]~output_o\;

ww_DP(2) <= \DP[2]~output_o\;

ww_DP(1) <= \DP[1]~output_o\;

ww_DP(0) <= \DP[0]~output_o\;

ww_TC(3) <= \TC[3]~output_o\;

ww_TC(2) <= \TC[2]~output_o\;

ww_TC(1) <= \TC[1]~output_o\;

ww_TC(0) <= \TC[0]~output_o\;

ww_TV(3) <= \TV[3]~output_o\;

ww_TV(2) <= \TV[2]~output_o\;

ww_TV(1) <= \TV[1]~output_o\;

ww_TV(0) <= \TV[0]~output_o\;
END structure;


