-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "11/05/2025 14:52:34"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          Parquimetro
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY Parquimetro_vhd_vec_tst IS
END Parquimetro_vhd_vec_tst;
ARCHITECTURE Parquimetro_arch OF Parquimetro_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL ALU : STD_LOGIC_VECTOR(3 DOWNTO 0);
SIGNAL CC : STD_LOGIC;
SIGNAL CK : STD_LOGIC;
SIGNAL DP : STD_LOGIC_VECTOR(3 DOWNTO 0);
SIGNAL DT : STD_LOGIC;
SIGNAL IT : STD_LOGIC;
SIGNAL LDA : STD_LOGIC;
SIGNAL LDB : STD_LOGIC;
SIGNAL LDC : STD_LOGIC;
SIGNAL MT : STD_LOGIC;
SIGNAL RT : STD_LOGIC;
SIGNAL SP : STD_LOGIC;
SIGNAL TC : STD_LOGIC_VECTOR(3 DOWNTO 0);
SIGNAL TM : STD_LOGIC;
SIGNAL TV : STD_LOGIC_VECTOR(3 DOWNTO 0);
SIGNAL VC : STD_LOGIC;
COMPONENT Parquimetro
	PORT (
	ALU : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
	CC : IN STD_LOGIC;
	CK : IN STD_LOGIC;
	DP : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
	DT : IN STD_LOGIC;
	IT : IN STD_LOGIC;
	LDA : OUT STD_LOGIC;
	LDB : OUT STD_LOGIC;
	LDC : OUT STD_LOGIC;
	MT : OUT STD_LOGIC;
	RT : OUT STD_LOGIC;
	SP : IN STD_LOGIC;
	TC : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
	TM : OUT STD_LOGIC;
	TV : OUT STD_LOGIC_VECTOR(3 DOWNTO 0);
	VC : IN STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : Parquimetro
	PORT MAP (
-- list connections between master ports and signals
	ALU => ALU,
	CC => CC,
	CK => CK,
	DP => DP,
	DT => DT,
	IT => IT,
	LDA => LDA,
	LDB => LDB,
	LDC => LDC,
	MT => MT,
	RT => RT,
	SP => SP,
	TC => TC,
	TM => TM,
	TV => TV,
	VC => VC
	);

-- CK
t_prcs_CK: PROCESS
BEGIN
LOOP
	CK <= '0';
	WAIT FOR 5000 ps;
	CK <= '1';
	WAIT FOR 5000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_CK;

-- SP
t_prcs_SP: PROCESS
BEGIN
	SP <= '0';
	WAIT FOR 10000 ps;
	SP <= '1';
	WAIT FOR 940000 ps;
	SP <= '0';
WAIT;
END PROCESS t_prcs_SP;

-- CC
t_prcs_CC: PROCESS
BEGIN
	CC <= '0';
	WAIT FOR 20000 ps;
	CC <= '1';
	WAIT FOR 800000 ps;
	CC <= '0';
WAIT;
END PROCESS t_prcs_CC;

-- IT
t_prcs_IT: PROCESS
BEGIN
	IT <= '0';
	WAIT FOR 180000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
	WAIT FOR 20000 ps;
	IT <= '1';
	WAIT FOR 10000 ps;
	IT <= '0';
WAIT;
END PROCESS t_prcs_IT;

-- DT
t_prcs_DT: PROCESS
BEGIN
	DT <= '0';
	WAIT FOR 60000 ps;
	DT <= '1';
	WAIT FOR 10000 ps;
	DT <= '0';
	WAIT FOR 30000 ps;
	DT <= '1';
	WAIT FOR 10000 ps;
	DT <= '0';
WAIT;
END PROCESS t_prcs_DT;

-- VC
t_prcs_VC: PROCESS
BEGIN
	VC <= '0';
WAIT;
END PROCESS t_prcs_VC;
END Parquimetro_arch;
