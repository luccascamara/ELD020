--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Multiplexador de 4 vias de 4 bits => MUX.vhd
-- Rev. 0
-- Especificacoes: Entradas: Da[3..0], Db[3..0], Dc[3..0], Dd[3..0], S[1..0]
--				   	 Saidas : Mx_out[3..0]
-- MUX seleciona um dos quatro vetores de entradas em funcao do codigo de S:
--			S=00 => seleciona Da
--			S=01 => seleciona Db
--			S=10 => seleciona Dc
--			S=11 => seleciona Dd
-- MUX eh um seletor assincrono. 
--********************************************************************************
library ieee;
use ieee.std_logic_1164.all;
entity MUX_B is
	port( Da		: in std_logic_vector(3 downto 0);
		  Db		: in std_logic_vector(3 downto 0);
		  Dc		: in std_logic_vector(3 downto 0);
		  S			: in std_logic_vector(1 downto 0);
		  Mx_out	: out std_logic_vector(3 downto 0)
);
end MUX_B;
architecture comportamental of MUX_B is
begin
process(Da, Db, Dc,S)
begin
case S is
	when "00" => Mx_out <= Da;
	when "01" => Mx_out <= Db;
	when "10" => Mx_out <= Dc;
	when "11" => Mx_out <= "0000";
	when others => null;
end case;
end process;
end comportamental;