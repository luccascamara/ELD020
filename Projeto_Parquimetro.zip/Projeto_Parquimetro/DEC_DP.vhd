--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Decodificador BCD- Didplay de 7 Segmentos => DEC.vhd
-- Rev. 0
-- Especificacoes: Entradas: X[3..0]
--				   	 Saidas :  H[6..0]
-- DEC decodifica um vetor de 4 bits gerando 7 sinais para ativacao 
--	(em nivel logico zero)  dos 7 segmentos de um display em codigos hexadecimais
-- DEC eh um decodificador assincrono. 
--********************************************************************************
library ieee;
use ieee.std_logic_1164.all;

entity DEC_DP is			  			  			-- declaracao da entidade DEC.vhd
	port 
	(
		X 	: in std_logic_vector(3 downto 0); 	-- vetor de entrada X(3) X(2) X(1) X(0)
		H  : out std_logic_vector(6 downto 0) 	-- vetor de saida H(6) H(5) H(4) H(3) H(2) H(1) H(0)
	);
end DEC_DP;

architecture FLUXO_DE_DADOS of DEC_DP is      		-- arquitetura com seletor de dados para DEC
begin
	with X select
		H <="1000111" when "0000",	-- display L 
			 "1000000" when "0001",	-- display O
			 "0110110" when "0010",	-- display M
			 "1111111" when others;	-- display TUDO APAGADO
end FLUXO_DE_DADOS;
