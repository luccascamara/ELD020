--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Decodificador BCD- Didplay de 7 Segmentos => DEC.vhd
-- Rev. 0
-- Especificacoes: Entradas: X[3..0]
--				   	 Saidas :  H[6..0]
-- DEC decodifica um vetor de 4 bits gerando 7 sinais para ativacao 
--	(em nivel logico zero)  dos 7 segmentos de um display em codigos hexadecimais
-- DEC eh um decodificador assincrono. 
--********************************************************************************
library ieee;
use ieee.std_logic_1164.all;

entity DEC is			  			  			-- declaracao da entidade DEC.vhd
	port 
	(
		X 	: in std_logic_vector(3 downto 0); 	-- vetor de entrada X(3) X(2) X(1) X(0)
		H  : out std_logic_vector(6 downto 0) 	-- vetor de saida H(6) H(5) H(4) H(3) H(2) H(1) H(0)
	);
end DEC;

architecture FLUXO_DE_DADOS of DEC is      		-- arquitetura com seletor de dados para DEC
begin
	with X select
		H <="1000000" when "0000",	-- display 0
			"1111001" when "0001",	-- display 1
			"0100100" when "0010",	-- display 2
			"0110000" when "0011",	-- display 3
			"0011001" when "0100",	-- display 4
			"0010010" when "0101",	-- display 5
			"0000010" when "0110",	-- display 6
			"1111000" when "0111",	-- display 7
			"0000000" when "1000",	-- display 8
			"0010000" when "1001",	-- display 9
			"0001000" when "1010",	-- display A
			"0000011" when "1011",	-- display b
			"1000110" when "1100",	-- display C
			"0100001" when "1101",	-- display d
			"0000110" when "1110",	-- display E
			"0001110" when others;	-- display F
end FLUXO_DE_DADOS;
