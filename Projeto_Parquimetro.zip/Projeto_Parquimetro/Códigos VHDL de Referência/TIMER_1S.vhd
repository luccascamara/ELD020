--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Timer de 1 segundo => TIMER_1S.vhd
-- Rev. 0
-- Especificacoes: Entradas: CK, RT
--				   	 Saidas :  TM
-- TIMER eh um contador crescente de zero a 49.999.999.
-- Possui um sinal de saida (TM) que vai para '1' quando a contagem chega ao maximo.
-- Quando eh recebido um sinal de inicio de contagem (RT=1) o TIMER reinicia 
--	o contador, de modo sincrono, com o valor zero enquanto RT=1.
--	Para disparar o TIMER deve ocorrer RT=0, fazendo o contador do TIMER
--	iniciar a contagem crescente. Enquanto a contagem nao atingir o valor
--	maximo a saida TM eh mantida em zero. Chegando ao valor maximo ocorre TM=1.
--	Com frequencia de clock de 50 MHz o sinal TM permanece em zero por 1 segundo. 
--********************************************************************************
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;

ENTITY TIMER_1S IS PORT(
   CK		: IN std_logic;	-- Clock de 50MHz
	RT		: IN std_logic; 	-- Reseta e inicia temporizacao 
	TM		: OUT std_logic 	-- Final de temporizacao 
    );
END TIMER_1S;
   
ARCHITECTURE COMPORTAMENTAL OF TIMER_1S IS
SIGNAL CNT: INTEGER RANGE 0 TO 50000000;-- contador (0 a 49.999.999)

BEGIN
    PROCESS (CK,RT)				-- lista da sensibilidade do processo
    BEGIN
		IF (CK'event and CK='1') THEN  -- detecta borda de subida do CK
			IF (RT= '1') THEN 
				CNT<= 0;				-- inicia contador com zero
				TM<= '0';			-- inicia TM resetado
--			ELSIF CNT< 49999999 THEN  -- contagem 0 a 49.999.999 (usada no projeto final)
			ELSIF CNT< 4 THEN 		  -- contagem 0 a 4 (usada para simulacao)
				CNT<= CNT+1; 	-- incrementa contador
				TM<= '0';		-- mantem TM resetado
			ELSE 
				TM<= '1';		-- ativa TM e mantem CNT no maximo
			END IF;
		END IF;
    END PROCESS;
END COMPORTAMENTAL;