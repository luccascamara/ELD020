--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Unidade de Controle Exemplo => UC_Exemplo.vhd
-- Rev. 0
-- Especificacoes: Entradas: CK, SP, IT, DT, CC, VC, ZR, PO, NG, ES, TM
-- 			 Saidas:Sel_mxa[1..0], Sel_mxb[1..0], Sel_alu[1..0],Lda, Ldb, Ldc, RT
-- A UC controla os elementos do fluxo de dados do processador para parquimetro.
--********************************************************************************
library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity UC_Exemplo is
port(	CK	: in std_logic;	-- clock de 50MHz
-- Entradas Externas:
		SP	: in std_logic; 	-- sinal de presenca de veiculo (ativo em '1')
		IT	: in std_logic; 	-- sinal que incrementa  X minutos de credito (ativo em '1')
		DT	: in std_logic; 	-- sinal que decrementa Y minutos de credito (ativo em '1')
		CC : in std_logic; 	-- sinal de aceitacao do cartao de credito (ativo em '1')
		VC	: in std_logic; 	-- sinal para validacao de credito (ativo em '1')
-- Sinais de Estado da ALU:
		ZR	: in std_logic;	-- resultado zero na operacao (ativo em '1')
		PO	: in std_logic;	-- resultado positivo na operacao (ativo em '1')
		NG	: in std_logic;	-- resultado negativo na operacao (ativo em '1')
		ES	: in std_logic;	-- resultado de estouro na operacao (>15)	
-- Sinais de Estado dos TIMER's:
		TM	: in std_logic;	-- fim da temporizacao do Timer_1S (ativo em '1')
-- Sinais de Saida para MUX:
		Sel_mxa : out std_logic_vector(1 downto 0); 	-- seleciona entrada de MUX_A
		Sel_mxb	: out std_logic_vector(1 downto 0);	-- seleciona entrada de MUX_B
-- Sinais de Saida para ALU:
		Sel_alu	: out std_logic_vector(1 downto 0);	-- seleciona operacao da ALU
-- Sinais de Saida para Registradores:
		Lda		: out std_logic;						-- carrega TP (Tempo de Permanencia)
		Ldb		: out std_logic;						-- carrega TV (Tempo de Validacao)
		Ldc		: out std_logic;						-- carrega TC (Tempo de Credito)
-- Sinais de Saida para TIMER's:
		RT		: out std_logic;			-- inicia temporizacao do Timer_1 (ativo em '1')
-- Sinais de Saida da UC:
		MT		: out std_logic );		-- inicia multa (ativo em '1')
end UC_Exemplo;
----------------------------------------------------------------------------------
architecture FSM of UC_Exemplo is
type state_type is (ZERA_RG, VAG_OCP, CAR_TV, 
											-- COMPLETAR COM OS ESTADOS DA UC
																		MULTA);
signal E: state_type;
begin
Transicao_de_Estados: process(CK, SP)
begin
if SP='0' then E <= ZERA_RG;	  			-- zera registros, multa e vaga livre (DP=0)
elsif (CK'event and CK='1') then
 case E is
	when ZERA_RG => E <= VAG_OCP;			-- sinaliza ocupacao da vaga (DP=1)	
	when VAG_OCP => E <= CAR_TV;			-- carrega tempo de validacao	
	
		
											-- COMPLETAR A TRANSICAO DE ESTADOS DA UC
	
		
	when MULTA => E <= MULTA;								-- aciona multa e tira foto	
	when others => Null;
 end case;
end if;
end process Transicao_de_Estados;

Ativacao_de_Saidas: process(E)
begin
 case E is
	when ZERA_RG => 				 
				Sel_mxa <= "XX"; Sel_mxb <= "11"; Sel_alu <= "00";
				Ldc <= '1'; Ldb <= '1'; Lda <= '1';	RT <= '1'; MT <= '0';	
	when VAG_OCP =>
				Sel_mxa <= "00"; Sel_mxb <= "00"; Sel_alu <= "10";
				Ldc <= '0'; Ldb <= '0'; Lda <= '1';	RT <= '1'; MT <= '0';	
	
											-- COMPLETAR COM A SAIDA DOS OUTROS ESTADOS DA UC
	
	when MULTA => 		
				Sel_mxa <= "11"; Sel_mxb <= "11"; Sel_alu <= "10";
				Ldc <= '0'; Ldb <= '0'; Lda <= '1';	RT <= '1'; MT <= '1';	
	when others => Null;
 end case;
end process Ativacao_de_Saidas;
end FSM;
