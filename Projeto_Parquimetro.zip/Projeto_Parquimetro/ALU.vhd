--********************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 2  - 2 Semestre de 2025
-- Prof. Valter F. Avelino - 07/2025
-- Componente VHDL: Unidade Aritmetica e Logica => ALU.vhd
-- Rev. 0
-- Especificacoes: Entradas: A[3..0], B[3..0], Op[1..0]
--				  		 Saidas :  Alu_out[3..0], ZR, PO, NG, ES
-- ALU realiza as operacoes: Passa B (Op=00), NOT(B) (OP=01), B+A (Op=10) e B-A (Op=11)
-- ALU gera quattro sinais de status:
--  		Resultado igual a zero (ZR=1)
--       Resultado maior que zero (PO=1)
--			Resultado menor que zero (NG=1)
--			Resultado maior que 15 (ES=1)
-- Essa ALU eh assincrona. 
--********************************************************************************
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
 
entity ALU is
   port
   (
      A, B		 	: in std_logic_vector(3 downto 0); -- vetores de entrada
      Op			: in std_logic_vector(1 downto 0); -- codigo de operacao
      Alu_out		: out std_logic_vector(3 downto 0);-- vetor de saida
      ZR			: out std_logic; 				-- resultado igual a zero 
      PO			: out std_logic; 				-- resultado positivo 
      NG			: out std_logic; 				-- resultado negativo
      ES			: out std_logic 				-- resultado maoir que 15
   );
end entity ALU;
 
architecture Behavioral of ALU is

 begin
   process(A,B,Op) is		     				-- ALU assincrona
   
   variable Temp: std_logic_vector(5 downto 0);	-- registrador temporario 
												-- de 4 bits + bit de estouro + bit de sinal 
   begin
    case Op is
         when "00" =>       					-- Passa B
			Temp := std_logic_vector((unsigned("00" & B)));
		 when "01" =>       					-- NOT(B)
			Temp := std_logic_vector((unsigned("00" & NOT(B))));
         when "10" => 							-- B + A
            Temp(4 downto 0) := std_logic_vector(unsigned("0" & B) + unsigned("0" & A));
            Temp(5) := '0';						-- resultado positivo
         when "11" => 							-- |B - A|,NG=1 se B < A
            if (B > A) then
               Temp(4 downto 0) := std_logic_vector(unsigned("0" & B) - unsigned("0" & A));
               Temp(5) := '0';					-- resultado positivo
            elsif (B = A) then
			   Temp :="000000";					-- resultado zero
			elsif (B < A) then
               Temp(4 downto 0) := std_logic_vector(unsigned("0" & A) - unsigned("0" & B));
               Temp(5) := '1';					-- resultado negativo
            end if;
          when others => null;					-- nao faz nada com operando incorreto
    end case;
	if (Temp = "000000" ) then  				-- verifica se resultado eh igual a zero
		ZR <= '1';
		PO <= '0';
		NG <= '0';
		ES <= '0';
	elsif Temp(4) = '1' then  					-- verifica se resultado eh maior que 15
		ZR <= '0';
		PO <= '0';
		NG <= '0';
		ES <= '1';
	elsif Temp(5) = '1' then					-- verifica se resultado eh negativo 
		ZR <= '0';
		PO <= '0';
		NG <= '1';
		ES <= '0';
    else 										-- resultado eh positivo
		ZR <= '0';
		PO <= '1';
		NG <= '0';
		ES <= '0';
    end if;     
    
   Alu_out  <= Temp(3 downto 0); 				-- atualiza saida da ALU
         
   end process;
end architecture Behavioral;