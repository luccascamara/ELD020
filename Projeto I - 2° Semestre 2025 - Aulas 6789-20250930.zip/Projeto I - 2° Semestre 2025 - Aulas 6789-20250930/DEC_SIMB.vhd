--*****************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 1  - 2o Semestre de 2025
-- Prof. Dr. Valter F. Avelino - 07/2025
-- Componente VHDL: Decodificador Hexadecimal / 7 Segmentos => DEC_SIMB.vhd
-- Rev. 0
-- Especificacoes: Entradas: Q[3..0]
-- 				    Saidas:   H[6..0]
-- Esse codigo eh um exemplo de descricao VHDL de um decodificador de codigos
-- hexadecimais em codigo para ativacao de display de 7 segmentos da 
-- disciplina de Sistemas Digitais II do Centro Universitario FEI.
--****************************************************************************
library ieee;
use ieee.std_logic_1164.all;

entity DEC_SIMB is  			  			-- declaracao da entidade DEC_SIMB
	port 
	(	Q 	: in std_logic_vector(3 downto 0);-- vetor de entrada Q[3] Q[2] Q[1] Q[0]
		H : out std_logic_vector(6 downto 0)); -- vetor de saÃ­da H(6..0)
end DEC_SIMB;

architecture SELETOR of DEC_SIMB is      	
begin
	with Q select
		H   <="0001100" when "0000",	-- display P
				"1011011" when "0001",	-- display simbolo 1
				"1101101" when "0010",	-- display simbolo 2
				"1011011" when "0011",	-- display simbolo 1
				"1101101" when "0100",	-- display simbolo 2
				"1011011" when "0101",	-- display simbolo 1
				"1101101" when "0110",	-- display simbolo 2
				"1011011" when "0111",	-- display simbolo 1
				"1101101" when "1000",	-- display simbolo 2
				"1011011" when "1001",	-- display simbolo 1
				"1101101" when "1010",	-- display simbolo 2
				"1011011" when "1011",	-- display simbolo 1
				"1101101" when "1100",	-- display simbolo 2
				"1011011" when "1101",	-- display simbolo 1
				"1101101" when "1110",	-- display simbolo 2
				"1011011" when others;	-- display simbolo 1
end SELETOR;
