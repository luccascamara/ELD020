--****************************************************************************
-- CENTRO UNIVERSITARIO FEI
-- Sistemas Digitais II  -  Projeto 1  - 2o Semestre de 2025
-- Prof. Dr. Valter F. Avelino - 07/2025
-- Componente VHDL: FSM_Exemplo.vhd
-- Rev. 0
-- Especificacoes: 
--			Entradas: INI, CK, CK_EN, BP, SF, ST
-- 		Saidas: BPR, VDP, TVA[3..0], TVB[3..0], TVP[3..0], LD[5..0]
-- Esse codigo eh um exemplo de descricao VHDL de uma maquina de estados
-- finitos (FSM) de um controlador de semaforo adaptativo para o Projeto 1 da 
-- disciplina de Sistemas Digitais II do Centro Universitario FEI.
-- Parametros: TVA=N3; TVB=N2; TAA=TAB=N1; TVP=(N2+N1); TVAR=N2
--**************************************************************************** 
LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.all;
USE IEEE.STD_LOGIC_ARITH.ALL;

ENTITY FSM IS
    PORT (INI, CK, CK_EN, BP, SF, ST: 	IN STD_LOGIC;		-- sinais de entrada
			BPR, VDP: 							OUT STD_LOGIC;				        	 	-- sinais de saida
			TVA, TVB, TVP: 					OUT STD_LOGIC_VECTOR(3 DOWNTO 0);-- vetores de saida
			LD: 									OUT STD_LOGIC_VECTOR(5 DOWNTO 0));  	 		-- leds de saida
END FSM;

ARCHITECTURE BEHAVIOR OF FSM IS
    TYPE ESTADOS IS ( INICIO, FALHA,
							TVA_I, TVA_C, 	--TEMPO VERDE A
							TAA1, TAA2,		--TEMPO AMARELO A
							TVB_I, TVB_C, 	--TEMPO VERDE B
							TAB1, TAB2,		--TEMPO AMARELO B
							TVP_I, TVP_C);	--TEMPO VERDE P
	 
															
    SIGNAL E: ESTADOS;							-- declaracao de variavel de estado
	 SIGNAL VA,VB,VP, AA, AB: INTEGER RANGE 0 TO 15;-- declaracao de variaveis de contagem
	 CONSTANT N3: INTEGER := 7;   	-- declaracao de parametro
	 CONSTANT N2: INTEGER := 6;   -- declaracao de parametro
	 CONSTANT N1: INTEGER := 2;   -- declaracao de parametro
	 
BEGIN

------------------------------ ESTADOS ------------------------------

    PROCESS (INI, CK, CK_EN) 	-- processo para definir transicoes dos estados
    BEGIN
        IF (INI='0') THEN  E <= INICIO; VA <= 0; VB <= 0; VP <= 0;  -- estado inicial 
        ELSIF (CK'event and CK='1' and CK_EN='1') THEN -- sincronismo com CK_EN
				CASE E IS
					WHEN INICIO => 
						E <= TVA_I; 
						IF ST='0' THEN VA<=N3-1;  -- sensor de trafego
						ELSE VA<=N2-1;
						END IF;
					WHEN TVA_I =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSE E<= TVA_C;VA<=VA-1;
						END IF;
					WHEN TVA_C =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSIF VA = 0 THEN E<= TAA1; AA<=1;
						ELSE E<= TVA_C ; VA<=VA-1;
						END IF;
					WHEN TAA1 =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSE E<= TAA2; AA<=0;
						END IF;
					WHEN TAA2 =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSIF BP = '1' THEN E<= TVP_I; VP<=(N2+N1)-1; 
						ELSE E<= TVB_I ; VB<=(N2-1);
						END IF;
					WHEN TVP_I =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSE E<= TVP_C; VP<=VP-1;
						END IF;
					WHEN TVP_C =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSIF VP = 0 THEN E<= TVB_I; VB<=(N2-1);
						ELSE E<= TVP_C ; VP<=VP-1;
						END IF;
					WHEN TVB_I =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSE E<= TVB_C ; VB<=VB-1;
						END IF;
					WHEN TVB_C =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSIF VB = 0 THEN E<= TAB1; AB<=1;
						ELSE E<= TVB_C ; VB<=VB-1;
						END IF;
					WHEN TAB1 =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0; 
						ELSE E<= TAB2; AB<=0;
						END IF;
					WHEN TAB2 =>
						IF SF = '1' THEN E<= FALHA; VA<=0; VB<=0; VP<=0;  
						ELSE 	E<= TVA_I ;
								IF ST='0' THEN VA<=N3-1;  -- sensor de trafego
								ELSE VA<=N2-1;
								END IF;
						END IF;			
           		WHEN OTHERS => NULL;
				END CASE;
        END IF;
    END PROCESS;
    
	 ------------------------------ sAIDAS ------------------------------
	 
    PROCESS (E)							-- processo para definir variaveis de saida
    BEGIN
				CASE E IS								  
					WHEN INICIO =>	LD <= "100100"; VDP<= '0'; BPR<= '1';
               WHEN TVA_I =>	LD <= "001100"; VDP<= '0'; BPR<= '0';
					WHEN TVA_C =>	LD <= "001100"; VDP<= '0'; BPR<= '0';
					WHEN TAA1 =>	LD <= "010100"; VDP<= '0'; BPR<= '0';
					WHEN TAA2 =>	LD <= "010100"; VDP<= '0'; BPR<= '0';
					WHEN TVB_I =>	LD <= "100001"; VDP<= '0'; BPR<= '0';
					WHEN TVB_C =>	LD <= "100001"; VDP<= '0'; BPR<= '0';
					WHEN TAB1 =>	LD <= "100010"; VDP<= '0'; BPR<= '0';
					WHEN TAB2 =>	LD <= "100010"; VDP<= '0'; BPR<= '0';
					WHEN TVP_I =>	LD <= "100100"; VDP<= '1'; BPR<= '1';
					WHEN TVP_C =>	LD <= "100100"; VDP<= '1'; BPR<= '1';
					WHEN FALHA =>	LD <= "010010"; VDP<= '0'; BPR<= '1';
					WHEN OTHERS => NULL;
				END CASE;
     END PROCESS;
	  
	  -- Atualizacao das saidas dos temporizadores:
	  TVA <= CONV_STD_LOGIC_VECTOR(VA, TVA'length);
	  TVB <= CONV_STD_LOGIC_VECTOR(VB, TVB'length);
	  TVP <= CONV_STD_LOGIC_VECTOR(VP, TVP'length);
	  

END BEHAVIOR;
