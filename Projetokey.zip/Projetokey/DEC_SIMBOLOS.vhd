LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY DEC_SIMBOLOS IS
    PORT (
        Q : IN  STD_LOGIC_VECTOR(3 DOWNTO 0);   -- Entrada do contador TVP (4 bits)
        H : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)    -- Saída para display HEX5 (anodo comum)
    );
END DEC_SIMBOLOS;

ARCHITECTURE Behavior OF DEC_SIMBOLOS IS
BEGIN
    PROCESS(Q)
    BEGIN
        IF (Q = "0000") THEN
            -- Mostra a letra "P" (pedestre parado)
            -- Segmentos acesos: a, b, e, f, g → padrão "0111000"
            H <= "0111000";
        ELSE
            -- Alterna entre dois símbolos simétricos conforme o bit menos significativo
            IF (Q(0) = '0') THEN
                -- Símbolo 1
                -- Exemplo: segmentos a, c, e, f, g → "0100110"
                H <= "0100110";
            ELSE
                -- Símbolo 2 (simétrico)
                -- Exemplo: segmentos a, b, d, e, g → "0011010"
                H <= "0011010";
            END IF;
        END IF;
    END PROCESS;
END Behavior;
