-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 16.1.0 Build 196 10/24/2016 SJ Lite Edition"

-- DATE "10/08/2025 15:20:40"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	key IS
    PORT (
	BPR : OUT std_logic;
	INI : IN std_logic;
	CK : IN std_logic;
	CK_EN : IN std_logic;
	BP : OUT std_logic;
	KEY1 : IN std_logic;
	SF : IN std_logic;
	ST : IN std_logic;
	VDP : OUT std_logic;
	LD : OUT std_logic_vector(5 DOWNTO 0);
	TVA : OUT std_logic_vector(3 DOWNTO 0);
	TVB : OUT std_logic_vector(3 DOWNTO 0);
	TVP : OUT std_logic_vector(3 DOWNTO 0)
	);
END key;

ARCHITECTURE structure OF key IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_BPR : std_logic;
SIGNAL ww_INI : std_logic;
SIGNAL ww_CK : std_logic;
SIGNAL ww_CK_EN : std_logic;
SIGNAL ww_BP : std_logic;
SIGNAL ww_KEY1 : std_logic;
SIGNAL ww_SF : std_logic;
SIGNAL ww_ST : std_logic;
SIGNAL ww_VDP : std_logic;
SIGNAL ww_LD : std_logic_vector(5 DOWNTO 0);
SIGNAL ww_TVA : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_TVB : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_TVP : std_logic_vector(3 DOWNTO 0);
SIGNAL \BPR~output_o\ : std_logic;
SIGNAL \BP~output_o\ : std_logic;
SIGNAL \VDP~output_o\ : std_logic;
SIGNAL \LD[5]~output_o\ : std_logic;
SIGNAL \LD[4]~output_o\ : std_logic;
SIGNAL \LD[3]~output_o\ : std_logic;
SIGNAL \LD[2]~output_o\ : std_logic;
SIGNAL \LD[1]~output_o\ : std_logic;
SIGNAL \LD[0]~output_o\ : std_logic;
SIGNAL \TVA[3]~output_o\ : std_logic;
SIGNAL \TVA[2]~output_o\ : std_logic;
SIGNAL \TVA[1]~output_o\ : std_logic;
SIGNAL \TVA[0]~output_o\ : std_logic;
SIGNAL \TVB[3]~output_o\ : std_logic;
SIGNAL \TVB[2]~output_o\ : std_logic;
SIGNAL \TVB[1]~output_o\ : std_logic;
SIGNAL \TVB[0]~output_o\ : std_logic;
SIGNAL \TVP[3]~output_o\ : std_logic;
SIGNAL \TVP[2]~output_o\ : std_logic;
SIGNAL \TVP[1]~output_o\ : std_logic;
SIGNAL \TVP[0]~output_o\ : std_logic;
SIGNAL \CK~input_o\ : std_logic;
SIGNAL \KEY1~input_o\ : std_logic;
SIGNAL \INI~input_o\ : std_logic;
SIGNAL \SF~input_o\ : std_logic;
SIGNAL \inst2|E.TVA_I~6_combout\ : std_logic;
SIGNAL \inst2|Selector26~0_combout\ : std_logic;
SIGNAL \CK_EN~input_o\ : std_logic;
SIGNAL \inst2|E.TVA_I~7_combout\ : std_logic;
SIGNAL \inst2|Selector22~0_combout\ : std_logic;
SIGNAL \inst2|VP[3]~1_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~0_combout\ : std_logic;
SIGNAL \ST~input_o\ : std_logic;
SIGNAL \inst2|VA[0]~3_combout\ : std_logic;
SIGNAL \inst2|VA[3]~4_combout\ : std_logic;
SIGNAL \inst2|VA[3]~5_combout\ : std_logic;
SIGNAL \inst2|VA[3]~6_combout\ : std_logic;
SIGNAL \inst2|Add0~2_combout\ : std_logic;
SIGNAL \inst2|VA[1]~2_combout\ : std_logic;
SIGNAL \inst2|Add0~1_combout\ : std_logic;
SIGNAL \inst2|VA[2]~1_combout\ : std_logic;
SIGNAL \inst2|Add0~0_combout\ : std_logic;
SIGNAL \inst2|VA[3]~0_combout\ : std_logic;
SIGNAL \inst2|Equal0~0_combout\ : std_logic;
SIGNAL \inst2|AA[0]~7_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~1_combout\ : std_logic;
SIGNAL \inst2|AA[0]~2_combout\ : std_logic;
SIGNAL \inst2|AA[0]~5_combout\ : std_logic;
SIGNAL \inst2|AA[1]~6_combout\ : std_logic;
SIGNAL \inst2|Add1~1_combout\ : std_logic;
SIGNAL \inst2|AA[2]~4_combout\ : std_logic;
SIGNAL \inst2|Add1~0_combout\ : std_logic;
SIGNAL \inst2|AA[3]~3_combout\ : std_logic;
SIGNAL \inst2|Equal1~0_combout\ : std_logic;
SIGNAL \inst2|VP[3]~0_combout\ : std_logic;
SIGNAL \inst2|VP[0]~4_combout\ : std_logic;
SIGNAL \inst2|VP[1]~3_combout\ : std_logic;
SIGNAL \inst2|Add4~0_combout\ : std_logic;
SIGNAL \inst2|VP[2]~2_combout\ : std_logic;
SIGNAL \inst2|Equal4~0_combout\ : std_logic;
SIGNAL \inst2|E.INICIO~2_combout\ : std_logic;
SIGNAL \inst2|VB[3]~0_combout\ : std_logic;
SIGNAL \inst2|VB[3]~1_combout\ : std_logic;
SIGNAL \inst2|VB[3]~2_combout\ : std_logic;
SIGNAL \inst2|Selector21~0_combout\ : std_logic;
SIGNAL \inst2|Selector20~0_combout\ : std_logic;
SIGNAL \inst2|Add2~0_combout\ : std_logic;
SIGNAL \inst2|Selector19~0_combout\ : std_logic;
SIGNAL \inst2|Equal2~0_combout\ : std_logic;
SIGNAL \inst2|AB[1]~0_combout\ : std_logic;
SIGNAL \inst2|Add3~2_combout\ : std_logic;
SIGNAL \inst2|Add3~1_combout\ : std_logic;
SIGNAL \inst2|Add3~0_combout\ : std_logic;
SIGNAL \inst2|Equal3~0_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~1_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~0_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~2_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~3_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~4_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~5_combout\ : std_logic;
SIGNAL \inst2|E.TVA_I~q\ : std_logic;
SIGNAL \inst2|E.INICIO~5_combout\ : std_logic;
SIGNAL \inst2|E.TAA_I~q\ : std_logic;
SIGNAL \inst2|E.TVB_I~6_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~2_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~3_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~4_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~5_combout\ : std_logic;
SIGNAL \inst2|E.TVB_I~q\ : std_logic;
SIGNAL \inst2|E.INICIO~4_combout\ : std_logic;
SIGNAL \inst2|E.TAB~q\ : std_logic;
SIGNAL \inst2|E.INICIO~0_combout\ : std_logic;
SIGNAL \inst2|E.INICIO~1_combout\ : std_logic;
SIGNAL \inst2|E.INICIO~3_combout\ : std_logic;
SIGNAL \inst2|E.INICIO~6_combout\ : std_logic;
SIGNAL \inst2|E.INICIO~7_combout\ : std_logic;
SIGNAL \inst2|E.INICIO~q\ : std_logic;
SIGNAL \inst1|BP~0_combout\ : std_logic;
SIGNAL \inst1|BP~combout\ : std_logic;
SIGNAL \inst2|E.TVP_I~0_combout\ : std_logic;
SIGNAL \inst2|E.TVP_I~q\ : std_logic;
SIGNAL \inst2|BPR~combout\ : std_logic;
SIGNAL \inst2|WideOr5~combout\ : std_logic;
SIGNAL \inst2|E.FALHA~0_combout\ : std_logic;
SIGNAL \inst2|E.FALHA~q\ : std_logic;
SIGNAL \inst2|WideOr6~combout\ : std_logic;
SIGNAL \inst2|WideOr7~combout\ : std_logic;
SIGNAL \inst2|WideOr7~0_combout\ : std_logic;
SIGNAL \inst2|VA\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|AB\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|VB\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|VP\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|AA\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \inst2|ALT_INV_E.TAB~q\ : std_logic;
SIGNAL \inst2|ALT_INV_WideOr7~0_combout\ : std_logic;
SIGNAL \inst2|ALT_INV_WideOr7~combout\ : std_logic;

BEGIN

BPR <= ww_BPR;
ww_INI <= INI;
ww_CK <= CK;
ww_CK_EN <= CK_EN;
BP <= ww_BP;
ww_KEY1 <= KEY1;
ww_SF <= SF;
ww_ST <= ST;
VDP <= ww_VDP;
LD <= ww_LD;
TVA <= ww_TVA;
TVB <= ww_TVB;
TVP <= ww_TVP;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\inst2|ALT_INV_E.TAB~q\ <= NOT \inst2|E.TAB~q\;
\inst2|ALT_INV_WideOr7~0_combout\ <= NOT \inst2|WideOr7~0_combout\;
\inst2|ALT_INV_WideOr7~combout\ <= NOT \inst2|WideOr7~combout\;

\BPR~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|BPR~combout\,
	devoe => ww_devoe,
	o => \BPR~output_o\);

\BP~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst1|BP~combout\,
	devoe => ww_devoe,
	o => \BP~output_o\);

\VDP~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|E.TVP_I~q\,
	devoe => ww_devoe,
	o => \VDP~output_o\);

\LD[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|WideOr5~combout\,
	devoe => ww_devoe,
	o => \LD[5]~output_o\);

\LD[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|WideOr6~combout\,
	devoe => ww_devoe,
	o => \LD[4]~output_o\);

\LD[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|E.TVA_I~q\,
	devoe => ww_devoe,
	o => \LD[3]~output_o\);

\LD[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_WideOr7~combout\,
	devoe => ww_devoe,
	o => \LD[2]~output_o\);

\LD[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|ALT_INV_WideOr7~0_combout\,
	devoe => ww_devoe,
	o => \LD[1]~output_o\);

\LD[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|E.TVB_I~q\,
	devoe => ww_devoe,
	o => \LD[0]~output_o\);

\TVA[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VA\(3),
	devoe => ww_devoe,
	o => \TVA[3]~output_o\);

\TVA[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VA\(2),
	devoe => ww_devoe,
	o => \TVA[2]~output_o\);

\TVA[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VA\(1),
	devoe => ww_devoe,
	o => \TVA[1]~output_o\);

\TVA[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VA\(0),
	devoe => ww_devoe,
	o => \TVA[0]~output_o\);

\TVB[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VB\(3),
	devoe => ww_devoe,
	o => \TVB[3]~output_o\);

\TVB[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VB\(2),
	devoe => ww_devoe,
	o => \TVB[2]~output_o\);

\TVB[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VB\(1),
	devoe => ww_devoe,
	o => \TVB[1]~output_o\);

\TVB[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VB\(0),
	devoe => ww_devoe,
	o => \TVB[0]~output_o\);

\TVP[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VP\(3),
	devoe => ww_devoe,
	o => \TVP[3]~output_o\);

\TVP[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VP\(2),
	devoe => ww_devoe,
	o => \TVP[2]~output_o\);

\TVP[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VP\(1),
	devoe => ww_devoe,
	o => \TVP[1]~output_o\);

\TVP[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst2|VP\(0),
	devoe => ww_devoe,
	o => \TVP[0]~output_o\);

\CK~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK,
	o => \CK~input_o\);

\KEY1~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_KEY1,
	o => \KEY1~input_o\);

\INI~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_INI,
	o => \INI~input_o\);

\SF~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SF,
	o => \SF~input_o\);

\inst2|E.TVA_I~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~6_combout\ = (\inst2|E.TAB~q\ & (!\SF~input_o\)) # (!\inst2|E.TAB~q\ & ((!\inst2|E.INICIO~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SF~input_o\,
	datab => \inst2|E.INICIO~q\,
	datad => \inst2|E.TAB~q\,
	combout => \inst2|E.TVA_I~6_combout\);

\inst2|Selector26~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Selector26~0_combout\ = (!\inst2|AB\(0) & \inst2|E.TAB~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AB\(0),
	datad => \inst2|E.TAB~q\,
	combout => \inst2|Selector26~0_combout\);

\CK_EN~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK_EN,
	o => \CK_EN~input_o\);

\inst2|E.TVA_I~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~7_combout\ = (\inst2|E.TAB~q\ & (!\inst2|Equal3~0_combout\ & !\SF~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAB~q\,
	datac => \inst2|Equal3~0_combout\,
	datad => \SF~input_o\,
	combout => \inst2|E.TVA_I~7_combout\);

\inst2|Selector22~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Selector22~0_combout\ = (!\inst2|VB\(0)) # (!\inst2|E.TVB_I~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst2|E.TVB_I~q\,
	datad => \inst2|VB\(0),
	combout => \inst2|Selector22~0_combout\);

\inst2|VP[3]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VP[3]~1_combout\ = (\inst2|VP[3]~0_combout\ & ((\inst2|VP\(3) $ (\inst2|Equal4~0_combout\)) # (!\inst2|E.TVP_I~q\))) # (!\inst2|VP[3]~0_combout\ & (\inst2|VP\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VP\(3),
	datab => \inst2|VP[3]~0_combout\,
	datac => \inst2|Equal4~0_combout\,
	datad => \inst2|E.TVP_I~q\,
	combout => \inst2|VP[3]~1_combout\);

\inst2|VP[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VP[3]~1_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VP\(3));

\inst2|E.TVB_I~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~0_combout\ = (\inst2|E.TVP_I~q\ & ((\inst2|VP\(3)) # (!\inst2|Equal4~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \inst2|VP\(3),
	datad => \inst2|Equal4~0_combout\,
	combout => \inst2|E.TVB_I~0_combout\);

\ST~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ST,
	o => \ST~input_o\);

\inst2|VA[0]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[0]~3_combout\ = (\inst2|E.TVA_I~q\ & ((!\inst2|VA\(0)))) # (!\inst2|E.TVA_I~q\ & (\ST~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ST~input_o\,
	datab => \inst2|VA\(0),
	datad => \inst2|E.TVA_I~q\,
	combout => \inst2|VA[0]~3_combout\);

\inst2|VA[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[3]~4_combout\ = (\CK_EN~input_o\ & ((\inst2|E.TAB~q\) # ((\inst2|E.TVA_I~q\) # (!\inst2|E.INICIO~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CK_EN~input_o\,
	datab => \inst2|E.TAB~q\,
	datac => \inst2|E.TVA_I~q\,
	datad => \inst2|E.INICIO~q\,
	combout => \inst2|VA[3]~4_combout\);

\inst2|VA[3]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[3]~5_combout\ = (\inst2|VA[3]~4_combout\ & (((\inst2|Equal3~0_combout\ & !\SF~input_o\)) # (!\inst2|E.TAB~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VA[3]~4_combout\,
	datab => \inst2|Equal3~0_combout\,
	datac => \SF~input_o\,
	datad => \inst2|E.TAB~q\,
	combout => \inst2|VA[3]~5_combout\);

\inst2|VA[3]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[3]~6_combout\ = ((\inst2|E.TVA_I~q\ & ((\SF~input_o\) # (\inst2|Equal0~0_combout\)))) # (!\inst2|VA[3]~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VA[3]~5_combout\,
	datab => \SF~input_o\,
	datac => \inst2|Equal0~0_combout\,
	datad => \inst2|E.TVA_I~q\,
	combout => \inst2|VA[3]~6_combout\);

\inst2|VA[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VA[0]~3_combout\,
	asdata => \inst2|VA\(0),
	clrn => \INI~input_o\,
	sload => \inst2|VA[3]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VA\(0));

\inst2|Add0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add0~2_combout\ = \inst2|VA\(1) $ (\inst2|VA\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst2|VA\(1),
	datad => \inst2|VA\(0),
	combout => \inst2|Add0~2_combout\);

\inst2|VA[1]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[1]~2_combout\ = (\inst2|E.TVA_I~q\ & ((!\inst2|Add0~2_combout\))) # (!\inst2|E.TVA_I~q\ & (\ST~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ST~input_o\,
	datab => \inst2|Add0~2_combout\,
	datad => \inst2|E.TVA_I~q\,
	combout => \inst2|VA[1]~2_combout\);

\inst2|VA[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VA[1]~2_combout\,
	asdata => \inst2|VA\(1),
	clrn => \INI~input_o\,
	sload => \inst2|VA[3]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VA\(1));

\inst2|Add0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add0~1_combout\ = \inst2|VA\(2) $ (((\inst2|VA\(1)) # (\inst2|VA\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst2|VA\(1),
	datac => \inst2|VA\(0),
	datad => \inst2|VA\(2),
	combout => \inst2|Add0~1_combout\);

\inst2|VA[2]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[2]~1_combout\ = (\inst2|E.TVA_I~q\ & ((!\inst2|Add0~1_combout\))) # (!\inst2|E.TVA_I~q\ & (\ST~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ST~input_o\,
	datab => \inst2|Add0~1_combout\,
	datad => \inst2|E.TVA_I~q\,
	combout => \inst2|VA[2]~1_combout\);

\inst2|VA[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VA[2]~1_combout\,
	asdata => \inst2|VA\(2),
	clrn => \INI~input_o\,
	sload => \inst2|VA[3]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VA\(2));

\inst2|Add0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add0~0_combout\ = \inst2|VA\(3) $ (((\inst2|VA\(2)) # ((\inst2|VA\(1)) # (\inst2|VA\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VA\(2),
	datab => \inst2|VA\(1),
	datac => \inst2|VA\(0),
	datad => \inst2|VA\(3),
	combout => \inst2|Add0~0_combout\);

\inst2|VA[3]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VA[3]~0_combout\ = (\inst2|E.TVA_I~q\ & ((!\inst2|Add0~0_combout\))) # (!\inst2|E.TVA_I~q\ & (!\ST~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ST~input_o\,
	datab => \inst2|Add0~0_combout\,
	datad => \inst2|E.TVA_I~q\,
	combout => \inst2|VA[3]~0_combout\);

\inst2|VA[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VA[3]~0_combout\,
	asdata => \inst2|VA\(3),
	clrn => \INI~input_o\,
	sload => \inst2|VA[3]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VA\(3));

\inst2|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Equal0~0_combout\ = (!\inst2|VA\(3) & (!\inst2|VA\(2) & (!\inst2|VA\(1) & !\inst2|VA\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VA\(3),
	datab => \inst2|VA\(2),
	datac => \inst2|VA\(1),
	datad => \inst2|VA\(0),
	combout => \inst2|Equal0~0_combout\);

\inst2|AA[0]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AA[0]~7_combout\ = (\inst2|E.TVA_I~q\ & (!\SF~input_o\ & \inst2|Equal0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVA_I~q\,
	datab => \SF~input_o\,
	datac => \inst2|Equal0~0_combout\,
	combout => \inst2|AA[0]~7_combout\);

\inst2|E.TVB_I~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~1_combout\ = (\inst2|E.TAA_I~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAA_I~q\,
	datad => \SF~input_o\,
	combout => \inst2|E.TVB_I~1_combout\);

\inst2|AA[0]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AA[0]~2_combout\ = (\CK_EN~input_o\ & ((\inst2|AA[0]~7_combout\) # ((\inst2|Equal1~0_combout\ & \inst2|E.TVB_I~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CK_EN~input_o\,
	datab => \inst2|AA[0]~7_combout\,
	datac => \inst2|Equal1~0_combout\,
	datad => \inst2|E.TVB_I~1_combout\,
	combout => \inst2|AA[0]~2_combout\);

\inst2|AA[0]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AA[0]~5_combout\ = (\inst2|AA\(0) & ((!\inst2|AA[0]~2_combout\))) # (!\inst2|AA\(0) & (\inst2|E.TAA_I~q\ & \inst2|AA[0]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAA_I~q\,
	datac => \inst2|AA\(0),
	datad => \inst2|AA[0]~2_combout\,
	combout => \inst2|AA[0]~5_combout\);

\inst2|AA[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|AA[0]~5_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AA\(0));

\inst2|AA[1]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AA[1]~6_combout\ = (\inst2|AA[0]~2_combout\ & (\inst2|E.TAA_I~q\ & (\inst2|AA\(1) $ (!\inst2|AA\(0))))) # (!\inst2|AA[0]~2_combout\ & (((\inst2|AA\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAA_I~q\,
	datab => \inst2|AA\(1),
	datac => \inst2|AA\(0),
	datad => \inst2|AA[0]~2_combout\,
	combout => \inst2|AA[1]~6_combout\);

\inst2|AA[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|AA[1]~6_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AA\(1));

\inst2|Add1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add1~1_combout\ = \inst2|AA\(2) $ (((\inst2|AA\(0)) # (\inst2|AA\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst2|AA\(0),
	datac => \inst2|AA\(1),
	datad => \inst2|AA\(2),
	combout => \inst2|Add1~1_combout\);

\inst2|AA[2]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AA[2]~4_combout\ = (\inst2|AA[0]~2_combout\ & (((\inst2|E.TAA_I~q\ & !\inst2|Add1~1_combout\)))) # (!\inst2|AA[0]~2_combout\ & (\inst2|AA\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AA\(2),
	datab => \inst2|E.TAA_I~q\,
	datac => \inst2|AA[0]~2_combout\,
	datad => \inst2|Add1~1_combout\,
	combout => \inst2|AA[2]~4_combout\);

\inst2|AA[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|AA[2]~4_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AA\(2));

\inst2|Add1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add1~0_combout\ = \inst2|AA\(3) $ (((\inst2|AA\(2)) # ((\inst2|AA\(0)) # (\inst2|AA\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AA\(2),
	datab => \inst2|AA\(0),
	datac => \inst2|AA\(1),
	datad => \inst2|AA\(3),
	combout => \inst2|Add1~0_combout\);

\inst2|AA[3]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AA[3]~3_combout\ = (\inst2|AA[0]~2_combout\ & (((\inst2|E.TAA_I~q\ & !\inst2|Add1~0_combout\)))) # (!\inst2|AA[0]~2_combout\ & (\inst2|AA\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AA\(3),
	datab => \inst2|E.TAA_I~q\,
	datac => \inst2|AA[0]~2_combout\,
	datad => \inst2|Add1~0_combout\,
	combout => \inst2|AA[3]~3_combout\);

\inst2|AA[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|AA[3]~3_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AA\(3));

\inst2|Equal1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Equal1~0_combout\ = (\inst2|AA\(3)) # ((\inst2|AA\(2)) # ((\inst2|AA\(0)) # (\inst2|AA\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AA\(3),
	datab => \inst2|AA\(2),
	datac => \inst2|AA\(0),
	datad => \inst2|AA\(1),
	combout => \inst2|Equal1~0_combout\);

\inst2|VP[3]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VP[3]~0_combout\ = (\CK_EN~input_o\ & ((\inst2|E.TVB_I~0_combout\) # ((\inst2|E.TVP_I~0_combout\ & !\inst2|Equal1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CK_EN~input_o\,
	datab => \inst2|E.TVB_I~0_combout\,
	datac => \inst2|E.TVP_I~0_combout\,
	datad => \inst2|Equal1~0_combout\,
	combout => \inst2|VP[3]~0_combout\);

\inst2|VP[0]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VP[0]~4_combout\ = (\inst2|VP\(0) & ((!\inst2|VP[3]~0_combout\))) # (!\inst2|VP\(0) & (\inst2|E.TVP_I~q\ & \inst2|VP[3]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datac => \inst2|VP\(0),
	datad => \inst2|VP[3]~0_combout\,
	combout => \inst2|VP[0]~4_combout\);

\inst2|VP[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VP[0]~4_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VP\(0));

\inst2|VP[1]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VP[1]~3_combout\ = (\inst2|VP[3]~0_combout\ & (\inst2|E.TVP_I~q\ & (\inst2|VP\(1) $ (!\inst2|VP\(0))))) # (!\inst2|VP[3]~0_combout\ & (((\inst2|VP\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \inst2|VP\(1),
	datac => \inst2|VP\(0),
	datad => \inst2|VP[3]~0_combout\,
	combout => \inst2|VP[1]~3_combout\);

\inst2|VP[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VP[1]~3_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VP\(1));

\inst2|Add4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add4~0_combout\ = \inst2|VP\(2) $ (((\inst2|VP\(1)) # (\inst2|VP\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst2|VP\(1),
	datac => \inst2|VP\(0),
	datad => \inst2|VP\(2),
	combout => \inst2|Add4~0_combout\);

\inst2|VP[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VP[2]~2_combout\ = (\inst2|VP[3]~0_combout\ & (((\inst2|E.TVP_I~q\ & !\inst2|Add4~0_combout\)))) # (!\inst2|VP[3]~0_combout\ & (\inst2|VP\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VP\(2),
	datab => \inst2|E.TVP_I~q\,
	datac => \inst2|VP[3]~0_combout\,
	datad => \inst2|Add4~0_combout\,
	combout => \inst2|VP[2]~2_combout\);

\inst2|VP[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|VP[2]~2_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VP\(2));

\inst2|Equal4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Equal4~0_combout\ = (!\inst2|VP\(2) & (!\inst2|VP\(1) & !\inst2|VP\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst2|VP\(2),
	datac => \inst2|VP\(1),
	datad => \inst2|VP\(0),
	combout => \inst2|Equal4~0_combout\);

\inst2|E.INICIO~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~2_combout\ = (\inst2|E.TVP_I~q\ & (\inst2|Equal4~0_combout\ & !\inst2|VP\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \inst2|Equal4~0_combout\,
	datad => \inst2|VP\(3),
	combout => \inst2|E.INICIO~2_combout\);

\inst2|VB[3]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VB[3]~0_combout\ = (\inst2|E.TAA_I~q\ & (!\inst1|BP~combout\ & !\SF~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAA_I~q\,
	datac => \inst1|BP~combout\,
	datad => \SF~input_o\,
	combout => \inst2|VB[3]~0_combout\);

\inst2|VB[3]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VB[3]~1_combout\ = (\inst2|VB[3]~0_combout\ & (((\inst2|E.INICIO~4_combout\ & !\inst2|Equal2~0_combout\)) # (!\inst2|Equal1~0_combout\))) # (!\inst2|VB[3]~0_combout\ & (\inst2|E.INICIO~4_combout\ & ((!\inst2|Equal2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VB[3]~0_combout\,
	datab => \inst2|E.INICIO~4_combout\,
	datac => \inst2|Equal1~0_combout\,
	datad => \inst2|Equal2~0_combout\,
	combout => \inst2|VB[3]~1_combout\);

\inst2|VB[3]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|VB[3]~2_combout\ = (\CK_EN~input_o\ & ((\inst2|E.INICIO~2_combout\) # (\inst2|VB[3]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CK_EN~input_o\,
	datab => \inst2|E.INICIO~2_combout\,
	datac => \inst2|VB[3]~1_combout\,
	combout => \inst2|VB[3]~2_combout\);

\inst2|VB[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Selector22~0_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|VB[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VB\(0));

\inst2|Selector21~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Selector21~0_combout\ = (\inst2|VB\(1) $ (!\inst2|VB\(0))) # (!\inst2|E.TVB_I~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VB\(1),
	datab => \inst2|VB\(0),
	datad => \inst2|E.TVB_I~q\,
	combout => \inst2|Selector21~0_combout\);

\inst2|VB[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Selector21~0_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|VB[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VB\(1));

\inst2|Selector20~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Selector20~0_combout\ = (\inst2|VB\(2) $ (((!\inst2|VB\(1) & !\inst2|VB\(0))))) # (!\inst2|E.TVB_I~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VB\(2),
	datab => \inst2|VB\(1),
	datac => \inst2|VB\(0),
	datad => \inst2|E.TVB_I~q\,
	combout => \inst2|Selector20~0_combout\);

\inst2|VB[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Selector20~0_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|VB[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VB\(2));

\inst2|Add2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add2~0_combout\ = \inst2|VB\(3) $ (((\inst2|VB\(2)) # ((\inst2|VB\(1)) # (\inst2|VB\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VB\(2),
	datab => \inst2|VB\(1),
	datac => \inst2|VB\(0),
	datad => \inst2|VB\(3),
	combout => \inst2|Add2~0_combout\);

\inst2|Selector19~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Selector19~0_combout\ = (\inst2|E.TVB_I~q\ & !\inst2|Add2~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVB_I~q\,
	datad => \inst2|Add2~0_combout\,
	combout => \inst2|Selector19~0_combout\);

\inst2|VB[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Selector19~0_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|VB[3]~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|VB\(3));

\inst2|Equal2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Equal2~0_combout\ = (!\inst2|VB\(3) & (!\inst2|VB\(2) & (!\inst2|VB\(1) & !\inst2|VB\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|VB\(3),
	datab => \inst2|VB\(2),
	datac => \inst2|VB\(1),
	datad => \inst2|VB\(0),
	combout => \inst2|Equal2~0_combout\);

\inst2|AB[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|AB[1]~0_combout\ = (\CK_EN~input_o\ & ((\inst2|E.TVA_I~7_combout\) # ((\inst2|Equal2~0_combout\ & \inst2|E.INICIO~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CK_EN~input_o\,
	datab => \inst2|E.TVA_I~7_combout\,
	datac => \inst2|Equal2~0_combout\,
	datad => \inst2|E.INICIO~4_combout\,
	combout => \inst2|AB[1]~0_combout\);

\inst2|AB[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Selector26~0_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|AB[1]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AB\(0));

\inst2|Add3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add3~2_combout\ = \inst2|AB\(0) $ (!\inst2|AB\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst2|AB\(0),
	datad => \inst2|AB\(1),
	combout => \inst2|Add3~2_combout\);

\inst2|AB[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Add3~2_combout\,
	clrn => \INI~input_o\,
	sclr => \inst2|ALT_INV_E.TAB~q\,
	ena => \inst2|AB[1]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AB\(1));

\inst2|Add3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add3~1_combout\ = \inst2|AB\(2) $ (((!\inst2|AB\(0) & !\inst2|AB\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst2|AB\(0),
	datac => \inst2|AB\(1),
	datad => \inst2|AB\(2),
	combout => \inst2|Add3~1_combout\);

\inst2|AB[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Add3~1_combout\,
	clrn => \INI~input_o\,
	sclr => \inst2|ALT_INV_E.TAB~q\,
	ena => \inst2|AB[1]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AB\(2));

\inst2|Add3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Add3~0_combout\ = \inst2|AB\(3) $ (((!\inst2|AB\(2) & (!\inst2|AB\(0) & !\inst2|AB\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AB\(2),
	datab => \inst2|AB\(0),
	datac => \inst2|AB\(1),
	datad => \inst2|AB\(3),
	combout => \inst2|Add3~0_combout\);

\inst2|AB[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|Add3~0_combout\,
	clrn => \INI~input_o\,
	sclr => \inst2|ALT_INV_E.TAB~q\,
	ena => \inst2|AB[1]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|AB\(3));

\inst2|Equal3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|Equal3~0_combout\ = (!\inst2|AB\(3) & (!\inst2|AB\(2) & (!\inst2|AB\(0) & !\inst2|AB\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|AB\(3),
	datab => \inst2|AB\(2),
	datac => \inst2|AB\(0),
	datad => \inst2|AB\(1),
	combout => \inst2|Equal3~0_combout\);

\inst2|E.TVA_I~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~1_combout\ = ((\inst2|E.TAB~q\ & (!\inst2|Equal3~0_combout\ & !\SF~input_o\))) # (!\CK_EN~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAB~q\,
	datab => \inst2|Equal3~0_combout\,
	datac => \SF~input_o\,
	datad => \CK_EN~input_o\,
	combout => \inst2|E.TVA_I~1_combout\);

\inst2|E.TVA_I~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~0_combout\ = (\inst2|E.TVP_I~q\) # ((\inst2|E.INICIO~4_combout\) # ((\inst2|E.INICIO~5_combout\) # (\inst2|E.TVB_I~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \inst2|E.INICIO~4_combout\,
	datac => \inst2|E.INICIO~5_combout\,
	datad => \inst2|E.TVB_I~1_combout\,
	combout => \inst2|E.TVA_I~0_combout\);

\inst2|E.TVA_I~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~2_combout\ = (\inst2|E.TVA_I~0_combout\ & ((!\inst2|Equal0~0_combout\) # (!\inst2|E.TVA_I~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVA_I~0_combout\,
	datac => \inst2|E.TVA_I~q\,
	datad => \inst2|Equal0~0_combout\,
	combout => \inst2|E.TVA_I~2_combout\);

\inst2|E.TVA_I~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~3_combout\ = (\inst2|E.TAA_I~q\) # ((!\inst2|E.TVP_I~q\ & !\inst2|Equal2~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAA_I~q\,
	datac => \inst2|E.TVP_I~q\,
	datad => \inst2|Equal2~0_combout\,
	combout => \inst2|E.TVA_I~3_combout\);

\inst2|E.TVA_I~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~4_combout\ = (\inst2|Equal1~0_combout\ & ((\inst2|E.TVB_I~0_combout\) # ((\inst2|E.TVA_I~3_combout\)))) # (!\inst2|Equal1~0_combout\ & (!\inst2|E.TAA_I~q\ & ((\inst2|E.TVB_I~0_combout\) # (\inst2|E.TVA_I~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|Equal1~0_combout\,
	datab => \inst2|E.TVB_I~0_combout\,
	datac => \inst2|E.TVA_I~3_combout\,
	datad => \inst2|E.TAA_I~q\,
	combout => \inst2|E.TVA_I~4_combout\);

\inst2|E.TVA_I~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVA_I~5_combout\ = (!\inst2|E.TVA_I~1_combout\ & (((!\inst2|E.TVA_I~q\ & !\inst2|E.TVA_I~4_combout\)) # (!\inst2|E.TVA_I~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000100010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVA_I~1_combout\,
	datab => \inst2|E.TVA_I~2_combout\,
	datac => \inst2|E.TVA_I~q\,
	datad => \inst2|E.TVA_I~4_combout\,
	combout => \inst2|E.TVA_I~5_combout\);

\inst2|E.TVA_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|E.TVA_I~6_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|E.TVA_I~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.TVA_I~q\);

\inst2|E.INICIO~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~5_combout\ = (\inst2|E.TVA_I~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVA_I~q\,
	datad => \SF~input_o\,
	combout => \inst2|E.INICIO~5_combout\);

\inst2|E.TAA_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|E.INICIO~5_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|E.INICIO~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.TAA_I~q\);

\inst2|E.TVB_I~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~6_combout\ = (\SF~input_o\ & (\inst2|E.TVP_I~q\)) # (!\SF~input_o\ & ((\inst2|E.TAA_I~q\ & ((!\inst1|BP~combout\))) # (!\inst2|E.TAA_I~q\ & (\inst2|E.TVP_I~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \SF~input_o\,
	datac => \inst2|E.TAA_I~q\,
	datad => \inst1|BP~combout\,
	combout => \inst2|E.TVB_I~6_combout\);

\inst2|E.TVB_I~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~2_combout\ = (\inst2|E.TVB_I~0_combout\) # (((\inst2|Equal1~0_combout\ & \inst2|E.TVB_I~1_combout\)) # (!\CK_EN~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVB_I~0_combout\,
	datab => \inst2|Equal1~0_combout\,
	datac => \inst2|E.TVB_I~1_combout\,
	datad => \CK_EN~input_o\,
	combout => \inst2|E.TVB_I~2_combout\);

\inst2|E.TVB_I~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~3_combout\ = (\inst2|E.TAB~q\ & (((!\inst2|Equal3~0_combout\)))) # (!\inst2|E.TAB~q\ & (!\inst2|Equal2~0_combout\ & (\inst2|E.TVB_I~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TAB~q\,
	datab => \inst2|Equal2~0_combout\,
	datac => \inst2|E.TVB_I~q\,
	datad => \inst2|Equal3~0_combout\,
	combout => \inst2|E.TVB_I~3_combout\);

\inst2|E.TVB_I~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~4_combout\ = (\inst2|E.TVA_I~q\ & (!\inst2|Equal0~0_combout\)) # (!\inst2|E.TVA_I~q\ & ((\inst2|E.TVB_I~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111001001110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVA_I~q\,
	datab => \inst2|Equal0~0_combout\,
	datac => \inst2|E.TVB_I~3_combout\,
	combout => \inst2|E.TVB_I~4_combout\);

\inst2|E.TVB_I~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVB_I~5_combout\ = (!\inst2|E.TVB_I~2_combout\ & ((\SF~input_o\) # (!\inst2|E.TVB_I~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001100100011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SF~input_o\,
	datab => \inst2|E.TVB_I~2_combout\,
	datac => \inst2|E.TVB_I~4_combout\,
	combout => \inst2|E.TVB_I~5_combout\);

\inst2|E.TVB_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|E.TVB_I~6_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|E.TVB_I~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.TVB_I~q\);

\inst2|E.INICIO~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~4_combout\ = (\inst2|E.TVB_I~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVB_I~q\,
	datad => \SF~input_o\,
	combout => \inst2|E.INICIO~4_combout\);

\inst2|E.TAB\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|E.INICIO~4_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|E.INICIO~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.TAB~q\);

\inst2|E.INICIO~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~0_combout\ = (\inst2|E.TVP_I~q\) # ((!\SF~input_o\ & ((\inst2|E.TAB~q\) # (\inst2|E.TAA_I~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \inst2|E.TAB~q\,
	datac => \inst2|E.TAA_I~q\,
	datad => \SF~input_o\,
	combout => \inst2|E.INICIO~0_combout\);

\inst2|E.INICIO~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~1_combout\ = (\inst2|E.INICIO~0_combout\ & ((\inst2|E.TVP_I~q\) # ((\inst2|E.TAA_I~q\) # (!\inst2|Equal3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.INICIO~0_combout\,
	datab => \inst2|E.TVP_I~q\,
	datac => \inst2|E.TAA_I~q\,
	datad => \inst2|Equal3~0_combout\,
	combout => \inst2|E.INICIO~1_combout\);

\inst2|E.INICIO~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~3_combout\ = (\inst2|E.INICIO~1_combout\ & ((\inst2|E.TAA_I~q\ & (\inst2|Equal1~0_combout\)) # (!\inst2|E.TAA_I~q\ & ((!\inst2|E.INICIO~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.INICIO~1_combout\,
	datab => \inst2|Equal1~0_combout\,
	datac => \inst2|E.TAA_I~q\,
	datad => \inst2|E.INICIO~2_combout\,
	combout => \inst2|E.INICIO~3_combout\);

\inst2|E.INICIO~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~6_combout\ = (\inst2|E.INICIO~4_combout\ & (((\inst2|E.INICIO~5_combout\ & !\inst2|Equal0~0_combout\)) # (!\inst2|Equal2~0_combout\))) # (!\inst2|E.INICIO~4_combout\ & (\inst2|E.INICIO~5_combout\ & ((!\inst2|Equal0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.INICIO~4_combout\,
	datab => \inst2|E.INICIO~5_combout\,
	datac => \inst2|Equal2~0_combout\,
	datad => \inst2|Equal0~0_combout\,
	combout => \inst2|E.INICIO~6_combout\);

\inst2|E.INICIO~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.INICIO~7_combout\ = (!\inst2|E.INICIO~3_combout\ & (!\inst2|E.INICIO~6_combout\ & \CK_EN~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.INICIO~3_combout\,
	datab => \inst2|E.INICIO~6_combout\,
	datad => \CK_EN~input_o\,
	combout => \inst2|E.INICIO~7_combout\);

\inst2|E.INICIO\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => VCC,
	clrn => \INI~input_o\,
	ena => \inst2|E.INICIO~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.INICIO~q\);

\inst1|BP~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst1|BP~0_combout\ = (\inst2|E.TVP_I~q\) # ((!\INI~input_o\) # (!\inst2|E.INICIO~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datac => \inst2|E.INICIO~q\,
	datad => \INI~input_o\,
	combout => \inst1|BP~0_combout\);

\inst1|BP\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst1|BP~combout\ = (!\inst1|BP~0_combout\ & ((\inst1|BP~combout\) # (!\KEY1~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst1|BP~combout\,
	datac => \KEY1~input_o\,
	datad => \inst1|BP~0_combout\,
	combout => \inst1|BP~combout\);

\inst2|E.TVP_I~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.TVP_I~0_combout\ = (\inst1|BP~combout\ & (\inst2|E.TAA_I~q\ & !\SF~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst1|BP~combout\,
	datab => \inst2|E.TAA_I~q\,
	datad => \SF~input_o\,
	combout => \inst2|E.TVP_I~0_combout\);

\inst2|E.TVP_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|E.TVP_I~0_combout\,
	clrn => \INI~input_o\,
	ena => \inst2|E.TVB_I~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.TVP_I~q\);

\inst2|BPR\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|BPR~combout\ = (\inst2|E.TVP_I~q\) # (!\inst2|E.INICIO~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datad => \inst2|E.INICIO~q\,
	combout => \inst2|BPR~combout\);

\inst2|WideOr5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|WideOr5~combout\ = (\inst2|E.TVB_I~q\) # ((\inst2|E.TAB~q\) # (!\inst2|E.INICIO~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVB_I~q\,
	datab => \inst2|E.TAB~q\,
	datad => \inst2|E.INICIO~q\,
	combout => \inst2|WideOr5~combout\);

\inst2|E.FALHA~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|E.FALHA~0_combout\ = \inst2|E.INICIO~q\ $ (\inst2|E.TVA_I~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst2|E.INICIO~q\,
	datad => \inst2|E.TVA_I~0_combout\,
	combout => \inst2|E.FALHA~0_combout\);

\inst2|E.FALHA\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \inst2|E.FALHA~0_combout\,
	asdata => \SF~input_o\,
	clrn => \INI~input_o\,
	sload => \inst2|E.TAB~q\,
	ena => \inst2|E.TVA_I~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst2|E.FALHA~q\);

\inst2|WideOr6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|WideOr6~combout\ = (\inst2|E.TVP_I~q\) # ((\inst2|E.FALHA~q\) # (\inst2|E.TAA_I~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVP_I~q\,
	datab => \inst2|E.FALHA~q\,
	datac => \inst2|E.TAA_I~q\,
	combout => \inst2|WideOr6~combout\);

\inst2|WideOr7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|WideOr7~combout\ = (\inst2|E.TVB_I~q\) # ((\inst2|E.TAB~q\) # (\inst2|E.FALHA~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst2|E.TVB_I~q\,
	datab => \inst2|E.TAB~q\,
	datac => \inst2|E.FALHA~q\,
	combout => \inst2|WideOr7~combout\);

\inst2|WideOr7~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \inst2|WideOr7~0_combout\ = (!\inst2|E.TAB~q\ & !\inst2|E.FALHA~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst2|E.TAB~q\,
	datad => \inst2|E.FALHA~q\,
	combout => \inst2|WideOr7~0_combout\);

ww_BPR <= \BPR~output_o\;

ww_BP <= \BP~output_o\;

ww_VDP <= \VDP~output_o\;

ww_LD(5) <= \LD[5]~output_o\;

ww_LD(4) <= \LD[4]~output_o\;

ww_LD(3) <= \LD[3]~output_o\;

ww_LD(2) <= \LD[2]~output_o\;

ww_LD(1) <= \LD[1]~output_o\;

ww_LD(0) <= \LD[0]~output_o\;

ww_TVA(3) <= \TVA[3]~output_o\;

ww_TVA(2) <= \TVA[2]~output_o\;

ww_TVA(1) <= \TVA[1]~output_o\;

ww_TVA(0) <= \TVA[0]~output_o\;

ww_TVB(3) <= \TVB[3]~output_o\;

ww_TVB(2) <= \TVB[2]~output_o\;

ww_TVB(1) <= \TVB[1]~output_o\;

ww_TVB(0) <= \TVB[0]~output_o\;

ww_TVP(3) <= \TVP[3]~output_o\;

ww_TVP(2) <= \TVP[2]~output_o\;

ww_TVP(1) <= \TVP[1]~output_o\;

ww_TVP(0) <= \TVP[0]~output_o\;
END structure;


