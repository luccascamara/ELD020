library ieee;
use ieee.std_logic_1164.all;

entity vhdl2 is
    port (
        CK, INI, VA, VB : in std_logic;
        L : out std_logic
    );
end vhdl2;

architecture BEHAVIOR of vhdl2 is
    type ESTADOS is (E0, E1, E2, E3, E4, E5, E6, E7, E8, E9, EF);
    signal E : ESTADOS;
    signal V : std_logic_vector(1 downto 0);
begin
    V <= VA & VB;

    process (CK, INI)
    begin
        if (INI = '0') then
            E <= E0;
        elsif (CK'event and CK = '1') then
            case E is
                when E0 =>
                    if V = "01" then
                        E <= E1;
                    elsif V = "10" then
                        E <= E2;
                    else
                        E <= E0;
                    end if;

                when E1 =>
                    if V = "01" then
                        E <= E4;
                    elsif V = "10" then
                        E <= E3;
                    else
                        E <= E1;
                    end if;

                when E2 =>
                    if V = "01" then
                        E <= E3;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E2;
                    end if;

                when E3 =>
                    if V = "01" then
                        E <= EF;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E3;
                    end if;

                when E4 =>
                    if V = "01" then
                        E <= E5;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E4;
                    end if;

                when E5 =>
                    if V = "01" then
                        E <= E6;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E5;
                    end if;

                when E6 =>
                    if V = "01" then
                        E <= E7;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E6;
                    end if;

                when E7 =>
                    if V = "01" then
                        E <= E8;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E7;
                    end if;

                when E8 =>
                    if V = "01" then
                        E <= E9;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E8;
                    end if;

                when E9 =>
                    if V = "01" then
                        E <= EF;
                    elsif V = "10" then
                        E <= EF;
                    else
                        E <= E9;
                    end if;

                when EF =>
                    E <= E0;

                when others =>
                    null;
            end case;
        end if;
    end process;

    process (E)
    begin
        case E is
            when E0  => L <= '0';
            when E1  => L <= '0';
            when E2  => L <= '0';
            when E3  => L <= '0';
            when E4  => L <= '0';
            when E5  => L <= '0';
            when E6  => L <= '0';
            when E7  => L <= '0';
            when E8  => L <= '0';
            when E9  => L <= '0';
            when EF  => L <= '1';
            when others => null;
        end case;
    end process;
end BEHAVIOR;
