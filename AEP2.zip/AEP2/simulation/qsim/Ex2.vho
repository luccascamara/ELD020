-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 16.1.0 Build 196 10/24/2016 SJ Lite Edition"

-- DATE "10/15/2025 23:53:22"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	vhdl2 IS
    PORT (
	CK : IN std_logic;
	INI : IN std_logic;
	VA : IN std_logic;
	VB : IN std_logic;
	L : BUFFER std_logic
	);
END vhdl2;

-- Design Ports Information
-- L	=>  Location: PIN_W6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- VA	=>  Location: PIN_U6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- VB	=>  Location: PIN_U7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CK	=>  Location: PIN_M8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- INI	=>  Location: PIN_M9,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF vhdl2 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_CK : std_logic;
SIGNAL ww_INI : std_logic;
SIGNAL ww_VA : std_logic;
SIGNAL ww_VB : std_logic;
SIGNAL ww_L : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \INI~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \CK~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \L~output_o\ : std_logic;
SIGNAL \CK~input_o\ : std_logic;
SIGNAL \CK~inputclkctrl_outclk\ : std_logic;
SIGNAL \VA~input_o\ : std_logic;
SIGNAL \VB~input_o\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \INI~input_o\ : std_logic;
SIGNAL \INI~inputclkctrl_outclk\ : std_logic;
SIGNAL \E.E0~q\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \E.E1~q\ : std_logic;
SIGNAL \Selector4~0_combout\ : std_logic;
SIGNAL \E.E4~q\ : std_logic;
SIGNAL \Selector5~0_combout\ : std_logic;
SIGNAL \E.E5~q\ : std_logic;
SIGNAL \Selector6~0_combout\ : std_logic;
SIGNAL \E.E6~q\ : std_logic;
SIGNAL \Selector7~0_combout\ : std_logic;
SIGNAL \E.E7~q\ : std_logic;
SIGNAL \Selector8~0_combout\ : std_logic;
SIGNAL \E.E8~q\ : std_logic;
SIGNAL \Selector9~0_combout\ : std_logic;
SIGNAL \E.E9~q\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \E.E2~q\ : std_logic;
SIGNAL \Selector3~2_combout\ : std_logic;
SIGNAL \Selector3~3_combout\ : std_logic;
SIGNAL \E.E3~q\ : std_logic;
SIGNAL \Selector10~1_combout\ : std_logic;
SIGNAL \Selector10~0_combout\ : std_logic;
SIGNAL \Selector10~2_combout\ : std_logic;
SIGNAL \Selector10~3_combout\ : std_logic;
SIGNAL \E.EF~q\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_CK <= CK;
ww_INI <= INI;
ww_VA <= VA;
ww_VB <= VB;
L <= ww_L;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\INI~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \INI~input_o\);

\CK~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CK~input_o\);
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y41_N24
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X16_Y0_N30
\L~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \E.EF~q\,
	devoe => ww_devoe,
	o => \L~output_o\);

-- Location: IOIBUF_X0_Y18_N15
\CK~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK,
	o => \CK~input_o\);

-- Location: CLKCTRL_G3
\CK~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CK~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CK~inputclkctrl_outclk\);

-- Location: IOIBUF_X16_Y0_N8
\VA~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_VA,
	o => \VA~input_o\);

-- Location: IOIBUF_X16_Y0_N1
\VB~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_VB,
	o => \VB~input_o\);

-- Location: LCCOMB_X16_Y1_N10
\Selector0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = (!\E.EF~q\ & ((\E.E0~q\) # (\VA~input_o\ $ (\VB~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000100110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \E.EF~q\,
	datac => \E.E0~q\,
	datad => \VB~input_o\,
	combout => \Selector0~0_combout\);

-- Location: IOIBUF_X0_Y18_N22
\INI~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_INI,
	o => \INI~input_o\);

-- Location: CLKCTRL_G4
\INI~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \INI~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \INI~inputclkctrl_outclk\);

-- Location: FF_X16_Y1_N11
\E.E0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector0~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E0~q\);

-- Location: LCCOMB_X16_Y1_N12
\Selector1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E1~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((!\E.E0~q\))) # (!\VB~input_o\ & (\E.E1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000011010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E1~q\,
	datad => \E.E0~q\,
	combout => \Selector1~0_combout\);

-- Location: FF_X16_Y1_N13
\E.E1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector1~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E1~q\);

-- Location: LCCOMB_X16_Y1_N16
\Selector4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector4~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E4~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E1~q\))) # (!\VB~input_o\ & (\E.E4~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E4~q\,
	datad => \E.E1~q\,
	combout => \Selector4~0_combout\);

-- Location: FF_X16_Y1_N17
\E.E4\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector4~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E4~q\);

-- Location: LCCOMB_X16_Y1_N6
\Selector5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector5~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E5~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E4~q\))) # (!\VB~input_o\ & (\E.E5~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E5~q\,
	datad => \E.E4~q\,
	combout => \Selector5~0_combout\);

-- Location: FF_X16_Y1_N7
\E.E5\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector5~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E5~q\);

-- Location: LCCOMB_X16_Y1_N8
\Selector6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector6~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E6~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E5~q\))) # (!\VB~input_o\ & (\E.E6~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E6~q\,
	datad => \E.E5~q\,
	combout => \Selector6~0_combout\);

-- Location: FF_X16_Y1_N9
\E.E6\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector6~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E6~q\);

-- Location: LCCOMB_X16_Y1_N28
\Selector7~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector7~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E7~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E6~q\))) # (!\VB~input_o\ & (\E.E7~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E7~q\,
	datad => \E.E6~q\,
	combout => \Selector7~0_combout\);

-- Location: FF_X16_Y1_N29
\E.E7\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector7~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E7~q\);

-- Location: LCCOMB_X16_Y1_N22
\Selector8~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector8~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E8~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E7~q\))) # (!\VB~input_o\ & (\E.E8~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E8~q\,
	datad => \E.E7~q\,
	combout => \Selector8~0_combout\);

-- Location: FF_X16_Y1_N23
\E.E8\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector8~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E8~q\);

-- Location: LCCOMB_X16_Y1_N20
\Selector9~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector9~0_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E9~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E8~q\))) # (!\VB~input_o\ & (\E.E9~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E9~q\,
	datad => \E.E8~q\,
	combout => \Selector9~0_combout\);

-- Location: FF_X16_Y1_N21
\E.E9\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector9~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E9~q\);

-- Location: LCCOMB_X16_Y1_N26
\Selector2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (\VA~input_o\ & ((\VB~input_o\ & (\E.E2~q\)) # (!\VB~input_o\ & ((!\E.E0~q\))))) # (!\VA~input_o\ & (!\VB~input_o\ & (\E.E2~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000010110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E2~q\,
	datad => \E.E0~q\,
	combout => \Selector2~0_combout\);

-- Location: FF_X16_Y1_N27
\E.E2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector2~0_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E2~q\);

-- Location: LCCOMB_X16_Y1_N14
\Selector3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector3~2_combout\ = (\VA~input_o\ & (\VB~input_o\ & (\E.E3~q\))) # (!\VA~input_o\ & ((\VB~input_o\ & ((\E.E2~q\))) # (!\VB~input_o\ & (\E.E3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010010010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E3~q\,
	datad => \E.E2~q\,
	combout => \Selector3~2_combout\);

-- Location: LCCOMB_X16_Y1_N30
\Selector3~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector3~3_combout\ = (\Selector3~2_combout\) # ((\VA~input_o\ & (!\VB~input_o\ & \E.E1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \Selector3~2_combout\,
	datad => \E.E1~q\,
	combout => \Selector3~3_combout\);

-- Location: FF_X16_Y1_N31
\E.E3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector3~3_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.E3~q\);

-- Location: LCCOMB_X16_Y1_N4
\Selector10~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector10~1_combout\ = (\E.E8~q\) # (\E.E7~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \E.E8~q\,
	datad => \E.E7~q\,
	combout => \Selector10~1_combout\);

-- Location: LCCOMB_X16_Y1_N18
\Selector10~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector10~0_combout\ = (\E.E2~q\) # ((\E.E4~q\) # ((\E.E6~q\) # (\E.E5~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.E2~q\,
	datab => \E.E4~q\,
	datac => \E.E6~q\,
	datad => \E.E5~q\,
	combout => \Selector10~0_combout\);

-- Location: LCCOMB_X16_Y1_N0
\Selector10~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector10~2_combout\ = (\E.E3~q\) # ((!\VB~input_o\ & ((\Selector10~1_combout\) # (\Selector10~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.E3~q\,
	datab => \VB~input_o\,
	datac => \Selector10~1_combout\,
	datad => \Selector10~0_combout\,
	combout => \Selector10~2_combout\);

-- Location: LCCOMB_X16_Y1_N24
\Selector10~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector10~3_combout\ = (\E.E9~q\ & (\VA~input_o\ $ ((\VB~input_o\)))) # (!\E.E9~q\ & (\Selector10~2_combout\ & (\VA~input_o\ $ (\VB~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA~input_o\,
	datab => \VB~input_o\,
	datac => \E.E9~q\,
	datad => \Selector10~2_combout\,
	combout => \Selector10~3_combout\);

-- Location: FF_X16_Y1_N25
\E.EF\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \Selector10~3_combout\,
	clrn => \INI~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.EF~q\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_L <= \L~output_o\;
END structure;


