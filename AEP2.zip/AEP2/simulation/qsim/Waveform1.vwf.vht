-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "10/15/2025 23:47:48"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          Ex2
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY Ex2_vhd_vec_tst IS
END Ex2_vhd_vec_tst;
ARCHITECTURE Ex2_arch OF Ex2_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL CLOCK : STD_LOGIC;
SIGNAL F : STD_LOGIC;
SIGNAL INICIO : STD_LOGIC;
SIGNAL Y : STD_LOGIC;
COMPONENT Ex2
	PORT (
	CLOCK : IN STD_LOGIC;
	F : OUT STD_LOGIC;
	INICIO : IN STD_LOGIC;
	Y : IN STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : Ex2
	PORT MAP (
-- list connections between master ports and signals
	CLOCK => CLOCK,
	F => F,
	INICIO => INICIO,
	Y => Y
	);

-- INICIO
t_prcs_INICIO: PROCESS
BEGIN
	INICIO <= '0';
	WAIT FOR 20000 ps;
	INICIO <= '1';
WAIT;
END PROCESS t_prcs_INICIO;

-- CLOCK
t_prcs_CLOCK: PROCESS
BEGIN
LOOP
	CLOCK <= '0';
	WAIT FOR 5000 ps;
	CLOCK <= '1';
	WAIT FOR 5000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_CLOCK;

-- Y
t_prcs_Y: PROCESS
BEGIN
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 60000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 30000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 30000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 30000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 30000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 30000 ps;
	Y <= '0';
	WAIT FOR 20000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 90000 ps;
	Y <= '1';
	WAIT FOR 30000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 70000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 20000 ps;
	Y <= '1';
	WAIT FOR 50000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 40000 ps;
	Y <= '0';
	WAIT FOR 20000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
	WAIT FOR 20000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 20000 ps;
	Y <= '1';
	WAIT FOR 20000 ps;
	Y <= '0';
	WAIT FOR 10000 ps;
	Y <= '1';
	WAIT FOR 10000 ps;
	Y <= '0';
WAIT;
END PROCESS t_prcs_Y;
END Ex2_arch;
