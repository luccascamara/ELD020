-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "10/15/2025 23:53:21"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          vhdl2
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY vhdl2_vhd_vec_tst IS
END vhdl2_vhd_vec_tst;
ARCHITECTURE vhdl2_arch OF vhdl2_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL CK : STD_LOGIC;
SIGNAL INI : STD_LOGIC;
SIGNAL L : STD_LOGIC;
SIGNAL VA : STD_LOGIC;
SIGNAL VB : STD_LOGIC;
COMPONENT vhdl2
	PORT (
	CK : IN STD_LOGIC;
	INI : IN STD_LOGIC;
	L : BUFFER STD_LOGIC;
	VA : IN STD_LOGIC;
	VB : IN STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : vhdl2
	PORT MAP (
-- list connections between master ports and signals
	CK => CK,
	INI => INI,
	L => L,
	VA => VA,
	VB => VB
	);

-- INI
t_prcs_INI: PROCESS
BEGIN
	INI <= '0';
	WAIT FOR 30000 ps;
	INI <= '1';
WAIT;
END PROCESS t_prcs_INI;

-- CK
t_prcs_CK: PROCESS
BEGIN
LOOP
	CK <= '0';
	WAIT FOR 5000 ps;
	CK <= '1';
	WAIT FOR 5000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_CK;

-- VA
t_prcs_VA: PROCESS
BEGIN
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 40000 ps;
	VA <= '0';
	WAIT FOR 30000 ps;
	VA <= '1';
	WAIT FOR 50000 ps;
	VA <= '0';
	WAIT FOR 40000 ps;
	VA <= '1';
	WAIT FOR 30000 ps;
	VA <= '0';
	WAIT FOR 40000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 20000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 20000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
	WAIT FOR 70000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 20000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 20000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 30000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 10000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 30000 ps;
	VA <= '0';
	WAIT FOR 30000 ps;
	VA <= '1';
	WAIT FOR 60000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 40000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 30000 ps;
	VA <= '0';
	WAIT FOR 10000 ps;
	VA <= '1';
	WAIT FOR 20000 ps;
	VA <= '0';
WAIT;
END PROCESS t_prcs_VA;

-- VB
t_prcs_VB: PROCESS
BEGIN
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 20000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 20000 ps;
	VB <= '0';
	WAIT FOR 20000 ps;
	VB <= '1';
	WAIT FOR 30000 ps;
	VB <= '0';
	WAIT FOR 40000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 20000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 50000 ps;
	VB <= '1';
	WAIT FOR 20000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 50000 ps;
	VB <= '0';
	WAIT FOR 80000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 50000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 40000 ps;
	VB <= '1';
	WAIT FOR 30000 ps;
	VB <= '0';
	WAIT FOR 20000 ps;
	VB <= '1';
	WAIT FOR 40000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 20000 ps;
	VB <= '1';
	WAIT FOR 20000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 30000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 20000 ps;
	VB <= '1';
	WAIT FOR 60000 ps;
	VB <= '0';
	WAIT FOR 30000 ps;
	VB <= '1';
	WAIT FOR 30000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 30000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 10000 ps;
	VB <= '0';
	WAIT FOR 10000 ps;
	VB <= '1';
	WAIT FOR 20000 ps;
	VB <= '0';
	WAIT FOR 20000 ps;
	VB <= '1';
WAIT;
END PROCESS t_prcs_VB;
END vhdl2_arch;
