library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity AEP3 is
port(
  CK  : in  std_logic;

  -- Entradas de controle
  SP  : in  std_logic;  -- reset total (ativo em zero)
  IT  : in  std_logic;  -- incrementa X
  DT  : in  std_logic;  -- decrementa Y
  CC  : in  std_logic;  -- habilita cartão
  VC  : in  std_logic;  -- valida crédito

  -- Flags da ULA
  Z   : in  std_logic;
  P   : in  std_logic;
  N   : in  std_logic;
  E   : in  std_logic;

  -- Timer
  TM  : in  std_logic;

  -- Saídas
  DP  : out std_logic;
  MT  : out std_logic;

  -- MUX 4x1
  MX  : out std_logic_vector(1 downto 0);

  -- ULA
  ULA : out std_logic_vector(2 downto 0);

  -- Banco de registradores
  HRE : out std_logic;
  HRA : out std_logic;
  HRB : out std_logic;
  ERE : out std_logic_vector(1 downto 0);
  ERA : out std_logic_vector(1 downto 0);
  ERB : out std_logic_vector(1 downto 0);

  -- Timer
  RT  : out std_logic;

  -- Habilitação da saída de dados
  OE  : out std_logic
);
end AEP3;

architecture FSM of AEP3 is
  type ESTADOS is (
    INI_TC, INI_RX, INI_RY, INI_RMAX,
    AG_VALIDA, SOMA_X, VER_MAX, LIM_MAX, SUB_Y, LIM_MIN,
    VER_R3, AGD_TM, SUB_R3, MULTA
  );
  signal ME : ESTADOS;
begin
  --------------------------------------------------------------------
  -- Próximo estado
  --------------------------------------------------------------------
  process (CK, SP)
  begin
    if SP = '0' then
      ME <= INI_TC;        -- reset síncrono do estado
      DP <= '1';
      MT <= '0';
    elsif (CK'event and CK = '1') then
      case ME is
        when INI_TC =>
          if (SP = '1') then ME <= INI_RX; DP <= '0';
          else                 ME <= INI_TC;
          end if;

        when INI_RX   => ME <= INI_RY;
        when INI_RY   => ME <= INI_RMAX;
        when INI_RMAX => ME <= AG_VALIDA;

        when AG_VALIDA =>
          if (VC = '1') then
            ME <= VER_R3;
          elsif (CC = '1' and IT = '1') then
            ME <= SOMA_X;
          elsif (CC = '1' and DT = '1') then
            ME <= SUB_Y;
          else
            ME <= AG_VALIDA;
          end if;

        when SOMA_X   => ME <= VER_MAX;

        when VER_MAX =>
          if (P = '1') then ME <= LIM_MAX;
          else                ME <= AG_VALIDA;
          end if;

        when LIM_MAX  => ME <= AG_VALIDA;

        when SUB_Y =>
          if (N = '1') then ME <= LIM_MIN;
          else                ME <= AG_VALIDA;
          end if;

        when LIM_MIN  => ME <= AG_VALIDA;

        when VER_R3 =>
          if (Z = '1') then ME <= MULTA;
          else                ME <= AGD_TM;
          end if;

        when AGD_TM =>
          if (TM = '0') then ME <= AGD_TM;
          else                ME <= SUB_R3;
          end if;

        when SUB_R3 =>
          if (Z = '1') then ME <= MULTA;
          else                ME <= AGD_TM;
          end if;

        when MULTA    => ME <= MULTA; MT <= '1';
        when others   => null;
      end case;
    end if;
  end process;

  --------------------------------------------------------------------
  -- Saídas (MUX, Banco de Registradores, ULA, Timer, OE)
  -- ATUALIZADAS segundo a tabela enviada
  --------------------------------------------------------------------
  process (ME)
  begin
    case ME is
      -- Ini_TC
      when INI_TC =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "11";
        HRB <= '1';  ERB <= "11"; ULA <= "101"; OE  <= '1'; RT  <= '1';

      -- Ini_RX
      when INI_RX =>
        MX  <= "01"; HRE <= '1'; ERE <= "00"; HRA <= '0'; ERA <= "XX";
        HRB <= '0';  ERB <= "XX"; ULA <= "XXX"; OE  <= '0'; RT  <= '1';

      -- Ini_RY
      when INI_RY =>
        MX  <= "10"; HRE <= '1'; ERE <= "10"; HRA <= '0'; ERA <= "XX";
        HRB <= '0';  ERB <= "XX"; ULA <= "XXX"; OE  <= '0'; RT  <= '1';

      -- Ini_RMAX
      when INI_RMAX =>
        MX  <= "11"; HRE <= '1'; ERE <= "11"; HRA <= '0'; ERA <= "XX";
        HRB <= '0';  ERB <= "XX"; ULA <= "XXX"; OE  <= '0'; RT  <= '1';

      -- Ag_Valida
      when AG_VALIDA =>
        MX  <= "XX"; HRE <= '0'; ERE <= "XX"; HRA <= '1'; ERA <= "11";
        HRB <= '0';  ERB <= "XX"; ULA <= "000"; OE  <= '1'; RT  <= '1';

      -- Soma_X
      when SOMA_X =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "11";
        HRB <= '1';  ERB <= "00"; ULA <= "100"; OE  <= '1'; RT  <= '0';

      -- Ver_Max
      when VER_MAX =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "11";
        HRB <= '1';  ERB <= "01"; ULA <= "101"; OE  <= '0'; RT  <= '0';

      -- Lim_Max
      when LIM_MAX =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "01";
        HRB <= '0';  ERB <= "XX"; ULA <= "000"; OE  <= '1'; RT  <= '0';

      -- Sub_Y
      when SUB_Y =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "11";
        HRB <= '1';  ERB <= "10"; ULA <= "101"; OE  <= '1'; RT  <= '0';

      -- Lim_Min
      when LIM_MIN =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "11";
        HRB <= '1';  ERB <= "11"; ULA <= "101"; OE  <= '1'; RT  <= '0';

      -- Ver_R3
      when VER_R3 =>
        MX  <= "XX"; HRE <= '0'; ERE <= "XX"; HRA <= '1'; ERA <= "11";
        HRB <= '0';  ERB <= "XX"; ULA <= "000"; OE  <= '0'; RT  <= '1';

      -- Agd_TM
      when AGD_TM =>
        MX  <= "XX"; HRE <= '0'; ERE <= "XX"; HRA <= '0'; ERA <= "XX";
        HRB <= '0';  ERB <= "XX"; ULA <= "XXX"; OE  <= '1'; RT  <= '0';

      -- Sub_R3
      when SUB_R3 =>
        MX  <= "00"; HRE <= '1'; ERE <= "11"; HRA <= '1'; ERA <= "11";
        HRB <= '0';  ERB <= "XX"; ULA <= "111"; OE  <= '1'; RT  <= '1';

      -- Multa
      when MULTA =>
        MX  <= "XX"; HRE <= '0'; ERE <= "XX"; HRA <= '0'; ERA <= "XX";
        HRB <= '0';  ERB <= "XX"; ULA <= "XXX"; OE  <= '1'; RT  <= '1';

      when others => null;
    end case;
  end process;
end FSM;
