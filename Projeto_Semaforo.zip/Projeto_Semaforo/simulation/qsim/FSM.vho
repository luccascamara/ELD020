-- Copyright (C) 2016  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Intel and sold by Intel or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 16.1.0 Build 196 10/24/2016 SJ Lite Edition"

-- DATE "10/17/2025 15:33:25"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	FSM IS
    PORT (
	INI : IN std_logic;
	CK : IN std_logic;
	CK_EN : IN std_logic;
	BP : IN std_logic;
	SF : IN std_logic;
	ST : IN std_logic;
	BPR : OUT std_logic;
	VDP : OUT std_logic;
	TVA : OUT std_logic_vector(3 DOWNTO 0);
	TVB : OUT std_logic_vector(3 DOWNTO 0);
	TVP : OUT std_logic_vector(3 DOWNTO 0);
	LD : OUT std_logic_vector(5 DOWNTO 0)
	);
END FSM;

ARCHITECTURE structure OF FSM IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_INI : std_logic;
SIGNAL ww_CK : std_logic;
SIGNAL ww_CK_EN : std_logic;
SIGNAL ww_BP : std_logic;
SIGNAL ww_SF : std_logic;
SIGNAL ww_ST : std_logic;
SIGNAL ww_BPR : std_logic;
SIGNAL ww_VDP : std_logic;
SIGNAL ww_TVA : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_TVB : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_TVP : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_LD : std_logic_vector(5 DOWNTO 0);
SIGNAL \BPR~output_o\ : std_logic;
SIGNAL \VDP~output_o\ : std_logic;
SIGNAL \TVA[0]~output_o\ : std_logic;
SIGNAL \TVA[1]~output_o\ : std_logic;
SIGNAL \TVA[2]~output_o\ : std_logic;
SIGNAL \TVA[3]~output_o\ : std_logic;
SIGNAL \TVB[0]~output_o\ : std_logic;
SIGNAL \TVB[1]~output_o\ : std_logic;
SIGNAL \TVB[2]~output_o\ : std_logic;
SIGNAL \TVB[3]~output_o\ : std_logic;
SIGNAL \TVP[0]~output_o\ : std_logic;
SIGNAL \TVP[1]~output_o\ : std_logic;
SIGNAL \TVP[2]~output_o\ : std_logic;
SIGNAL \TVP[3]~output_o\ : std_logic;
SIGNAL \LD[0]~output_o\ : std_logic;
SIGNAL \LD[1]~output_o\ : std_logic;
SIGNAL \LD[2]~output_o\ : std_logic;
SIGNAL \LD[3]~output_o\ : std_logic;
SIGNAL \LD[4]~output_o\ : std_logic;
SIGNAL \LD[5]~output_o\ : std_logic;
SIGNAL \CK~input_o\ : std_logic;
SIGNAL \INI~input_o\ : std_logic;
SIGNAL \CK_EN~input_o\ : std_logic;
SIGNAL \E.INICIO~q\ : std_logic;
SIGNAL \SF~input_o\ : std_logic;
SIGNAL \E.FALHA~0_combout\ : std_logic;
SIGNAL \E.FALHA~q\ : std_logic;
SIGNAL \BP~input_o\ : std_logic;
SIGNAL \VP[0]~8_combout\ : std_logic;
SIGNAL \VP[0]~21_combout\ : std_logic;
SIGNAL \VP[0]~4_combout\ : std_logic;
SIGNAL \VP[0]~5_combout\ : std_logic;
SIGNAL \VP[0]~9_combout\ : std_logic;
SIGNAL \VP[0]~11_combout\ : std_logic;
SIGNAL \VB[0]~11_combout\ : std_logic;
SIGNAL \E.TVP_C~q\ : std_logic;
SIGNAL \VP[3]~12_combout\ : std_logic;
SIGNAL \VP[0]~13_combout\ : std_logic;
SIGNAL \Selector9~1_combout\ : std_logic;
SIGNAL \VP[1]~14_combout\ : std_logic;
SIGNAL \VP[1]~15_combout\ : std_logic;
SIGNAL \Equal1~1_combout\ : std_logic;
SIGNAL \VP[2]~16_combout\ : std_logic;
SIGNAL \VP[2]~17_combout\ : std_logic;
SIGNAL \VP[3]~18_combout\ : std_logic;
SIGNAL \VP[3]~19_combout\ : std_logic;
SIGNAL \Equal1~0_combout\ : std_logic;
SIGNAL \Selector10~0_combout\ : std_logic;
SIGNAL \VP[0]~10_combout\ : std_logic;
SIGNAL \E.TVB_I~q\ : std_logic;
SIGNAL \Selector18~0_combout\ : std_logic;
SIGNAL \VA[0]~3_combout\ : std_logic;
SIGNAL \VB[0]~2_combout\ : std_logic;
SIGNAL \Selector18~1_combout\ : std_logic;
SIGNAL \VB[0]~3_combout\ : std_logic;
SIGNAL \VP[0]~6_combout\ : std_logic;
SIGNAL \VP[0]~20_combout\ : std_logic;
SIGNAL \VP[0]~7_combout\ : std_logic;
SIGNAL \VB[0]~5_combout\ : std_logic;
SIGNAL \VB[0]~6_combout\ : std_logic;
SIGNAL \VB[1]~7_combout\ : std_logic;
SIGNAL \VB[2]~8_combout\ : std_logic;
SIGNAL \VB[2]~9_combout\ : std_logic;
SIGNAL \Add2~0_combout\ : std_logic;
SIGNAL \VB[3]~10_combout\ : std_logic;
SIGNAL \Equal2~0_combout\ : std_logic;
SIGNAL \Selector6~0_combout\ : std_logic;
SIGNAL \E.TVB_C~q\ : std_logic;
SIGNAL \VB[0]~4_combout\ : std_logic;
SIGNAL \E.TAB1~q\ : std_logic;
SIGNAL \VA[0]~5_combout\ : std_logic;
SIGNAL \E.TAB2~q\ : std_logic;
SIGNAL \VA[0]~1_combout\ : std_logic;
SIGNAL \E.TVA_I~q\ : std_logic;
SIGNAL \ST~input_o\ : std_logic;
SIGNAL \VA[0]~2_combout\ : std_logic;
SIGNAL \VA[0]~0_combout\ : std_logic;
SIGNAL \VA[0]~4_combout\ : std_logic;
SIGNAL \VA[0]~7_combout\ : std_logic;
SIGNAL \VA[0]~9_combout\ : std_logic;
SIGNAL \VA[0]~10_combout\ : std_logic;
SIGNAL \VA[1]~11_combout\ : std_logic;
SIGNAL \VA[1]~12_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \Selector12~5_combout\ : std_logic;
SIGNAL \Selector12~6_combout\ : std_logic;
SIGNAL \Selector11~0_combout\ : std_logic;
SIGNAL \Selector11~1_combout\ : std_logic;
SIGNAL \Selector11~2_combout\ : std_logic;
SIGNAL \Selector12~0_combout\ : std_logic;
SIGNAL \Selector12~1_combout\ : std_logic;
SIGNAL \Selector12~2_combout\ : std_logic;
SIGNAL \Selector12~3_combout\ : std_logic;
SIGNAL \Selector12~4_combout\ : std_logic;
SIGNAL \Selector12~7_combout\ : std_logic;
SIGNAL \Equal0~1_combout\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \E.TVA_C~q\ : std_logic;
SIGNAL \VA[0]~8_combout\ : std_logic;
SIGNAL \E.TAA1~q\ : std_logic;
SIGNAL \VA[0]~6_combout\ : std_logic;
SIGNAL \E.TAA2~q\ : std_logic;
SIGNAL \Selector9~0_combout\ : std_logic;
SIGNAL \E.TVP_I~q\ : std_logic;
SIGNAL \WideOr15~combout\ : std_logic;
SIGNAL \VDP~0_combout\ : std_logic;
SIGNAL \WideOr13~0_combout\ : std_logic;
SIGNAL \WideOr13~combout\ : std_logic;
SIGNAL \WideOr11~0_combout\ : std_logic;
SIGNAL \WideOr11~combout\ : std_logic;
SIGNAL VA : std_logic_vector(3 DOWNTO 0);
SIGNAL VB : std_logic_vector(3 DOWNTO 0);
SIGNAL VP : std_logic_vector(3 DOWNTO 0);
SIGNAL \ALT_INV_WideOr11~combout\ : std_logic;
SIGNAL \ALT_INV_WideOr11~0_combout\ : std_logic;
SIGNAL \ALT_INV_VA[0]~0_combout\ : std_logic;
SIGNAL \ALT_INV_WideOr13~combout\ : std_logic;
SIGNAL \ALT_INV_WideOr13~0_combout\ : std_logic;
SIGNAL \ALT_INV_VB[0]~2_combout\ : std_logic;
SIGNAL \ALT_INV_VDP~0_combout\ : std_logic;

BEGIN

ww_INI <= INI;
ww_CK <= CK;
ww_CK_EN <= CK_EN;
ww_BP <= BP;
ww_SF <= SF;
ww_ST <= ST;
BPR <= ww_BPR;
VDP <= ww_VDP;
TVA <= ww_TVA;
TVB <= ww_TVB;
TVP <= ww_TVP;
LD <= ww_LD;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_WideOr11~combout\ <= NOT \WideOr11~combout\;
\ALT_INV_WideOr11~0_combout\ <= NOT \WideOr11~0_combout\;
\ALT_INV_VA[0]~0_combout\ <= NOT \VA[0]~0_combout\;
\ALT_INV_WideOr13~combout\ <= NOT \WideOr13~combout\;
\ALT_INV_WideOr13~0_combout\ <= NOT \WideOr13~0_combout\;
\ALT_INV_VB[0]~2_combout\ <= NOT \VB[0]~2_combout\;
\ALT_INV_VDP~0_combout\ <= NOT \VDP~0_combout\;

\BPR~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \WideOr15~combout\,
	devoe => ww_devoe,
	o => \BPR~output_o\);

\VDP~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_VDP~0_combout\,
	devoe => ww_devoe,
	o => \VDP~output_o\);

\TVA[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VA(0),
	devoe => ww_devoe,
	o => \TVA[0]~output_o\);

\TVA[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VA(1),
	devoe => ww_devoe,
	o => \TVA[1]~output_o\);

\TVA[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VA(2),
	devoe => ww_devoe,
	o => \TVA[2]~output_o\);

\TVA[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VA(3),
	devoe => ww_devoe,
	o => \TVA[3]~output_o\);

\TVB[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VB(0),
	devoe => ww_devoe,
	o => \TVB[0]~output_o\);

\TVB[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VB(1),
	devoe => ww_devoe,
	o => \TVB[1]~output_o\);

\TVB[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VB(2),
	devoe => ww_devoe,
	o => \TVB[2]~output_o\);

\TVB[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VB(3),
	devoe => ww_devoe,
	o => \TVB[3]~output_o\);

\TVP[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VP(0),
	devoe => ww_devoe,
	o => \TVP[0]~output_o\);

\TVP[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VP(1),
	devoe => ww_devoe,
	o => \TVP[1]~output_o\);

\TVP[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VP(2),
	devoe => ww_devoe,
	o => \TVP[2]~output_o\);

\TVP[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VP(3),
	devoe => ww_devoe,
	o => \TVP[3]~output_o\);

\LD[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_VB[0]~2_combout\,
	devoe => ww_devoe,
	o => \LD[0]~output_o\);

\LD[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_WideOr13~0_combout\,
	devoe => ww_devoe,
	o => \LD[1]~output_o\);

\LD[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_WideOr13~combout\,
	devoe => ww_devoe,
	o => \LD[2]~output_o\);

\LD[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_VA[0]~0_combout\,
	devoe => ww_devoe,
	o => \LD[3]~output_o\);

\LD[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_WideOr11~0_combout\,
	devoe => ww_devoe,
	o => \LD[4]~output_o\);

\LD[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_WideOr11~combout\,
	devoe => ww_devoe,
	o => \LD[5]~output_o\);

\CK~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK,
	o => \CK~input_o\);

\INI~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_INI,
	o => \INI~input_o\);

\CK_EN~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK_EN,
	o => \CK_EN~input_o\);

\E.INICIO\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => VCC,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.INICIO~q\);

\SF~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SF,
	o => \SF~input_o\);

\E.FALHA~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \E.FALHA~0_combout\ = (\E.FALHA~q\) # ((\E.INICIO~q\ & (\CK_EN~input_o\ & \SF~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.FALHA~q\,
	datab => \E.INICIO~q\,
	datac => \CK_EN~input_o\,
	datad => \SF~input_o\,
	combout => \E.FALHA~0_combout\);

\E.FALHA\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \E.FALHA~0_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.FALHA~q\);

\BP~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_BP,
	o => \BP~input_o\);

\VP[0]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~8_combout\ = (\E.TAA2~q\) # (((\E.TVP_I~q\ & \SF~input_o\)) # (!\WideOr15~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAA2~q\,
	datab => \E.TVP_I~q\,
	datac => \SF~input_o\,
	datad => \WideOr15~combout\,
	combout => \VP[0]~8_combout\);

\VP[0]~21\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~21_combout\ = (\E.TAA2~q\ & (((!VP(0) & !\VP[0]~8_combout\)) # (!\SF~input_o\))) # (!\E.TAA2~q\ & (((!VP(0) & !\VP[0]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAA2~q\,
	datab => \SF~input_o\,
	datac => VP(0),
	datad => \VP[0]~8_combout\,
	combout => \VP[0]~21_combout\);

\VP[0]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~4_combout\ = (\CK_EN~input_o\ & (!\E.FALHA~q\ & (!\VA[0]~5_combout\ & !\VA[0]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \CK_EN~input_o\,
	datab => \E.FALHA~q\,
	datac => \VA[0]~5_combout\,
	datad => \VA[0]~6_combout\,
	combout => \VP[0]~4_combout\);

\VP[0]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~5_combout\ = (\SF~input_o\) # ((!\E.TVB_I~q\ & !\E.TVB_C~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SF~input_o\,
	datac => \E.TVB_I~q\,
	datad => \E.TVB_C~q\,
	combout => \VP[0]~5_combout\);

\VP[0]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~9_combout\ = (!\VA[0]~1_combout\ & ((\SF~input_o\) # ((!\E.TVA_I~q\ & !\E.TVA_C~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~1_combout\,
	datab => \SF~input_o\,
	datac => \E.TVA_I~q\,
	datad => \E.TVA_C~q\,
	combout => \VP[0]~9_combout\);

\VP[0]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~11_combout\ = (\VP[0]~4_combout\ & (\VP[0]~5_combout\ & (\VP[0]~9_combout\ & !\VP[0]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[0]~4_combout\,
	datab => \VP[0]~5_combout\,
	datac => \VP[0]~9_combout\,
	datad => \VP[0]~10_combout\,
	combout => \VP[0]~11_combout\);

\VB[0]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[0]~11_combout\ = (!\SF~input_o\ & ((\E.TVP_I~q\) # ((\E.TVP_C~q\ & \Equal1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVP_C~q\,
	datab => \SF~input_o\,
	datac => \E.TVP_I~q\,
	datad => \Equal1~0_combout\,
	combout => \VB[0]~11_combout\);

\E.TVP_C\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VB[0]~11_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TVP_C~q\);

\VP[3]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[3]~12_combout\ = (\VP[0]~11_combout\ & ((!\SF~input_o\) # (!\E.TVP_C~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[0]~11_combout\,
	datac => \E.TVP_C~q\,
	datad => \SF~input_o\,
	combout => \VP[3]~12_combout\);

\VP[0]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~13_combout\ = (\VP[0]~21_combout\ & ((\VP[3]~12_combout\) # ((VP(0) & !\VP[0]~11_combout\)))) # (!\VP[0]~21_combout\ & (((VP(0) & !\VP[0]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[0]~21_combout\,
	datab => \VP[3]~12_combout\,
	datac => VP(0),
	datad => \VP[0]~11_combout\,
	combout => \VP[0]~13_combout\);

\VP[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VP[0]~13_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VP(0));

\Selector9~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector9~1_combout\ = (\E.TAA2~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAA2~q\,
	datad => \SF~input_o\,
	combout => \Selector9~1_combout\);

\VP[1]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[1]~14_combout\ = (\Selector9~1_combout\) # ((!\VP[0]~8_combout\ & (VP(0) $ (!VP(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011101011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector9~1_combout\,
	datab => VP(0),
	datac => VP(1),
	datad => \VP[0]~8_combout\,
	combout => \VP[1]~14_combout\);

\VP[1]~15\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[1]~15_combout\ = (\VP[3]~12_combout\ & ((\VP[1]~14_combout\) # ((VP(1) & !\VP[0]~11_combout\)))) # (!\VP[3]~12_combout\ & (((VP(1) & !\VP[0]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[3]~12_combout\,
	datab => \VP[1]~14_combout\,
	datac => VP(1),
	datad => \VP[0]~11_combout\,
	combout => \VP[1]~15_combout\);

\VP[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VP[1]~15_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VP(1));

\Equal1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Equal1~1_combout\ = (!VP(0) & !VP(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => VP(0),
	datad => VP(1),
	combout => \Equal1~1_combout\);

\VP[2]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[2]~16_combout\ = (\Selector9~1_combout\) # ((!\VP[0]~8_combout\ & (VP(2) $ (\Equal1~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector9~1_combout\,
	datab => VP(2),
	datac => \Equal1~1_combout\,
	datad => \VP[0]~8_combout\,
	combout => \VP[2]~16_combout\);

\VP[2]~17\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[2]~17_combout\ = (\VP[3]~12_combout\ & ((\VP[2]~16_combout\) # ((VP(2) & !\VP[0]~11_combout\)))) # (!\VP[3]~12_combout\ & (((VP(2) & !\VP[0]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[3]~12_combout\,
	datab => \VP[2]~16_combout\,
	datac => VP(2),
	datad => \VP[0]~11_combout\,
	combout => \VP[2]~17_combout\);

\VP[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VP[2]~17_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VP(2));

\VP[3]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[3]~18_combout\ = (!\VP[0]~8_combout\ & (VP(3) $ (((!VP(2) & \Equal1~1_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VP(3),
	datab => VP(2),
	datac => \Equal1~1_combout\,
	datad => \VP[0]~8_combout\,
	combout => \VP[3]~18_combout\);

\VP[3]~19\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[3]~19_combout\ = (\VP[3]~12_combout\ & ((\VP[3]~18_combout\) # ((VP(3) & !\VP[0]~11_combout\)))) # (!\VP[3]~12_combout\ & (((VP(3) & !\VP[0]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[3]~12_combout\,
	datab => \VP[3]~18_combout\,
	datac => VP(3),
	datad => \VP[0]~11_combout\,
	combout => \VP[3]~19_combout\);

\VP[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VP[3]~19_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VP(3));

\Equal1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Equal1~0_combout\ = (VP(0)) # ((VP(1)) # ((VP(2)) # (VP(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VP(0),
	datab => VP(1),
	datac => VP(2),
	datad => VP(3),
	combout => \Equal1~0_combout\);

\Selector10~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector10~0_combout\ = (\E.TVP_C~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVP_C~q\,
	datad => \SF~input_o\,
	combout => \Selector10~0_combout\);

\VP[0]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~10_combout\ = (\BP~input_o\ & (!\Equal1~0_combout\ & (\Selector10~0_combout\))) # (!\BP~input_o\ & ((\Selector9~1_combout\) # ((!\Equal1~0_combout\ & \Selector10~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111010100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \BP~input_o\,
	datab => \Equal1~0_combout\,
	datac => \Selector10~0_combout\,
	datad => \Selector9~1_combout\,
	combout => \VP[0]~10_combout\);

\E.TVB_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VP[0]~10_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TVB_I~q\);

\Selector18~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector18~0_combout\ = (!\SF~input_o\ & ((\E.TVP_C~q\) # (\E.TAA2~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVP_C~q\,
	datab => \E.TAA2~q\,
	datad => \SF~input_o\,
	combout => \Selector18~0_combout\);

\VA[0]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~3_combout\ = (\E.INICIO~q\ & !\E.FALHA~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.INICIO~q\,
	datad => \E.FALHA~q\,
	combout => \VA[0]~3_combout\);

\VB[0]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[0]~2_combout\ = (!\E.TVB_I~q\ & !\E.TVB_C~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \E.TVB_I~q\,
	datad => \E.TVB_C~q\,
	combout => \VB[0]~2_combout\);

\Selector18~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector18~1_combout\ = (!\E.TVP_C~q\ & !\E.TAA2~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \E.TVP_C~q\,
	datad => \E.TAA2~q\,
	combout => \Selector18~1_combout\);

\VB[0]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[0]~3_combout\ = ((\VB[0]~2_combout\ & (\VA[0]~3_combout\)) # (!\VB[0]~2_combout\ & ((\SF~input_o\)))) # (!\Selector18~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~3_combout\,
	datab => \SF~input_o\,
	datac => \VB[0]~2_combout\,
	datad => \Selector18~1_combout\,
	combout => \VB[0]~3_combout\);

\VP[0]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~6_combout\ = (\CK_EN~input_o\ & ((\SF~input_o\) # ((!\E.TVA_I~q\ & !\E.TVA_C~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SF~input_o\,
	datab => \E.TVA_I~q\,
	datac => \E.TVA_C~q\,
	datad => \CK_EN~input_o\,
	combout => \VP[0]~6_combout\);

\VP[0]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~20_combout\ = (!\E.FALHA~q\ & ((\SF~input_o\) # (!\E.TAB1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110100001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAB1~q\,
	datab => \SF~input_o\,
	datac => \E.FALHA~q\,
	combout => \VP[0]~20_combout\);

\VP[0]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VP[0]~7_combout\ = (!\VA[0]~1_combout\ & (!\VA[0]~6_combout\ & (\VP[0]~6_combout\ & \VP[0]~20_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~1_combout\,
	datab => \VA[0]~6_combout\,
	datac => \VP[0]~6_combout\,
	datad => \VP[0]~20_combout\,
	combout => \VP[0]~7_combout\);

\VB[0]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[0]~5_combout\ = (!\VB[0]~11_combout\ & (\VP[0]~7_combout\ & (!\Selector9~0_combout\ & !\VB[0]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VB[0]~11_combout\,
	datab => \VP[0]~7_combout\,
	datac => \Selector9~0_combout\,
	datad => \VB[0]~4_combout\,
	combout => \VB[0]~5_combout\);

\VB[0]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[0]~6_combout\ = (\VB[0]~5_combout\ & ((\Selector18~0_combout\) # ((!VB(0) & !\VB[0]~3_combout\)))) # (!\VB[0]~5_combout\ & (((VB(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector18~0_combout\,
	datab => VB(0),
	datac => \VB[0]~3_combout\,
	datad => \VB[0]~5_combout\,
	combout => \VB[0]~6_combout\);

\VB[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VB[0]~6_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VB(0));

\VB[1]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[1]~7_combout\ = (\VB[0]~5_combout\ & (!\VB[0]~3_combout\ & (VB(1) $ (!VB(0))))) # (!\VB[0]~5_combout\ & (VB(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VB(1),
	datab => VB(0),
	datac => \VB[0]~3_combout\,
	datad => \VB[0]~5_combout\,
	combout => \VB[1]~7_combout\);

\VB[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VB[1]~7_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VB(1));

\VB[2]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[2]~8_combout\ = (!\VB[0]~3_combout\ & (VB(2) $ (((!VB(0) & !VB(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VB(2),
	datab => VB(0),
	datac => VB(1),
	datad => \VB[0]~3_combout\,
	combout => \VB[2]~8_combout\);

\VB[2]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[2]~9_combout\ = (\VB[0]~5_combout\ & (((\Selector18~0_combout\) # (\VB[2]~8_combout\)))) # (!\VB[0]~5_combout\ & (VB(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VB(2),
	datab => \VB[0]~5_combout\,
	datac => \Selector18~0_combout\,
	datad => \VB[2]~8_combout\,
	combout => \VB[2]~9_combout\);

\VB[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VB[2]~9_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VB(2));

\Add2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Add2~0_combout\ = VB(3) $ (((VB(0)) # ((VB(1)) # (VB(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VB(0),
	datab => VB(1),
	datac => VB(2),
	datad => VB(3),
	combout => \Add2~0_combout\);

\VB[3]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[3]~10_combout\ = (\VB[0]~5_combout\ & (((!\VB[0]~3_combout\ & !\Add2~0_combout\)))) # (!\VB[0]~5_combout\ & (VB(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VB(3),
	datab => \VB[0]~3_combout\,
	datac => \Add2~0_combout\,
	datad => \VB[0]~5_combout\,
	combout => \VB[3]~10_combout\);

\VB[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VB[3]~10_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VB(3));

\Equal2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Equal2~0_combout\ = (!VB(0) & (!VB(1) & (!VB(2) & !VB(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VB(0),
	datab => VB(1),
	datac => VB(2),
	datad => VB(3),
	combout => \Equal2~0_combout\);

\Selector6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector6~0_combout\ = (!\SF~input_o\ & ((\E.TVB_I~q\) # ((\E.TVB_C~q\ & !\Equal2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVB_I~q\,
	datab => \E.TVB_C~q\,
	datac => \Equal2~0_combout\,
	datad => \SF~input_o\,
	combout => \Selector6~0_combout\);

\E.TVB_C\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \Selector6~0_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TVB_C~q\);

\VB[0]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VB[0]~4_combout\ = (\E.TVB_C~q\ & (\Equal2~0_combout\ & !\SF~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVB_C~q\,
	datab => \Equal2~0_combout\,
	datad => \SF~input_o\,
	combout => \VB[0]~4_combout\);

\E.TAB1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VB[0]~4_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TAB1~q\);

\VA[0]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~5_combout\ = (\E.TAB1~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAB1~q\,
	datad => \SF~input_o\,
	combout => \VA[0]~5_combout\);

\E.TAB2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VA[0]~5_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TAB2~q\);

\VA[0]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~1_combout\ = ((!\SF~input_o\ & \E.TAB2~q\)) # (!\E.INICIO~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.INICIO~q\,
	datab => \SF~input_o\,
	datad => \E.TAB2~q\,
	combout => \VA[0]~1_combout\);

\E.TVA_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VA[0]~1_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TVA_I~q\);

\ST~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ST,
	o => \ST~input_o\);

\VA[0]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~2_combout\ = (\VA[0]~1_combout\ & (\ST~input_o\)) # (!\VA[0]~1_combout\ & ((!VA(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \ST~input_o\,
	datac => \VA[0]~1_combout\,
	datad => VA(0),
	combout => \VA[0]~2_combout\);

\VA[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~0_combout\ = (!\E.TVA_I~q\ & !\E.TVA_C~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \E.TVA_I~q\,
	datad => \E.TVA_C~q\,
	combout => \VA[0]~0_combout\);

\VA[0]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~4_combout\ = (\VA[0]~0_combout\ & ((\E.TAB2~q\ & ((!\SF~input_o\))) # (!\E.TAB2~q\ & (!\VA[0]~3_combout\)))) # (!\VA[0]~0_combout\ & (((!\SF~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001011011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~0_combout\,
	datab => \E.TAB2~q\,
	datac => \VA[0]~3_combout\,
	datad => \SF~input_o\,
	combout => \VA[0]~4_combout\);

\VA[0]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~7_combout\ = (\SF~input_o\) # ((!\E.TVP_I~q\ & (!\E.TVP_C~q\ & !\E.TAA2~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SF~input_o\,
	datab => \E.TVP_I~q\,
	datac => \E.TVP_C~q\,
	datad => \E.TAA2~q\,
	combout => \VA[0]~7_combout\);

\VA[0]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~9_combout\ = (\VP[0]~4_combout\ & (\VP[0]~5_combout\ & (\VA[0]~7_combout\ & !\VA[0]~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VP[0]~4_combout\,
	datab => \VP[0]~5_combout\,
	datac => \VA[0]~7_combout\,
	datad => \VA[0]~8_combout\,
	combout => \VA[0]~9_combout\);

\VA[0]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~10_combout\ = (\VA[0]~9_combout\ & (\VA[0]~2_combout\ & (\VA[0]~4_combout\))) # (!\VA[0]~9_combout\ & (((VA(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~2_combout\,
	datab => \VA[0]~4_combout\,
	datac => VA(0),
	datad => \VA[0]~9_combout\,
	combout => \VA[0]~10_combout\);

\VA[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VA[0]~10_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VA(0));

\VA[1]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[1]~11_combout\ = (\VA[0]~1_combout\ & (((!\ST~input_o\)))) # (!\VA[0]~1_combout\ & (VA(0) $ ((!VA(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000111101011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~1_combout\,
	datab => VA(0),
	datac => VA(1),
	datad => \ST~input_o\,
	combout => \VA[1]~11_combout\);

\VA[1]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[1]~12_combout\ = (\VA[0]~9_combout\ & (\VA[0]~4_combout\ & (\VA[1]~11_combout\))) # (!\VA[0]~9_combout\ & (((VA(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~4_combout\,
	datab => \VA[1]~11_combout\,
	datac => VA(1),
	datad => \VA[0]~9_combout\,
	combout => \VA[1]~12_combout\);

\VA[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VA[1]~12_combout\,
	clrn => \INI~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VA(1));

\Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (!VA(0) & (!VA(1) & !VA(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => VA(0),
	datac => VA(1),
	datad => VA(2),
	combout => \Equal0~0_combout\);

\Selector12~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~5_combout\ = (!\E.TVP_C~q\ & (!\E.TVB_I~q\ & (!\E.TVB_C~q\ & !\E.TAA2~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVP_C~q\,
	datab => \E.TVB_I~q\,
	datac => \E.TVB_C~q\,
	datad => \E.TAA2~q\,
	combout => \Selector12~5_combout\);

\Selector12~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~6_combout\ = (\Selector12~5_combout\ & (!\E.TVP_I~q\ & (!\E.TAB1~q\ & !\E.TAA1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector12~5_combout\,
	datab => \E.TVP_I~q\,
	datac => \E.TAB1~q\,
	datad => \E.TAA1~q\,
	combout => \Selector12~6_combout\);

\Selector11~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector11~0_combout\ = (VA(3) & ((\E.FALHA~q\) # ((!\SF~input_o\ & !\Selector12~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VA(3),
	datab => \E.FALHA~q\,
	datac => \SF~input_o\,
	datad => \Selector12~6_combout\,
	combout => \Selector11~0_combout\);

\Selector11~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector11~1_combout\ = (\E.TVA_I~q\ & ((VA(3) $ (\Equal0~0_combout\)))) # (!\E.TVA_I~q\ & (\E.TVA_C~q\ & (VA(3) & !\Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVA_I~q\,
	datab => \E.TVA_C~q\,
	datac => VA(3),
	datad => \Equal0~0_combout\,
	combout => \Selector11~1_combout\);

\Selector11~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector11~2_combout\ = (\Selector11~0_combout\) # ((\Selector11~1_combout\ & !\SF~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector11~0_combout\,
	datab => \Selector11~1_combout\,
	datad => \SF~input_o\,
	combout => \Selector11~2_combout\);

\VA[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \Selector11~2_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VA(3));

\Selector12~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~0_combout\ = (!\E.FALHA~q\ & (!\SF~input_o\ & ((VA(3)) # (!\E.TVA_C~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VA(3),
	datab => \E.TVA_C~q\,
	datac => \E.FALHA~q\,
	datad => \SF~input_o\,
	combout => \Selector12~0_combout\);

\Selector12~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~1_combout\ = (\E.FALHA~q\ & (VA(2) & ((!\E.TAB2~q\)))) # (!\E.FALHA~q\ & (((!\E.TAB2~q\) # (!\SF~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001110101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VA(2),
	datab => \SF~input_o\,
	datac => \E.FALHA~q\,
	datad => \E.TAB2~q\,
	combout => \Selector12~1_combout\);

\Selector12~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~2_combout\ = (\VA[0]~0_combout\ & ((\Selector12~1_combout\) # ((\Equal0~0_combout\ & \Selector12~0_combout\)))) # (!\VA[0]~0_combout\ & (\Equal0~0_combout\ & (\Selector12~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \VA[0]~0_combout\,
	datab => \Equal0~0_combout\,
	datac => \Selector12~0_combout\,
	datad => \Selector12~1_combout\,
	combout => \Selector12~2_combout\);

\Selector12~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~3_combout\ = (VA(0)) # ((VA(1)) # ((!\E.TVA_I~q\ & !\E.TVA_C~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VA(0),
	datab => VA(1),
	datac => \E.TVA_I~q\,
	datad => \E.TVA_C~q\,
	combout => \Selector12~3_combout\);

\Selector12~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~4_combout\ = (VA(2) & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VA(2),
	datad => \SF~input_o\,
	combout => \Selector12~4_combout\);

\Selector12~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector12~7_combout\ = (\Selector12~2_combout\ & ((\Selector12~6_combout\) # ((\Selector12~3_combout\ & \Selector12~4_combout\)))) # (!\Selector12~2_combout\ & (\Selector12~3_combout\ & (\Selector12~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector12~2_combout\,
	datab => \Selector12~3_combout\,
	datac => \Selector12~4_combout\,
	datad => \Selector12~6_combout\,
	combout => \Selector12~7_combout\);

\VA[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \Selector12~7_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => VA(2));

\Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Equal0~1_combout\ = (!VA(0) & (!VA(1) & (!VA(2) & !VA(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => VA(0),
	datab => VA(1),
	datac => VA(2),
	datad => VA(3),
	combout => \Equal0~1_combout\);

\Selector2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (!\SF~input_o\ & ((\E.TVA_I~q\) # ((\E.TVA_C~q\ & !\Equal0~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVA_I~q\,
	datab => \E.TVA_C~q\,
	datac => \Equal0~1_combout\,
	datad => \SF~input_o\,
	combout => \Selector2~0_combout\);

\E.TVA_C\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \Selector2~0_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TVA_C~q\);

\VA[0]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~8_combout\ = (\E.TVA_C~q\ & (\Equal0~0_combout\ & (!VA(3) & !\SF~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TVA_C~q\,
	datab => \Equal0~0_combout\,
	datac => VA(3),
	datad => \SF~input_o\,
	combout => \VA[0]~8_combout\);

\E.TAA1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VA[0]~8_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TAA1~q\);

\VA[0]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VA[0]~6_combout\ = (\E.TAA1~q\ & !\SF~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAA1~q\,
	datad => \SF~input_o\,
	combout => \VA[0]~6_combout\);

\E.TAA2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \VA[0]~6_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TAA2~q\);

\Selector9~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \Selector9~0_combout\ = (\E.TAA2~q\ & (\BP~input_o\ & !\SF~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.TAA2~q\,
	datab => \BP~input_o\,
	datad => \SF~input_o\,
	combout => \Selector9~0_combout\);

\E.TVP_I\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~input_o\,
	d => \Selector9~0_combout\,
	clrn => \INI~input_o\,
	ena => \CK_EN~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \E.TVP_I~q\);

WideOr15 : fiftyfivenm_lcell_comb
-- Equation(s):
-- \WideOr15~combout\ = (\E.FALHA~q\) # ((\E.TVP_I~q\) # ((\E.TVP_C~q\) # (!\E.INICIO~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.FALHA~q\,
	datab => \E.TVP_I~q\,
	datac => \E.TVP_C~q\,
	datad => \E.INICIO~q\,
	combout => \WideOr15~combout\);

\VDP~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \VDP~0_combout\ = (!\E.TVP_I~q\ & !\E.TVP_C~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \E.TVP_I~q\,
	datad => \E.TVP_C~q\,
	combout => \VDP~0_combout\);

\WideOr13~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \WideOr13~0_combout\ = (!\E.FALHA~q\ & (!\E.TAB1~q\ & !\E.TAB2~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \E.FALHA~q\,
	datac => \E.TAB1~q\,
	datad => \E.TAB2~q\,
	combout => \WideOr13~0_combout\);

WideOr13 : fiftyfivenm_lcell_comb
-- Equation(s):
-- \WideOr13~combout\ = (\E.FALHA~q\) # ((\E.TAB1~q\) # ((\E.TAB2~q\) # (!\VB[0]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.FALHA~q\,
	datab => \E.TAB1~q\,
	datac => \E.TAB2~q\,
	datad => \VB[0]~2_combout\,
	combout => \WideOr13~combout\);

\WideOr11~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \WideOr11~0_combout\ = (!\E.FALHA~q\ & (!\E.TAA1~q\ & !\E.TAA2~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \E.FALHA~q\,
	datac => \E.TAA1~q\,
	datad => \E.TAA2~q\,
	combout => \WideOr11~0_combout\);

WideOr11 : fiftyfivenm_lcell_comb
-- Equation(s):
-- \WideOr11~combout\ = (\E.FALHA~q\) # ((\E.TAA1~q\) # ((\E.TAA2~q\) # (!\VA[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E.FALHA~q\,
	datab => \E.TAA1~q\,
	datac => \E.TAA2~q\,
	datad => \VA[0]~0_combout\,
	combout => \WideOr11~combout\);

ww_BPR <= \BPR~output_o\;

ww_VDP <= \VDP~output_o\;

ww_TVA(0) <= \TVA[0]~output_o\;

ww_TVA(1) <= \TVA[1]~output_o\;

ww_TVA(2) <= \TVA[2]~output_o\;

ww_TVA(3) <= \TVA[3]~output_o\;

ww_TVB(0) <= \TVB[0]~output_o\;

ww_TVB(1) <= \TVB[1]~output_o\;

ww_TVB(2) <= \TVB[2]~output_o\;

ww_TVB(3) <= \TVB[3]~output_o\;

ww_TVP(0) <= \TVP[0]~output_o\;

ww_TVP(1) <= \TVP[1]~output_o\;

ww_TVP(2) <= \TVP[2]~output_o\;

ww_TVP(3) <= \TVP[3]~output_o\;

ww_LD(0) <= \LD[0]~output_o\;

ww_LD(1) <= \LD[1]~output_o\;

ww_LD(2) <= \LD[2]~output_o\;

ww_LD(3) <= \LD[3]~output_o\;

ww_LD(4) <= \LD[4]~output_o\;

ww_LD(5) <= \LD[5]~output_o\;
END structure;


