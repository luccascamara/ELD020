LIBRARY IEEE;				-- declaracao de bibliotecas para descricao do projeto principal
USE IEEE.STD_LOGIC_1164.ALL;

---------------------------------------------------------------------------------------------------------

ENTITY Reg_Ped IS				
	PORT(
		key, ck, set, rst : IN STD_LOGIC;
		BP: OUT STD_LOGIC);						
END Reg_Ped;

---------------------------------------------------------------------------------------------------------

ARCHITECTURE comportamental OF  Reg_Ped  IS			-- declaracao estrutural da entidade "ff_d"		
BEGIN
	
	process (ck,set,rst)
	begin
	
		if (rst='0') then BP <='0'; 
		elsif (set='1') then BP <= '0';	
		elsif (key='0') then BP <= not(key);
		end if;
	
	end process;
	
END comportamental;
